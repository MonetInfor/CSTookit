﻿namespace BLL
{
    using System;

    internal class Send_mailBll
    {
    }
}


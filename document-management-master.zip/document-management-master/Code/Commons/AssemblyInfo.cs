﻿// Assembly Commons, Version 1.0.0.0

[assembly: System.Reflection.AssemblyProduct("Commons")]
[assembly: System.Reflection.AssemblyFileVersion("1.0.0.0")]
[assembly: System.Runtime.InteropServices.Guid("7c1cee37-6acd-4403-a1c0-4ffed7a726ac")]
[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Reflection.AssemblyCopyright("版权所有 (C) WwW.TNIdea.CoM 2010")]
[assembly: System.Reflection.AssemblyDescription("")]
[assembly: System.Reflection.AssemblyCompany("WwW.TNIdea.CoM")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Diagnostics.Debuggable(System.Diagnostics.DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows=true)]
[assembly: System.Reflection.AssemblyTitle("Commons")]
[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]


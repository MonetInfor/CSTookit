//------------------------------------------------------------

//------------------------------------------------------------

namespace Machine.Design.FreeFormEditing
{
    internal delegate void LocationChangedEventHandler(object sender, LocationChangedEventArgs e);
}

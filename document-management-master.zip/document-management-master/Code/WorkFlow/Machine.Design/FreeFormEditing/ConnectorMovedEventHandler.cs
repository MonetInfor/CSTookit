//------------------------------------------------------------

//------------------------------------------------------------

namespace Machine.Design.FreeFormEditing
{
    internal delegate void ConnectorMovedEventHandler(object sender, ConnectorMovedEventArgs e);
}

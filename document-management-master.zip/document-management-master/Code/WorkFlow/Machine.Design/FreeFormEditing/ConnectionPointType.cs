//------------------------------------------------------------

//------------------------------------------------------------

namespace Machine.Design.FreeFormEditing
{
    enum ConnectionPointType
    {        
        Default,
        Incoming,
        Outgoing,
    }
}

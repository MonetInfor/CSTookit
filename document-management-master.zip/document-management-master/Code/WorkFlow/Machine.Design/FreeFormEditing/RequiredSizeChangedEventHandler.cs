﻿//------------------------------------------------------------

//------------------------------------------------------------

namespace Machine.Design.FreeFormEditing
{
    internal delegate void RequiredSizeChangedEventHandler(object sender, RequiredSizeChangedEventArgs e);
}
﻿//----------------------------------------------------------------

//----------------------------------------------------------------

namespace Machine.Design.ToolboxItems
{
    public sealed class FinalState
    {
    }
}
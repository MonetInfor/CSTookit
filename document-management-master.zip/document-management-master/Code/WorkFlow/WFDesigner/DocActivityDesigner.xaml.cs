﻿
namespace WFDesigner
{
    public partial class DocActivityDesigner
    {
        public DocActivityDesigner()
        {
            InitializeComponent();
        }


    }
}

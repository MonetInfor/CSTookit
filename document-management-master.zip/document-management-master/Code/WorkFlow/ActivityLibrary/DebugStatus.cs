﻿namespace ActivityLibrary
{
    public class DebugStatus
    {
        public int status = 0; //0，正常执行 ； 1，调试模式
    }
}

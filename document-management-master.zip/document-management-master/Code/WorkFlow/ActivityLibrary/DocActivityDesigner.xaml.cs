﻿
namespace ActivityLibrary
{
    public partial class DocActivityDesigner
    {
        public DocActivityDesigner()
        {
            InitializeComponent();
        }


    }
}

﻿// Assembly Model, Version 0.0.0.0

[assembly: System.Reflection.AssemblyFileVersion("1.0.0.0")]
[assembly: System.Runtime.InteropServices.Guid("91b821a9-63d6-44c9-ba17-da72248418cd")]
[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Reflection.AssemblyCopyright("版权所有 (C) WwW.TNIdea.CoM 2010")]
[assembly: System.Reflection.AssemblyProduct("Model")]
[assembly: System.Reflection.AssemblyCompany("WwW.TNIdea.CoM")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyDescription("")]
[assembly: System.Reflection.AssemblyTitle("Model")]
[assembly: System.Diagnostics.Debuggable(System.Diagnostics.DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows=true)]


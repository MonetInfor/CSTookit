document-management
==============

A document management system based on windows workflow foundation (WF4.0).

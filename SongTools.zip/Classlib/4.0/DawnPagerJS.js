﻿/*----------------------------------------------------------
----    数据分页
----  1.strUrl 数据获取路径地址
----  2.pageNumber 当前数据分页页码
----  3.parameter 附加参数，格式必须为单个或键值对：
[5] 或 'uid,1,uname,admin'
------------------------------------------------------------
DawnPagerMvc('/Home/Index/', 1, 'uid,1,uname,admin')
----------------------------------------------------------*/
function DawnPagerHandler(strUrl, pageNumber, parameter) {
    parameter = parameter.split(',');
    var objData;
    if (parameter == undefined || parameter == 'undefined' || parameter == null || parameter == '') {
        objData = { pager: pageNumber };
    }
    else if (parameter.length == 2) {
        objData = '({"pager":';
        objData += '"';
        objData += pageNumber;
        objData += '"';
        objData += ',';
        objData += '"';
        objData += parameter[0];
        objData += '":"';
        objData += parameter[1];
        objData += '"';
        objData += '})';
        objData = eval(objData);
    }
    else if (parameter.length > 2 && parameter.length % 2 == 0) {
        objData = '({"pager":';
        objData += '"';
        objData += pageNumber;
        objData += '"';
        for (var i = 0; i < parameter.length / 2; i += 2) {
            objData += ',';
            objData += '"';
            objData += parameter[i];
            objData += '":';
            objData += '"';
            objData += parameter[i + 1];
            objData += '"';
        }
        objData += '})';
        objData = eval(objData);
    }
    $.ajax({
        url: strUrl
		, data: objData
		, type: 'POST'
		, success: function (data) {
		    $('#dataShowArea').html($(data).find('#dataShowArea').html());
		    $('#pagerList').html($(data).find('#pagerList').html());
		}
		, error: function (msg) {
		    //alert('获取分页数据时出现未知异常！请重试或联系管理员！');
		    popMsg1('获取分页数据时出现未知异常！请重试或联系管理员！');
		}
    });
}
/*----------------------------------------------------------
----    数据分页
----  1.strUrl 数据获取路径地址
----  2.pageNumber 当前数据分页页码
----  3.parameter 附加参数，格式必须为单个或键值对：
[5] 或 'uid,1,uname,admin'
------------------------------------------------------------
DawnPagerMvc('/Home/Index/', 1, 'uid,1,uname,admin')
----------------------------------------------------------*/
function DawnPagerMvc(strUrl, pageNumber, parameter) {
    parameter = parameter.split(',');
    var objData;
    if (parameter == undefined || parameter == 'undefined' || parameter == null || parameter == '') {
        objData = { id: pageNumber };
    }
    else if (parameter.length > 1 && parameter.length % 2 == 0) {
        objData = '({"pager":';
        objData += '"';
        objData += pageNumber;
        objData += '"';
        for (var i = 0; i < parameter.length; i += 2) {
            objData += ',';
            objData += '"';
            objData += parameter[i];
            objData += '":';
            objData += '"';
            objData += parameter[i + 1];
            objData += '"';
        }
        objData += '})';
        objData = eval(objData);
    }
    else {
        objData = { id: parameter[0], pager: pageNumber };
    }
    $.ajax({
        url: strUrl
        , data: objData
        , type: 'POST'
        , success: function (data) {
            $('#dataShowArea').html($(data).find('#dataShowArea').html());
            $('#pagerList').html($(data).find('#pagerList').html());
        }
        , error: function (msg) {
            //alert('获取分页数据时出现未知异常！请重试或联系管理员！');
            popMsg1('获取分页数据时出现未知异常！请重试或联系管理员！');
        }
    });
}
/*----------------------------------------------------------
----    数据分页
----  1.strUrl 数据获取路径地址
----  2.pageNumber 当前数据分页页码
----  3.parameter 附加参数，格式必须为单个或键值对：
[5] 或 'uid,1,uname,admin'
------------------------------------------------------------
DawnPagerMvc('/Home/Index/', 1, 'uid,1,uname,admin')
----------------------------------------------------------*/
function DawnPagerUrl(strUrl, pageNumber, parameter) {
    if (strUrl.substr(strUrl.length - 1) != '/') strUrl += '/';
    parameter = parameter.split(',');
    if (parameter == undefined || parameter == 'undefined' || parameter == null || parameter == '') {
        strUrl += pageNumber;
    }
    else if (parameter.length > 1) {
        strUrl += pageNumber;
        for (var i = 0; i < parameter.length; i++) {
            strUrl += '/';
            strUrl += parameter[0];
        }
    }
    else {
        strUrl += pageNumber;
        strUrl += '/';
        strUrl += parameter[i];
    }
    alert(strUrl);
    $.ajax({
        url: strUrl
        , type: 'POST'
        , success: function (data) {
            $('#dataShowArea').html($(data).find('#dataShowArea').html());
            $('#pagerList').html($(data).find('#pagerList').html());
        }
        , error: function (msg) {
            //alert('获取分页数据时出现未知异常！请重试或联系管理员！');
            popMsg1('获取分页数据时出现未知异常！请重试或联系管理员！');
        }
    });
}
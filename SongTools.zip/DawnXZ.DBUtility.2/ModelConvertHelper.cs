﻿// =================================================================== 
// 通用数据库(DawnXZ.DBUtility)操作项目
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：ModelConvertHelper.cs
// 项目名称：通用数据库操作层
// 创建时间：2012年08月01日 20:59:52
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;

namespace DawnXZ.DBUtility
{
    /// <summary>
    /// 实体转换辅助类
    /// <remarks>
    /// 实体中的名称必须与DataTable中的名称保持一致
    /// </remarks>
    /// </summary>
    /// <typeparam name="T">数据泛型</typeparam>
    public class ModelConvertHelper<T> where T : new()
    {
        /// <summary>
        /// 数据表转实体
        /// </summary>
        /// <param name="dt">数据表集合</param>
        /// <returns>数据泛型集合</returns>
        public static IList<T> ConvertToModel(DataTable dt)
        {
            //定义集合
            IList<T> ts = new List<T>();
            //获得此模型的类型
            Type type = typeof(T);
            string tempName = "";
            foreach (DataRow dr in dt.Rows)
            {
                T t = new T();
                //获得此模型的公共属性
                PropertyInfo[] propertys = t.GetType().GetProperties();
                foreach (PropertyInfo pi in propertys)
                {
                    tempName = pi.Name;
                    //检查DataTable是否包含此列 
                    if (dt.Columns.Contains(tempName))
                    {
                        //判断此属性是否有Setter
                        if (!pi.CanWrite) continue;
                        object value = dr[tempName];
                        if (value != DBNull.Value) pi.SetValue(t, value, null);
                    }
                }
                ts.Add(t);
            }
            return ts;
        }
    }
}

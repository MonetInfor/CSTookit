﻿// =================================================================== 
// 通用数据库(DawnXZ.DBUtility)操作项目
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：Conn.cs
// 项目名称：通用数据库操作层
// 创建时间：2010-12-24
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System;
using System.Web;
using System.Configuration;

namespace DawnXZ.DBUtility
{
    /// <summary>
    /// The Conn class 
    /// </summary>
    public static class DawnConnectionString
    {

        #region 数据库连接字符串

        #region Sql Server
        //public static readonly string SqlConnString = System.Configuration.ConfigurationManager.ConnectionStrings["strConnection"].ConnectionString;
        /// <summary>
        /// Sql Server 连接字符串
        /// 默认名称：strConnection
        /// </summary>
        /// <param name="KeyName">键值名称</param>
        /// <returns>连接字符串</returns>
        public static string SqlConnString(string KeyName)
        {
            string tmp = null;
            if (!string.IsNullOrEmpty(KeyName))
            {
                tmp = ConfigurationManager.ConnectionStrings[KeyName].ConnectionString;
            }
            else
            {
                tmp = ConfigurationManager.ConnectionStrings["strConnection"].ConnectionString;
            }
            return tmp;
        }
        #endregion Sql Server

        #region Sql Server CE
        //public static readonly string SqlCEConnString = string.Format(@"Data Source={0};pwd={1};", "sdfPath", "sdfPwd");
        /// <summary>
        /// Sql Server SDF 连接字符串
        /// </summary>
        /// <param name="sdfPath">SDF 文件路径</param>
        /// <param name="sdfPwd">SDF 密码</param>
        /// <returns>连接字符串</returns>
        public static string SqlCEConnString(string sdfPath, string sdfPwd)
        {
            return string.Format(@"Data Source={0};pwd={1};", sdfPath, sdfPwd);
        }
        #endregion Sql Server WTS

        #region OleDB
        //public static readonly string OleConnString = string.Format(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0}", AppDomain.CurrentDomain.BaseDirectory + ConfigurationSettings.AppSettings["OleDbName"]);
        /// <summary>
        /// OleDB (Access) 连接字符串
        /// 调用时请对此方法特别调用
        /// </summary>
        /// <param name="IsRelative">相对路径</param>
        /// <param name="OleDbPath">Access 文件路径</param>
        /// <param name="OleUid">文件名称</param>
        /// <param name="OlePwd">密码(无输入null)</param>
        /// <returns>连接字符串</returns>
        public static string OleConnString(bool IsRelative, string OleDbPath, string OleUid, string OlePwd)
        {
            string tmp = null;
            if (IsRelative)
            {
                tmp = string.Format(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};", HttpContext.Current.Server.MapPath(OleDbPath));
            }
            else
            {
                tmp = string.Format(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};", OleDbPath);
            }
            if (!string.IsNullOrEmpty(OleUid))
            {
                tmp += string.Format("uid={0};", OleUid);
            }
            if (!string.IsNullOrEmpty(OlePwd))
            {
                tmp += string.Format("pwd={0};", OlePwd);
            }
            return tmp;
        }
        #endregion OleDB

        #region ODBC
        //public static readonly string OdbcConnString = string.Format(@"Dsn={0};Uid={1};Pwd={2};maxbuffersize=10240;pagetimeout=60;ReadOnly=1;", "OdbcName", "uid", "pwd");
        /// <summary>
        /// ODBC 连接字符串
        /// 调用时请对此方法特别调用
        /// </summary>
        /// <param name="readonlyflg">是否只读</param>
        /// <param name="OdbcName">ODBC 名称</param>
        /// <param name="OdbcUid">ODBC 用户名</param>
        /// <param name="OdbcPwd">ODBC 密码</param>
        /// <returns>连接字符串</returns>
        public static string OdbcConnString(bool readonlyflg, string OdbcName, string OdbcUid, string OdbcPwd)
        {
            string tmp = null;
            tmp = string.Format(@"maxbuffersize=10240;pagetimeout=60;Dsn={0};", OdbcName);
            if (readonlyflg)
            {
                tmp += "ReadOnly=1;";
            }
            if (!string.IsNullOrEmpty(OdbcUid))
            {
                tmp += string.Format("uid={0};", OdbcUid);
            }
            if (!string.IsNullOrEmpty(OdbcPwd))
            {
                tmp += string.Format("pwd={0};", OdbcPwd);
            }
            return tmp;
        }
        #endregion ODBC

        #region SQLite
        //public static readonly string SQLiteConnString = string.Format(@"Data Source={0};Pooling=true;FailIfMissing=false", "SQLitePath");
        /// <summary>
        /// SQLite 连接字符串
        /// 调用时请对此方法特别调用
        /// </summary>
        /// <param name="sqlitePath">SQLite 文件路径</param>
        /// <returns></returns>
        public static string SQLiteConnString(string sqlitePath)
        {
            return string.Format(@"Data Source={0};Pooling=true;FailIfMissing=false", sqlitePath);
        }
        #endregion SQLite

        #endregion 数据库连接字符串

    }
}

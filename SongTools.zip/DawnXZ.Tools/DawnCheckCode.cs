﻿// =================================================================== 
// 【宋】常用工具集（DawnXZ.Tools）合集
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：DawnCheckCode.cs
// 项目名称：【宋】常用工具集
// 创建时间：2013-02-12 19:05
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System;
using System.IO;
using System.Text;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

namespace DawnXZ.Tools
{
    /// <summary>
    /// 图片式验证码
    /// <remarks>
    /// <para>
    /// Response.ClearContent();
    /// </para>
    /// <para>
    /// Response.ContentType = "image/Gif";
    /// </para>
    /// <para>
    /// Response.BinaryWrite(ms.ToArray());
    /// </para>
    /// </remarks>
    /// </summary>
    public class DawnCheckCode
    {

        #region 成员方法

        #region 随机生成验证码·中文

        /// <summary>
        /// 随机生成验证码
        /// <para>中文</para>
        /// </summary>
        /// <param name="codeNum">验证码长度</param>
        /// <returns>验证码</returns>
        public static string CreateCodeOfChs(int codeNum)
        {
            string checkCode = String.Empty;
            string chinese = "居的一是在不了有和人这中大为上个国我以要他时来用们生到作地于出就分对成会可主发年动同工也能下过子说产种面而方后多定行学法所民得经十三之进着等部度家电力里如水化高自二理起小物现实加量都两体制机当使点从业本去把性好应开它合还因由其些然前外天政四日那社义事平形相全表间样与关各重新线内数正心反你明看原又么利比或但质气第向道命此变条只没结解问意建月公无系军很情者最立代想已通并提直题党程展五果料象员革位入常文总次品式活设及管特件长求老头基资边流路级少图山统接知较将组见计别她手角期根论运农指几九区强放决西被干做必战先回则任取据处队南给色光门即保治北造百规热领七海口东导器压志世金增争济阶油思术极交受联什认六共权收证改清己美再采转更单风切打白教速花带安场身车例真务具万每目至达走积示议声报斗完类八离华名确才科张信马节话米整空元况今集温传土许步群广石记需段研界拉林律叫且究观越织装影算低持音众书布复容儿须际商非验连断深难近矿千周委素技备半办青省列习响约支般史感劳便团往酸历市克何除消构府称太准精值号率族维划选标写存候毛亲快效斯院查江型眼王按格养易置派层片始却专状育厂京识适属圆包火住调满县局照参红细引听该铁价严";
            Random random = new Random();
            for (int i = 0; i < codeNum; i++)
            {
                checkCode += chinese.Substring(random.Next(0, chinese.Length), 1);
            }
            return checkCode;
        }
        /// <summary>
        /// 随机生成验证码
        /// <para>区位码</para>
        /// </summary>
        /// <param name="codeNum">验证码长度</param>
        /// <returns>验证码</returns>
        public static string CreateCodeOfPosition(int codeNum)
        {
            string checkCode = String.Empty;
            Encoding gb = Encoding.GetEncoding("gb2312");
            object[] bytes = GetCodeOfPosition(codeNum);
            for (int i = 0; i < codeNum; i++)
            {
                checkCode += gb.GetString(Convert.ChangeType(bytes[i], typeof(byte[])) as byte[]);
            }
            return checkCode;
        }
        /// <summary>
        /// 随机生成验证码
        /// <remarks>
        /// <para>每循环一次产生一个含两个元素的十六进制字节数组，并将其放入数组中</para>
        /// <para>每个汉字有四个区位码组成</para>
        /// <para>区位码第1位和区位码第2位作为字节数组第一个元素 </para>
        /// <para>区位码第3位和区位码第4位作为字节数组第二个元素</para>
        /// </remarks>
        /// </summary>
        /// <param name="strlength">验证码长度</param>
        /// <returns>验证码字节数组</returns>
        private static object[] GetCodeOfPosition(int strlength)
        {
            string[] rBase = new String[16] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f" };
            Random rnd = new Random();
            object[] bytes = new object[strlength];
            for (int i = 0; i < strlength; i++)
            {
                //区位码第1位 
                int r1 = rnd.Next(11, 14);
                string str_r1 = rBase[r1].Trim();
                //区位码第2位 
                rnd = new Random(r1 * unchecked((int)DateTime.Now.Ticks) + i);//更换随机数发生器的
                //种子避免产生重复值 
                int r2;
                if (r1 == 13)
                {
                    r2 = rnd.Next(0, 7);
                }
                else
                {
                    r2 = rnd.Next(0, 16);
                }
                string str_r2 = rBase[r2].Trim();
                //区位码第3位 
                rnd = new Random(r2 * unchecked((int)DateTime.Now.Ticks) + i);
                int r3 = rnd.Next(10, 16);
                string str_r3 = rBase[r3].Trim();
                //区位码第4位 
                rnd = new Random(r3 * unchecked((int)DateTime.Now.Ticks) + i);
                int r4;
                if (r3 == 10)
                {
                    r4 = rnd.Next(1, 16);
                }
                else if (r3 == 15)
                {
                    r4 = rnd.Next(0, 15);
                }
                else
                {
                    r4 = rnd.Next(0, 16);
                }
                string str_r4 = rBase[r4].Trim();
                //定义两个字节变量存储产生的随机汉字区位码 
                byte byte1 = Convert.ToByte(str_r1 + str_r2, 16);
                byte byte2 = Convert.ToByte(str_r3 + str_r4, 16);
                //将两个字节变量存储在字节数组中 
                byte[] str_r = new byte[] { byte1, byte2 };
                //将产生的一个汉字的字节数组放入object数组中 
                bytes.SetValue(str_r, i);
            }
            return bytes;
        }

        #endregion

        #region 随机生成验证码·英文

        /// <summary>
        /// 随机生成验证码
        /// <para>英文和数字</para>
        /// </summary>
        /// <param name="codeNum">验证码长度</param>
        /// <returns>验证码</returns>
        public static string CreateCodeOfEng(int codeNum)
        {
            int rand;
            char code;
            string checkCode = String.Empty;
            //生成一定长度的验证码
            System.Random random = new Random();
            for (int i = 0; i < codeNum; i++)
            {
                rand = random.Next();
                if (rand % 3 == 0)
                {
                    code = (char)('A' + (char)(rand % 26));
                }
                else
                {
                    code = (char)('0' + (char)(rand % 10));
                }
                checkCode += code.ToString();
            }
            return checkCode;
        }

        #endregion

        #region 随机生成验证码·中文和英文及数字

        /// <summary>
        /// 随机生成验证码
        /// <para>中文和英文及数字</para>
        /// <para>使用区位码中文</para>
        /// <para>包含特殊字符</para>
        /// </summary>
        /// <param name="codeNum">验证码长度</param>
        /// <returns>验证码</returns>
        public static string CreateCodeOfAll(int codeNum)
        {
            return CreateCodeOfAll(codeNum, true, true);
        }
        /// <summary>
        /// 随机生成验证码
        /// <para>中文和英文及数字</para>
        /// </summary>
        /// <param name="codeNum">验证码长度</param>
        /// <param name="isPosition">是否使用区位码中文</param>
        /// <param name="innerSpchar">是否包含特殊字符</param>
        /// <returns>验证码</returns>
        public static string CreateCodeOfAll(int codeNum, bool isPosition, bool innerSpchar)
        {
            StringBuilder result = new StringBuilder();
            if (isPosition)
            {
                result.Append(CreateCodeOfPosition(codeNum));
            }
            else
            {
                result.Append(CreateCodeOfChs(codeNum));
            }
            result.Append(CreateCodeOfEng(codeNum));
            if (innerSpchar) result.Append("!@#$%^&*()");
            Random random = new Random();
            StringBuilder temp = new StringBuilder();
            int index = 0;
            while (true)
            {
                index = random.Next(0, result.Length - 1);
                temp.Append(result[index]);
                result.Remove(index, 1);
                if (result.Length <= 0) break;
            }
            for (int j = 0; j < codeNum; j++)
            {
                index = random.Next(0, temp.Length - 1);
                result.Append(temp[index]);
                temp.Remove(index, 1);
            }
            return result.ToString(); ;
        }

        #endregion

        #region 产生波形滤镜效果

        /// <summary>
        /// PI值1
        /// </summary>
        private const double PI1 = 3.1415926535897932384626433832795;
        /// <summary>
        /// PI值2
        /// </summary>
        private const double PI2 = 6.283185307179586476925286766559;
        /// <summary>
        /// 产生波形滤镜效果
        /// </summary>
        /// <param name="srcBmp">源图像</param>
        /// <param name="bXDir">true 高度 / false 宽度</param>
        /// <param name="dMultValue">倍数</param>
        /// <param name="dPhase">相位</param>
        /// <param name="flgPI">PI值[单倍/双倍]</param>
        /// <returns>图片</returns>
        private static Bitmap WaveformToImage(Bitmap srcBmp, bool bXDir, double dMultValue, double dPhase, bool flgPI)
        {
            System.Drawing.Bitmap destBmp = new Bitmap(srcBmp.Width, srcBmp.Height);
            // 将位图背景填充为白色 
            System.Drawing.Graphics graph = System.Drawing.Graphics.FromImage(destBmp);
            graph.FillRectangle(new SolidBrush(System.Drawing.Color.White), 0, 0, destBmp.Width, destBmp.Height);
            graph.Dispose();
            double dBaseAxisLen = bXDir ? (double)destBmp.Height : (double)destBmp.Width;
            for (int i = 0; i < destBmp.Width; i++)
            {
                for (int j = 0; j < destBmp.Height; j++)
                {
                    double dx = 0;
                    if (flgPI)
                    {
                        dx = bXDir ? (PI1 * (double)j) / dBaseAxisLen : (PI1 * (double)i) / dBaseAxisLen;
                    }
                    else
                    {
                        dx = bXDir ? (PI2 * (double)j) / dBaseAxisLen : (PI2 * (double)i) / dBaseAxisLen;
                    }
                    dx += dPhase;
                    double dy = Math.Sin(dx);
                    //取得当前点的颜色 
                    int nOldX = 0, nOldY = 0;
                    nOldX = bXDir ? i + (int)(dy * dMultValue) : i;
                    nOldY = bXDir ? j : j + (int)(dy * dMultValue);
                    System.Drawing.Color color = srcBmp.GetPixel(i, j);
                    if (nOldX >= 0 && nOldX < destBmp.Width && nOldY >= 0 && nOldY < destBmp.Height)
                    {
                        destBmp.SetPixel(nOldX, nOldY, color);
                    }
                }
            }
            return destBmp;
        }

        #endregion

        #region 建立图片式验证码

        /// <summary>
        /// 建立图片式验证码
        /// </summary>
        /// <param name="checkCode">验证码</param>
        /// <param name="isChs">是否为中文验证码</param>
        /// <returns>验证码图片</returns>
        public static byte[] CreateImageOfCheckCode(string checkCode, bool isChs)
        {
            return CreateImageOfStream(checkCode, isChs).ToArray();
        }
        /// <summary>
        /// 建立图片式验证码
        /// </summary>
        /// <param name="checkCode">验证码</param>
        /// <param name="isChs">是否为中文验证码</param>
        /// <returns>验证码图片</returns>
        public static Image CreateImageOfWinForm(string checkCode, bool isChs)
        {
            return Image.FromStream(CreateImageOfStream(checkCode, isChs));
        }
        /// <summary>
        /// 建立图片式验证码
        /// </summary>
        /// <param name="checkCode">验证码</param>
        /// <param name="isChs">是否为中文验证码</param>
        /// <returns>流</returns>
        private static MemoryStream CreateImageOfStream(string checkCode, bool isChs)
        {
            if (checkCode == null) return null;
            int randAngle = 45; //随机转动角度范围
            int imgWidth = Convert.ToInt32(checkCode.Length * 23);
            Bitmap image = new Bitmap(imgWidth, 28); //创建图片背景
            Graphics graph = Graphics.FromImage(image);
            try
            {
                graph.Clear(Color.White); //清除画面，填充背景
                graph.DrawRectangle(new Pen(Color.Silver), 0, 0, image.Width - 1, image.Height - 1); //画图片的边框线
                //graph.SmoothingMode = SmoothingMode.AntiAlias; //图片的模式
                //生成随机生成器 
                Random random = new Random();
                //画图片的背景噪音线
                Pen noise = new Pen(Color.Silver);
                for (int i = 0; i < 12; i++)
                {
                    int x1 = random.Next(image.Width);
                    int x2 = random.Next(image.Width);
                    int y1 = random.Next(image.Height);
                    int y2 = random.Next(image.Height);
                    graph.DrawLine(noise, x1, y1, x2, y2);
                }
                //验证码旋转，防止机器识别
                char[] chars = checkCode.ToCharArray();//拆散字符串成单字符数组
                //文字居中
                StringFormat format = new StringFormat(StringFormatFlags.NoClip);
                format.Alignment = StringAlignment.Center;
                format.LineAlignment = StringAlignment.Center;
                //定义颜色
                Color[] colorStyle = { Color.Blue, Color.DarkRed, Color.DarkBlue, Color.MediumBlue };
                //定义字体
                string[] fontStyle = null;
                if (isChs)
                {
                    fontStyle = new string[] { "Microsoft YaHei", "隶书", "黑体" };
                }
                else
                {
                    fontStyle = new string[] { "Arial", "Comic Sans MS", "Microsoft Sans Serif", "Courier", "Microsoft YaHei" };
                }
                Font font = null;
                LinearGradientBrush brush = null;
                for (int i = 0; i < chars.Length; i++)
                {
                    font = new Font(fontStyle[random.Next(fontStyle.Length)], 14, FontStyle.Bold);//字体样式(参数2为字体大小)
                    brush = new LinearGradientBrush(new Rectangle(0, 0, image.Width, image.Height), colorStyle[random.Next(colorStyle.Length)], colorStyle[random.Next(colorStyle.Length)], 1.2F, true);
                    Point dot = new Point(16, 16);
                    //graph.DrawString(dot.X.ToString(),fontstyle,new SolidBrush(Color.Black),10,150);//测试X坐标显示间距的
                    float angle = random.Next(-randAngle, randAngle);//转动的度数
                    graph.TranslateTransform(dot.X, dot.Y);//移动光标到指定位置
                    graph.RotateTransform(angle);
                    graph.DrawString(chars[i].ToString(), font, brush, 1, 1, format);
                    graph.RotateTransform(-angle);//转回去
                    graph.TranslateTransform(2, -dot.Y);//移动光标到指定位置
                }
                //画图片的前景噪音点 100
                for (int i = 0; i < 50; i++)
                {
                    int x = random.Next(image.Width);
                    int y = random.Next(image.Height);
                    image.SetPixel(x, y, Color.FromArgb(random.Next()));
                }
                //产生波形滤镜效果
                image = WaveformToImage(image, true, 2, 2, true);
                //生成图片
                MemoryStream ms = new MemoryStream();
                image.Save(ms, ImageFormat.Gif);
                return ms;
            }
            finally
            {
                graph.Dispose();
                image.Dispose();
            }
        }

        #endregion

        #endregion

    }
}

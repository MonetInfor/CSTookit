﻿// =================================================================== 
// 【宋】常用工具集（DawnXZ.Tools）合集
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：DawnProcessRequest.cs
// 项目名称：【宋】常用工具集
// 创建时间：2010-09-04
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System.Web;
using System.Globalization;

namespace DawnXZ.Tools
{
    /// <summary>
    /// 线程请求相关
    /// </summary>
    public class DawnProcessRequest
    {

        #region 成员方法

        private static readonly string SqlStr = System.Configuration.ConfigurationManager.AppSettings["strSqlInjection"] as string;
        private static readonly string FlagStr = System.Configuration.ConfigurationManager.AppSettings["strSqlInjectionFlag"] as string;
        private static readonly string sqlErrorPage = System.Configuration.ConfigurationManager.AppSettings["strSqlInjectionErrPage"] as string;
        
        /// <summary>
        /// 用来识别是否是流的方式传输
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        bool IsUploadRequest(HttpRequest request)
        {
            return StringStartsWithAnotherIgnoreCase(request.ContentType, "multipart/form-data");
        }
        /// <summary>
        /// 比较内容类型
        /// </summary>
        /// <param name="s1"></param>
        /// <param name="s2"></param>
        /// <returns></returns>
        private static bool StringStartsWithAnotherIgnoreCase(string s1, string s2)
        {
            return (string.Compare(s1, 0, s2, 0, s2.Length, true, CultureInfo.InvariantCulture) == 0);
        }

        #region SQL注入式攻击代码分析

        /// <summary>
        /// 处理用户提交的请求
        /// </summary>
        public void StartProcessRequest()
        {
            HttpRequest Request = System.Web.HttpContext.Current.Request;
            HttpResponse Response = System.Web.HttpContext.Current.Response;
            try
            {
                string getkeys = "";
                if (IsUploadRequest(Request)) return;  //如果是流传递就退出
                //字符串参数
                if (Request.QueryString != null)
                {
                    for (int i = 0; i < Request.QueryString.Count; i++)
                    {
                        getkeys = Request.QueryString.Keys[i];                        
                        if (!ProcessSqlStr(Request.QueryString[getkeys].ToLower()))
                        //if (DawnValidator.IsSqlFilter(Request.QueryString[getkeys].ToLower()))
                        {
                            if (FlagStr == "yes")
                            {
                                Response.Redirect(sqlErrorPage + "?errmsg=QueryString中含有非法字符串&sqlprocess=true");
                            }
                            else
                            {
                                Response.Redirect(sqlErrorPage);
                            }
                            Response.End();
                        }
                    }
                }
                //form参数
                if (Request.Form != null)
                {
                    for (int i = 0; i < Request.Form.Count; i++)
                    {
                        getkeys = Request.Form.Keys[i];
                        if (!ProcessSqlStr(Request.Form[getkeys].ToLower()))
                        //if (DawnValidator.IsSqlFilter(Request.Form[getkeys].ToLower()))
                        {
                            if (FlagStr == "yes")
                            {
                                Response.Redirect(sqlErrorPage + "?errmsg=Form中含有非法字符串&sqlprocess=true");
                            }
                            else
                            {
                                Response.Redirect(sqlErrorPage);
                            }
                            Response.End();
                        }
                    }
                }
                //cookie参数
                if (Request.Cookies != null)
                {
                    for (int i = 0; i < Request.Cookies.Count; i++)
                    {
                        getkeys = Request.Cookies.Keys[i];
                        if (!ProcessSqlStr(Request.Cookies[getkeys].Value.ToLower()))
                        //if (DawnValidator.IsSqlFilter(Request.Cookies[getkeys].Value.ToLower()))
                        {
                            if (FlagStr == "yes")
                            {
                                Response.Redirect(sqlErrorPage + "?errmsg=Cookie中含有非法字符串&sqlprocess=true");
                            }
                            else
                            {
                                Response.Redirect(sqlErrorPage);
                            }
                            Response.End();
                        }
                    }
                }
            }
            catch
            {
                // 错误处理: 处理用户提交信息!
                Response.Clear();
                Response.Write("CustomErrorPage配置错误");
                Response.End();
            }
        }
        /// <summary>
        /// 分析用户请求是否正常
        /// 传入用户提交数据
        /// 返回是否含有SQL注入式攻击代码
        /// </summary>
        /// <param name="Str"></param>
        /// <returns></returns>
        private bool ProcessSqlStr(string Str)
        {
            bool ReturnValue = true;
            try
            {
                if (Str != "")
                {
                    string[] anySqlStr = SqlStr.Split('|');
                    foreach (string ss in anySqlStr)
                    {
                        if (Str.IndexOf(ss) >= 0)
                        {
                            ReturnValue = false;
                            break;
                        }
                    }
                }
            }
            catch
            {
                ReturnValue = false;
            }
            return ReturnValue;
        }
        #endregion SQL注入式攻击代码分析

        #endregion 成员方法

    }
}

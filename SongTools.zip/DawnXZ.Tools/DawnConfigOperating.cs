﻿// =================================================================== 
// 【宋】常用工具集（DawnXZ.Tools）合集
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：DawnConfigOperating.cs
// 项目名称：【宋】常用工具集
// 创建时间：2010-09-04
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System.Web;
using System.Configuration;

namespace DawnXZ.Tools
{
    /// <summary>
    /// Config 文件操作类
    /// </summary>
    public class DawnConfigOperating
    {

        #region 成员方法

        /// <summary>
        /// 构造函数
        /// </summary>
        public DawnConfigOperating()
        { }
        /// <summary>
        ///  获取批定 config 文件中的AppSettings参数或ConnectionString参数
        /// </summary>
        /// <param name="dataFlag">类型标记：true 为 AppSettings 值，false 为 ConnectionString 值</param>
        /// <param name="AppSettingsName">指定Web.config文件中的AppSettings键值</param>
        /// <param name="keyName">指定 config 文件中的AppSettings键值</param>
        /// <param name="dataDefaultValue">默认值</param>
        /// <returns></returns>
        public static string GetValue(bool dataFlag, string AppSettingsName, string keyName, string dataDefaultValue)
        {
            string strConfigFile = HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings[AppSettingsName]);
            try
            {
                if (dataFlag)
                {
                    return GetAppSettings(strConfigFile, keyName);
                }
                else
                {
                    return GetConnectionStrings(strConfigFile, keyName);
                }
            }
            catch
            {
                return dataDefaultValue;
            }
        }
        /// <summary>
        ///  获取批定 config 文件中的AppSettings参数或ConnectionString参数
        /// </summary>
        /// <param name="dataFlag">类型标记：true 为 AppSettings 值，false 为 ConnectionString 值</param>
        /// <param name="AppSettingsName">指定Web.config文件中的AppSettings键值</param>
        /// <param name="keyName">指定 config 文件中的AppSettings键值</param>
        /// <param name="NewValue">新值</param>
        /// <returns></returns>
        public static bool SetValue(bool dataFlag, string AppSettingsName, string keyName, string NewValue)
        {
            string strConfigFile = HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings[AppSettingsName]);
            try
            {
                Configuration objConfig = ConfigurationManager.OpenExeConfiguration(strConfigFile);
                if (dataFlag)
                {
                    objConfig.AppSettings.Settings[keyName].Value = NewValue;
                    objConfig.Save();
                }
                else
                {
                    objConfig.ConnectionStrings.ConnectionStrings[keyName].ConnectionString = NewValue;
                    objConfig.Save();
                }
                objConfig = null;
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 获取指定 config 文件中的全局参数
        /// </summary>
        /// <param name="strConfigPath"></param>
        /// <param name="strName"></param>
        /// <returns></returns>
        public static string GetAppSettings(string strConfigPath, string strName)
        {
            System.Configuration.Configuration objConfig = System.Configuration.ConfigurationManager.OpenExeConfiguration(strConfigPath);
            string strValues = objConfig.AppSettings.Settings[strName].Value;
            objConfig = null;
            return strValues;
        }
        /// <summary>
        /// 获取指定 config 文件中的连接字符串
        /// </summary>
        /// <param name="strConfigPath"></param>
        /// <param name="strName"></param>
        /// <returns></returns>
        public static string GetConnectionStrings(string strConfigPath, string strName)
        {
            System.Configuration.Configuration objConfig = System.Configuration.ConfigurationManager.OpenExeConfiguration(strConfigPath);
            string strValues = objConfig.ConnectionStrings.ConnectionStrings[strName].ConnectionString; ;
            objConfig = null;
            return strValues;
        }

        #endregion 成员方法

    }
}

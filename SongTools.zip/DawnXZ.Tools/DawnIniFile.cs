﻿// =================================================================== 
// 【宋】常用工具集（DawnXZ.Tools）合集
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：DawnIniFile.cs
// 项目名称：【宋】常用工具集
// 创建时间：2010-09-04
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System;
using System.Text;
using System.Runtime.InteropServices;
using System.IO;

namespace DawnXZ.Tools
{
    /// <summary>
    /// INI文件操作类
    /// </summary>
    public class DawnIniFile
    {
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileInt(string lpAppName, string lpKeyName, int nDefault, string lpFileName);
        [DllImport("kernel32")]
        //private static extern int GetPrivateProfileString(string lpAppName, string lpKeyName, string lpDefault, StringBuilder lpReturnedString, int nSize, string lpFileName);
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);
        [DllImport("kernel32")]
        //private static extern bool WritePrivateProfileString(string lpAppName, string lpKeyName, string lpString, string lpFileName);
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

        #region 成员方法

        /// <summary>
        /// 读取 int 型数据
        /// </summary>
        /// <param name="FFileName">文件绝对路径</param>
        /// <param name="section">项目名称( 如：[TypeName] )</param>
        /// <param name="key">键</param>
        /// <param name="def">缺省值</param>
        /// <returns>int</returns>
        public static int ReadInt(string FFileName, string section, string key, int def)
        {
            return GetPrivateProfileInt(section, key, def, FFileName);
        }
        /// <summary>
        /// 读取 string 型数据
        /// </summary>
        /// <param name="FFileName">文件绝对路径</param>
        /// <param name="section">项目名称( 如：[TypeName] )</param>
        /// <param name="key">键</param>
        /// <param name="def">缺省值</param>
        /// <returns>string</returns>
        public static string ReadString(string FFileName, string section, string key, string def)
        {
            StringBuilder temp = new StringBuilder(2048);
            GetPrivateProfileString(section, key, def, temp, 2048, FFileName);
            return temp.ToString();
        }
        /// <summary>
        /// 写入 int 型数据
        /// </summary>
        /// <param name="FFileName">文件绝对路径</param>
        /// <param name="section">项目名称( 如：[TypeName] )</param>
        /// <param name="key">键</param>
        /// <param name="iVal">缺省值</param>
        public static void WriteInt(string FFileName, string section, string key, int iVal)
        {
            WritePrivateProfileString(section, key, iVal.ToString(), FFileName);
        }
        /// <summary>
        /// 写入 string 型数据
        /// </summary>
        /// <param name="FFileName">文件绝对路径</param>
        /// <param name="section">项目名称( 如：[TypeName] )</param>
        /// <param name="key">键</param>
        /// <param name="strVal">缺省值</param>
        public static void WriteString(string FFileName, string section, string key, string strVal)
        {
            WritePrivateProfileString(section, key, strVal, FFileName);
        }
        /// <summary>
        /// 删除“键”
        /// </summary>
        /// <param name="FFileName">文件绝对路径</param>
        /// <param name="section">项目名称( 如：[TypeName] )</param>
        /// <param name="key">键</param>
        public static void DelKey(string FFileName, string section, string key)
        {
            WritePrivateProfileString(section, key, null, FFileName);
        }
        /// <summary>
        /// 删除“项目”
        /// </summary>
        /// <param name="FFileName">文件绝对路径</param>
        /// <param name="section">项目名称( 如：[TypeName] )</param>
        public static void DelSection(string FFileName, string section)
        {
            WritePrivateProfileString(section, null, null, FFileName);
        }

        #endregion 成员方法

        #region ..

        /// <summary>
        /// 写入INI文件
        /// </summary>
        /// <param name="inipath">INI文件路径</param>
        /// <param name="Section">项目名称(如 [TypeName] )</param>
        /// <param name="Key">键</param>
        /// <param name="Value">值</param>
        public static void IniWriteValue(string inipath, string Section, string Key, string Value)
        {
            WritePrivateProfileString(Section, Key, Value, inipath);
        }
        /// <summary>
        /// 读出INI文件
        /// </summary>
        /// <param name="inipath">INI文件路径</param>
        /// <param name="Section">项目名称(如 [TypeName] )</param>
        /// <param name="Key">键</param>
        public static string IniReadValue(string inipath, string Section, string Key)
        {
            StringBuilder temp = new StringBuilder(500);
            int i = GetPrivateProfileString(Section, Key, "", temp, 500, inipath);
            return temp.ToString();
        }

        #endregion

        /// <summary>
        /// 验证文件是否存在
        /// </summary>
        /// <param name="FFileName">文件绝对路径</param>
        /// <returns>布尔值</returns>
        public static bool ExistINIFile(string FFileName)
        {
            return File.Exists(FFileName);
        }
    }
}

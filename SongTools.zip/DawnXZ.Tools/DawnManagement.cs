﻿// =================================================================== 
// 【宋】常用工具集（DawnXZ.Tools）合集
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：DawnManagement.cs
// 项目名称：【宋】常用工具集
// 创建时间：2010-10-22
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System;
using System.Management;

namespace DawnXZ.Tools
{
    /// <summary>
    /// Computer Information
    /// 计算机信息，WinForm 专用
    /// </summary>
    public class DawnManagement
    {

        #region 成员方法

        #region .
        /// <summary>
        /// CPU序列号（ID）
        /// </summary>
        public string CpuID;
        /// <summary>
        /// 网卡MAC地址
        /// </summary>
        public string MacAddress;
        /// <summary>
        /// 硬盘序列号（ID）
        /// </summary>
        public string DiskID;
        /// <summary>
        /// 计算机IP地址
        /// </summary>
        public string IpAddress;
        /// <summary>
        /// 当前登录用户名名称
        /// </summary>
        public string LoginUserName;
        /// <summary>
        /// 计算机名称
        /// </summary>
        public string ComputerName;
        /// <summary>
        /// 系统型号（操作系统·版本号）
        /// </summary>
        public string SystemType;
        /// <summary>
        /// 总物理内存（单位：MB）
        /// </summary>
        public string TotalPhysicalMemory;
        /// <summary>
        /// 执行
        /// </summary>
        private static DawnManagement _instance;
        #endregion .

        /// <summary>
        /// 执行
        /// </summary>
        /// <returns></returns>
        public static DawnManagement Instance()
        {
            if (_instance == null)
                _instance = new DawnManagement();
            return _instance;
        }
        /// <summary>
        /// 计算机信息处理类
        /// </summary>
        protected DawnManagement()
        {
            CpuID = GetCpuID();
            MacAddress = GetMacAddress();
            DiskID = GetDiskID();
            IpAddress = GetIPAddress();
            LoginUserName = GetUserName();
            SystemType = GetSystemType();
            TotalPhysicalMemory = GetTotalPhysicalMemory();
            ComputerName = GetComputerName();
        }

        #region GetCpuID
        /// <summary>
        /// CPU序列号（ID）
        /// </summary>
        /// <returns></returns>
        string GetCpuID()
        {
            try
            {
                //获取CPU序列号代码
                string cpuInfo = "";//cpu序列号
                ManagementClass mc = new ManagementClass("Win32_Processor");
                ManagementObjectCollection moc = mc.GetInstances();
                foreach (ManagementObject mo in moc)
                {
                    cpuInfo = mo.Properties["ProcessorId"].Value.ToString();
                }
                moc = null;
                mc = null;
                return cpuInfo;
            }
            catch
            {
                return "Unknown";
            }
            finally { }
        }
        #endregion GetCpuID

        #region GetMacAddress
        /// <summary>
        /// 网卡MAC地址
        /// </summary>
        /// <returns></returns>
        string GetMacAddress()
        {
            try
            {
                //获取网卡Mac地址
                string mac = "";
                ManagementClass mc = new ManagementClass("Win32_NetworkAdapterConfiguration");
                ManagementObjectCollection moc = mc.GetInstances();
                foreach (ManagementObject mo in moc)
                {
                    if ((bool)mo["IPEnabled"] == true)
                    {
                        mac = mo["MacAddress"].ToString();
                        break;
                    }
                }
                moc = null;
                mc = null;
                return mac;
            }
            catch
            {
                return "Unknown";
            }
            finally { }
        }
        #endregion GetMacAddress

        #region GetIPAddress
        /// <summary>
        /// 计算机IP地址
        /// </summary>
        /// <returns></returns>
        string GetIPAddress()
        {
            try
            {
                //获取IP地址
                string st = "";
                ManagementClass mc = new ManagementClass("Win32_NetworkAdapterConfiguration");
                ManagementObjectCollection moc = mc.GetInstances();
                foreach (ManagementObject mo in moc)
                {
                    if ((bool)mo["IPEnabled"] == true)
                    {
                        //st=mo["IpAddress"].ToString();
                        System.Array ar;
                        ar = (System.Array)(mo.Properties["IpAddress"].Value);
                        st = ar.GetValue(0).ToString();
                        break;
                    }
                }
                moc = null;
                mc = null;
                return st;
            }
            catch
            {
                return "Unknown";
            }
            finally { }
        }
        #endregion GetIPAddress

        #region GetDiskID
        /// <summary>
        /// 硬盘序列号（ID）
        /// </summary>
        /// <returns></returns>
        string GetDiskID()
        {
            try
            {
                //获取硬盘ID
                String HDid = "";
                ManagementClass mc = new ManagementClass("Win32_DiskDrive");
                ManagementObjectCollection moc = mc.GetInstances();
                foreach (ManagementObject mo in moc)
                {
                    HDid = (string)mo.Properties["Model"].Value;
                }
                moc = null;
                mc = null;
                return HDid;
            }
            catch
            {
                return "Unknown";
            }
            finally { }
        }
        #endregion GetDiskID

        #region GetUserName
        /// <summary>
        /// 操作系统的登录用户名
        /// </summary>
        /// <returns></returns>
        string GetUserName()
        {
            try
            {
                string st = "";
                ManagementClass mc = new ManagementClass("Win32_ComputerSystem");
                ManagementObjectCollection moc = mc.GetInstances();
                foreach (ManagementObject mo in moc)
                {
                    st = mo["UserName"].ToString();
                }
                moc = null;
                mc = null;
                return st;
            }
            catch
            {
                return "Unknown";
            }
            finally { }
        }
        #endregion GetUserName

        #region GetSystemType
        /// <summary>
        /// PC类型
        /// </summary>
        /// <returns></returns>
        string GetSystemType()
        {
            try
            {
                string st = "";
                ManagementClass mc = new ManagementClass("Win32_ComputerSystem");
                ManagementObjectCollection moc = mc.GetInstances();
                foreach (ManagementObject mo in moc)
                {
                    st = mo["SystemType"].ToString();
                }
                moc = null;
                mc = null;
                return st;
            }
            catch
            {
                return "Unknown";
            }
            finally { }
        }
        #endregion GetSystemType

        #region GetTotalPhysicalMemory
        /// <summary>
        /// 物理内存
        /// </summary>
        /// <returns></returns>
        string GetTotalPhysicalMemory()
        {
            try
            {
                string st = "";
                ManagementClass mc = new ManagementClass("Win32_ComputerSystem");
                ManagementObjectCollection moc = mc.GetInstances();
                foreach (ManagementObject mo in moc)
                {
                    st = mo["TotalPhysicalMemory"].ToString();
                }
                moc = null;
                mc = null;
                return st;
            }
            catch
            {
                return "Unknown";
            }
            finally { }
        }
        #endregion GetTotalPhysicalMemory

        #region GetComputerName
        /// <summary>
        /// 计算机名称
        /// </summary>
        /// <returns></returns>
        string GetComputerName()
        {
            try
            {
                return System.Environment.GetEnvironmentVariable("ComputerName");
            }
            catch
            {
                return "Unknown";
            }
            finally { }
        }
        #endregion GetComputerName

        #endregion 成员方法

    }
}

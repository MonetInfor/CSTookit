﻿
// =================================================================== 
// 【宋】常用工具集（DawnXZ.Tools）合集
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：DawnEmail.cs
// 项目名称：【宋】常用工具集
// 创建时间：2010-09-04
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System;
using System.Text;
using System.Net;
using System.Net.Mail;

namespace DawnXZ.Tools
{
    /// <summary>
    /// 邮件发送工具类
    /// </summary>
    public class DawnEmail
    {

        #region Property
        /// <summary>
        /// SMTP主机
        /// </summary>
        public string Host { get; set; }
        /// <summary>
        /// SMTP主机端口
        /// </summary>
        public int Port { get; set; }
        /// <summary>
        /// 发件人
        /// </summary>
        public string From { get; set; }
        /// <summary>
        /// 收件人
        /// </summary>
        public string To { get; set; }
        /// <summary>
        /// 邮件主题
        /// </summary>
        public string Subject { get; set; }
        /// <summary>
        /// 邮件内容
        /// </summary>
        public string Body { get; set; }
        /// <summary>
        /// 抄送
        /// </summary>
        public string Cc { get; set; }
        /// <summary>
        /// 密送
        /// </summary>
        public string Bcc { get; set; }
        /// <summary>
        /// 访问SMTP服务器的用户名
        /// </summary>
        public string SmtpUsername { get; set; }
        /// <summary>
        /// 访问SMTP服务器的用户密码
        /// </summary>
        public string SmtpPassword { get; set; }
        #endregion Property

        #region 成员方法
        /// <summary>
        /// 地址格式：address,displayName
        /// </summary>
        public MailAddress ParseAddress(string addressString)
        {
            string[] addressArray = addressString.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
            if (addressArray.Length > 1)
            {
                return new MailAddress(addressArray[0], addressArray[1]);
            }
            else
            {
                return new MailAddress(addressArray[0]);
            }
        }
        /// <summary>
        /// 多个地址格式：address1;address2
        /// </summary>
        public void ParseAddressCollection(MailAddressCollection addressCollection, string addressCollectionString)
        {
            if (!string.IsNullOrEmpty(addressCollectionString))
            {
                MailAddress mailAddress;
                string[] addressCollectionArray = addressCollectionString.Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string addressString in addressCollectionArray)
                {
                    mailAddress = ParseAddress(addressString);
                    addressCollection.Add(mailAddress);
                }
            }
        }
        /// <summary>
        /// 发送邮件
        /// </summary>
        public void Send(bool isHTML)
        {
            // Create mail message 
            MailMessage message = new MailMessage();
            message.From = ParseAddress(this.From);
            ParseAddressCollection(message.To, this.To);
            ParseAddressCollection(message.CC, this.Cc);
            ParseAddressCollection(message.Bcc, this.Bcc);
            message.Subject = this.Subject;
            message.Body = this.Body;
            message.BodyEncoding = Encoding.GetEncoding(936);
            message.IsBodyHtml = isHTML;
            // Send email 
            SmtpClient client = new SmtpClient(this.Host, this.Port);
            if (!String.IsNullOrEmpty(this.SmtpUsername) && !String.IsNullOrEmpty(this.SmtpUsername))
            {
                client.Credentials = new NetworkCredential(this.SmtpUsername, this.SmtpUsername);
            }
            client.EnableSsl = false;
            client.Send(message);

        }
        /// <summary>
        /// 发送邮件，默认邮件格式为文本
        /// </summary>
        public void Send()
        {
            Send(false);
        }
        #endregion 成员方法

    }
}

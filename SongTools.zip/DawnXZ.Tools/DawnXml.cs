﻿// =================================================================== 
// 【宋】常用工具集（DawnXZ.Tools）合集
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：DawnXml.cs
// 项目名称：【宋】常用工具集
// 创建时间：2010-09-04
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System;
using System.Text;
using System.Xml;
using System.Data;
using System.IO;

namespace DawnXZ.Tools
{
    /// <summary>
    /// string strXmlFile = Server.MapPath("TestXml.xml");
    /// DawnXMLOP xmlTool = new DawnXMLOP(strXmlFile);
    /// 数据显示 条件：节点BID=1所有数据
    /// dgList.DataSource = xmlTool.GetData("Book/Authors[BID=\"1\"]").Tables[0];;
    /// dgList.DataBind();
    /// 更新元素內容 条件：节点BID=2
    /// xmlTool.Replace("Book/Authors[BID=\"2\"]/Content","ppppppp");
    /// xmlTool.Save();
    /// 添加一个新节点 条件：节点BID=4
    /// xmlTool.InsertNode("Book","Author","BID","4");
    /// xmlTool.InsertElement("Book/Author[BID=\"4\"]","Content","aaaaaaaaa");
    /// xmlTool.InsertElement("Book/Author[BID=\"4\"]","Title","Sex","man","iiiiiiii");
    /// xmlTool.Save();
    /// 删除一个指定节点的所有內容和属性 条件：节点BID=4
    /// xmlTool.Delete("Book/Author[BID=\"4\"]");
    /// xmlTool.Save();
    /// 删除一个指定节点的子节点 条件：节点BID内容为4
    /// xmlTool.Delete("Book/Authors[BID=\"4\"]");
    /// xmlTool.Save();
    /// 删除一个指定节点的子节点 条件：节点AuthorsBID的属性Booktype=9
    /// xmlTool.Delete("Book/Authors[@Booktype=\"9\"]");
    /// xmlTool.Save();
    /// </summary>
    public class DawnXml
    {

        #region 成员方法

        /// <summary>
        /// XML文件
        /// </summary>
        protected string strXmlFile;
        /// <summary>
        /// XML文档实例名
        /// </summary>
        protected XmlDocument objXmlDoc = new XmlDocument();
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="XmlFile"></param>
        public DawnXml(string XmlFile)
        {
            try
            {
                if (!File.Exists(XmlFile))
                {
                    CreatXmlFile(XmlFile);
                }
                objXmlDoc.Load(XmlFile);

            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            strXmlFile = XmlFile;
        }
        /// <summary>
        /// 创建XML文件
        /// </summary>
        /// <param name="file"></param>
        protected void CreatXmlFile(string file)
        {
            XmlTextWriter writer = new
            XmlTextWriter(file, Encoding.UTF8);

            // start writing!
            writer.WriteStartDocument();
            writer.WriteStartElement("Root");
            writer.WriteEndElement();
            writer.WriteEndDocument();
            writer.Close();
        }
        /// <summary>
        /// 查找数据。返回一个DataSet 多条 
        /// </summary>
        /// <param name="XmlPathNode">结点路径</param>
        /// <returns></returns>
        public DataSet GetData(string XmlPathNode)
        {
            //查找数据。返回一个DataSet 
            DataSet ds = new DataSet();
            //=========多个=================
            foreach (XmlNode xmlnode in objXmlDoc.SelectNodes(XmlPathNode))
            {
                StringReader read = new StringReader(xmlnode.OuterXml);
                ds.ReadXml(read);
            }
            //==============================
            return ds;
        }
        /// <summary>
        /// 查找数据。返回一个DataSet 单条
        /// </summary>
        /// <param name="XmlPathNode"></param>
        /// <returns></returns>
        public DataSet GetDataSingle(string XmlPathNode)
        {
            //查找数据。返回一个DataSet 
            DataSet ds = new DataSet();
            //==========单个================
            StringReader read = new StringReader(objXmlDoc.SelectSingleNode(XmlPathNode).OuterXml);
            ds.ReadXml(read);
            //==============================
            return ds;
        }
        /// <summary>
        /// 更新节点内容
        /// </summary>
        /// <param name="XmlPathNode"></param>
        /// <param name="Content"></param>
        public void Replace(string XmlPathNode, string Content)
        {
            //更新节点内容。 
            objXmlDoc.SelectSingleNode(XmlPathNode).InnerText = Content;
        }
        /// <summary>
        /// 删除一个节点
        /// </summary>
        /// <param name="Node"></param>
        public void Delete(string Node)
        {
            //删除一个节点。 
            string mainNode = Node.Substring(0, Node.LastIndexOf("/"));
            objXmlDoc.SelectSingleNode(mainNode).RemoveChild(objXmlDoc.SelectSingleNode(Node));
        }
        /// <summary>
        /// 插入一个节点和此节点的一子节点
        /// </summary>
        /// <param name="MainNode"></param>
        /// <param name="ChildNode"></param>
        /// <param name="Element"></param>
        /// <param name="Content"></param>
        public void InsertNode(string MainNode, string ChildNode, string Element, string Content)
        {
            //插入一个节点和此节点的一子节点。 
            XmlNode objRootNode = objXmlDoc.SelectSingleNode(MainNode);
            XmlElement objChildNode = objXmlDoc.CreateElement(ChildNode);
            objRootNode.AppendChild(objChildNode);
            XmlElement objElement = objXmlDoc.CreateElement(Element);
            objElement.InnerText = Content;
            objChildNode.AppendChild(objElement);
        }
        /// <summary>
        /// 插入一个节点,带一属性
        /// </summary>
        /// <param name="MainNode"></param>
        /// <param name="Element"></param>
        /// <param name="Attrib"></param>
        /// <param name="AttribContent"></param>
        /// <param name="Content"></param>
        public void InsertElement(string MainNode, string Element, string Attrib, string AttribContent, string Content)
        {
            //插入一个节点,带一属性。 
            XmlNode objNode = objXmlDoc.SelectSingleNode(MainNode);
            XmlElement objElement = objXmlDoc.CreateElement(Element);
            objElement.SetAttribute(Attrib, AttribContent);
            objElement.InnerText = Content;
            objNode.AppendChild(objElement);
        }
        /// <summary>
        /// 插入一个节点,不带属性
        /// </summary>
        /// <param name="MainNode"></param>
        /// <param name="Element"></param>
        /// <param name="Content"></param>
        public void InsertElement(string MainNode, string Element, string Content)
        {
            XmlNode objNode = objXmlDoc.SelectSingleNode(MainNode);
            XmlElement objElement = objXmlDoc.CreateElement(Element);
            objElement.InnerText = Content;
            objNode.AppendChild(objElement);
        }
        /// <summary>
        /// 保存文件
        /// </summary>
        public void Save()
        {
            //保存文件。 
            try
            {
                objXmlDoc.Save(strXmlFile);
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            objXmlDoc = null;
        }
        ///<summary>
        ///获取单个值
        ///</summary>
        public string Read(string path, string node, string attribute)
        {
            string value = "";
            try
            {
                XmlNode xn = objXmlDoc.SelectSingleNode(node);
                value = (attribute.Equals("") ? xn.InnerText : xn.Attributes[attribute].Value);
            }
            catch { }
            return value;
        }

        #endregion 成员方法

    }
}

﻿// =================================================================== 
// 【宋】常用工具集（DawnXZ.Tools）合集
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：DawnCookie.cs
// 项目名称：【宋】常用工具集
// 创建时间：2010-09-04
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System;
using System.Web;

namespace DawnXZ.Tools
{
    /// <summary>
    /// Cookie 操作
    /// </summary>
    public class DawnCookie
    {

        #region 成员方法

        #region 写 Cookie
        /// <summary>
        /// 写cookie值
        /// </summary>
        /// <param name="strName">名称</param>
        /// <param name="strValue">值</param>
        public static void WriteCookie(string strName, string strValue)
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies[strName];
            if (cookie == null) cookie = new HttpCookie(strName);
            cookie.Value = strValue;
            //cookie.Value = System.Web.HttpUtility.UrlEncode(strValue, System.Text.Encoding.GetEncoding("utf-8"));
            HttpContext.Current.Response.AppendCookie(cookie);
        }
        /// <summary>
        /// 写cookie值
        /// </summary>
        /// <param name="strName">名称</param>
        /// <param name="key">键</param>
        /// <param name="strValue">值</param>
        public static void WriteCookie(string strName, string key, string strValue)
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies[strName];
            if (cookie == null) cookie = new HttpCookie(strName);
            cookie[key] = strValue;
            //cookie.Value = System.Web.HttpUtility.UrlEncode(strValue, System.Text.Encoding.GetEncoding("utf-8"));
            HttpContext.Current.Response.AppendCookie(cookie);
        }
        /// <summary>
        /// 写cookie值
        /// </summary>
        /// <param name="strName">名称</param>
        /// <param name="strValue">值</param>
        /// <param name="expires">过期时间(分钟)</param>
        public static void CookieSet(string strName, string strValue, int expires)
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies[strName];
            if (cookie == null) cookie = new HttpCookie(strName);
            cookie.Value = strValue;
            //cookie.Value = System.Web.HttpUtility.UrlEncode(strValue, System.Text.Encoding.GetEncoding("utf-8"));
            cookie.Expires = DateTime.Now.AddMinutes(expires);
            HttpContext.Current.Response.AppendCookie(cookie);
        }
        #endregion 写 Cookie

        #region 写 Cookie 跨域
        /// <summary>
        /// 写cookie值（支持跨域名）
        /// </summary>
        /// <param name="strKey">Cookie 写入键</param>
        /// <param name="strValue">Cookie 写入值</param>
        /// <param name="expires">Cookie 过期时间（分钟）</param>
        /// <param name="strDomain">Cookie 跨域名设置（或主域名，如：dawnxz.com）</param>
        public static void CookieSet(string strKey, string strValue, int expires, string strDomain)
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies[strKey];
            if (cookie == null)
            {
                cookie = new HttpCookie(strKey);
            }
            cookie.Domain = strDomain;
            cookie.Path = "/";
            cookie.Value = strValue;
            //cookie.Value = System.Web.HttpUtility.UrlEncode(strValue, System.Text.Encoding.GetEncoding("utf-8"));
            cookie.Expires = DateTime.Now.AddMinutes(expires);
            HttpContext.Current.Response.AppendCookie(cookie);
        }
        /// <summary>
        /// 写cookie值（支持跨域名）
        /// </summary>
        /// <param name="cookieName">Cookie 名称</param>
        /// <param name="strKey">Cookie 写入键</param>
        /// <param name="strValue">Cookie 写入值</param>
        /// <param name="expires">Cookie 过期时间（分钟）</param>
        /// <param name="strDomain">Cookie 跨域名设置（或主域名，如：dawnxz.com）</param>
        public static void CookieSet(string cookieName, string strKey, string strValue, int expires, string strDomain)
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies[cookieName];
            if (cookie == null)
            {
                cookie = new HttpCookie(cookieName);
                cookie.Domain = strDomain;
                cookie.Path = "/";
                cookie.Values.Add(strKey, System.Web.HttpUtility.UrlEncode(strValue, System.Text.Encoding.GetEncoding("utf-8")));
                cookie.Expires = DateTime.Now.AddMinutes(expires);
                HttpContext.Current.Response.AppendCookie(cookie);
            }
            else
            {
                if (HttpContext.Current.Request.Cookies[cookieName].Values[strKey] != null)
                {
                    cookie.Values.Set(strKey, System.Web.HttpUtility.UrlEncode(strValue, System.Text.Encoding.GetEncoding("utf-8")));
                    cookie.Expires = DateTime.Now.AddMinutes(expires);
                }
                else
                {
                    cookie.Domain = strDomain;
                    cookie.Path = "/";
                    cookie.Values.Add(strKey, System.Web.HttpUtility.UrlEncode(strValue, System.Text.Encoding.GetEncoding("utf-8")));
                    cookie.Expires = DateTime.Now.AddMinutes(expires);
                    HttpContext.Current.Response.AppendCookie(cookie);
                }
            }
        }
        #endregion 写 Cookie 跨域

        #region 读 Cookie
        /// <summary>
        /// 读cookie值
        /// </summary>
        /// <param name="strName">名称</param>
        /// <returns>cookie值</returns>
        public static string CookieGet(string strName)
        {
            if (HttpContext.Current.Request.Cookies != null && HttpContext.Current.Request.Cookies[strName] != null)
            {
                return HttpContext.Current.Request.Cookies[strName].Value.ToString();
                //return System.Web.HttpUtility.UrlDecode(HttpContext.Current.Request.Cookies[strName].Value, System.Text.Encoding.GetEncoding("utf-8"));
            }
            return null;
        }
        /// <summary>
        /// 读cookie值（支持跨域名）
        /// </summary>
        /// <param name="cookieName">Cookie 名称</param>
        /// <param name="strKey">Cookie 写入键</param>
        /// <returns>返回 Cookie 值</returns>
        public static string CookieGet(string cookieName, string strKey)
        {
            if (HttpContext.Current.Request.Cookies != null && HttpContext.Current.Request.Cookies[cookieName] != null && HttpContext.Current.Request.Cookies[cookieName][strKey] != null)
            {
                return HttpContext.Current.Request.Cookies[cookieName][strKey].ToString();
            }
            return null;
        }
        #endregion 读 Cookie

        #endregion 成员方法

    }
}

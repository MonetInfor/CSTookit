﻿// =================================================================== 
// 【宋】常用工具集（DawnXZ.Tools）合集
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：DawnHDD.cs
// 项目名称：【宋】常用工具集
// 创建时间：2010-09-04
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System;
using System.Management;

namespace DawnXZ.Tools
{
    /// <summary>
    /// 获取硬盘相应分区的序列号
    /// </summary>
    public class DawnHDD
    {

        #region 成员方法
        /// <summary>
        /// 获取硬盘相应分区的序列号
        /// </summary>
        /// <returns></returns>
        public static string GetAllSerialNumber()
        {
            string Dri = "";
            ManagementClass mo = new ManagementClass("Win32_LogicalDisk");
            ManagementObjectCollection mc = mo.GetInstances();
            foreach (ManagementObject m in mc)
            {
                if (Convert.ToString(m.Properties["DriveType"].Value) == "3")
                {
                    Dri = Dri + m.Properties["VolumeSerialNumber"].Value.ToString() + "\n";
                }
            }
            Dri = Dri.Substring(0, Dri.Length - 1);
            return Dri;
        }
        /// <summary>
        /// 获取硬盘相应分区的序列号
        /// </summary>
        /// <param name="Drive">盘符（如 C）</param> 
        /// <returns></returns>
        public static string GetSpecialVolumeSerialNumber(string Drive)
        {
            string Dri = "";
            ManagementClass mo = new ManagementClass("Win32_LogicalDisk");
            ManagementObjectCollection mc = mo.GetInstances();
            foreach (ManagementObject m in mc)
            {
                if (Convert.ToString(m.Properties["DriveType"].Value) == "3")
                {
                    if (m.Properties["Name"].Value.ToString().ToUpper().Trim().Substring(0, 1) == Drive.ToUpper().Trim())
                    {
                        Dri = Dri + m.Properties["VolumeSerialNumber"].Value.ToString();
                        break;
                    }
                }
            }
            return Dri;
        }
        /// <summary>
        /// 获取MAC地址
        /// </summary>
        /// <returns></returns>
        public static string GetNetCardMacAddress()
        {
            ManagementClass mc;
            ManagementObjectCollection moc;
            mc = new ManagementClass("Win32_NetworkAdapterConfiguration");
            moc = mc.GetInstances();
            string str = "";
            foreach (ManagementObject mo in moc)
            {
                if ((bool)mo["IPEnabled"] == true) str += mo["MacAddress"].ToString();
            }
            return str;
        }
        #endregion 成员方法

    }
}

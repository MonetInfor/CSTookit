﻿// =================================================================== 
// 【宋】常用工具集（DawnXZ.Tools）合集
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：DawnPageElapse.cs
// 项目名称：【宋】常用工具集
// 创建时间：2010-09-04
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System;
using System.Web;

namespace DawnXZ.Tools
{
    /// <summary>
    /// 获取页面运行时间
    /// 在 Web.config 文件中的 <httpModules></httpModules> 中加入下面代码
    /// <add name="DawnXZ.Tools" type="DawnXZ.Tools.DawnPageElapse, DawnXZ.Tools" />
    /// 需要显示的地方加入下面代码
    /// <div datasrc="#PageElapseTime" datafld="ElapseTime"></div>
    /// </summary>
    public class DawnPageElapse : IHttpModule
    {
        /// <summary>
        /// 开始时间
        /// </summary>
        private DateTime _StartTime;
        /// <summary>
        /// 启动
        /// </summary>
        /// <param name="context"></param>
        public void Init(System.Web.HttpApplication context)
        {
            context.BeginRequest += new EventHandler(OnBeginRequest);
            context.EndRequest += new EventHandler(OnEndRequest);
        }
        /// <summary>
        /// 释放
        /// </summary>
        public void Dispose()
        {
        }
        /// <summary>
        /// 在开始时**
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnBeginRequest(object sender, EventArgs e)
        {
            _StartTime = DateTime.Now;
        }
        /// <summary>
        /// 在结束时**
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnEndRequest(object sender, EventArgs e)
        {
            TimeSpan ts = DateTime.Now - _StartTime;

            HttpContext.Current.Response.Write("<XML ID=PageElapseTime><Time><ElapseTime>页面执行时间：" + ts.TotalMilliseconds + "ms</ElapseTime></Time></XML>");
        }
    }
}

﻿// =================================================================== 
// 【宋】常用工具集（DawnXZ.Tools）合集
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：DawnPerfCounter.cs
// 项目名称：【宋】常用工具集
// 创建时间：2010-09-04
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System.Threading;
using System.Runtime.InteropServices;
using System.ComponentModel;

namespace DawnXZ.Tools
{
    /// <summary>
    /// 计时器
    /// </summary>
    public class DawnPerfCounter
    {

        #region 成员方法

        #region 私有变量
        private long freq;
        private long startTime, stopTime;
        #endregion 私有变量

        #region 私有方法
        [DllImport("Kernel32.dll")]
        private static extern bool QueryPerformanceFrequency(out long lpFrequency);
        [DllImport("Kernel32.dll")]
        private static extern bool QueryPerformanceCounter(out long lpPerformanceCount);
        #endregion 私有方法

        #region 构造方法
        /// <summary>
        /// 创建类的实例
        /// </summary>
        /// <param name="startTimer">是否立即执行Start()方法</param>
        public DawnPerfCounter(bool startTimer)
        {
            startTime = 0;
            stopTime = 0;
            if (QueryPerformanceFrequency(out freq) == false) throw new Win32Exception();//不支持高精度计时
            if (startTimer) Start();
        }
        #endregion 构造方法

        #region 公有方法
        /// <summary>
        /// 停止计数
        /// </summary>
        public void Stop()
        {
            QueryPerformanceCounter(out stopTime);
        }
        /// <summary>
        /// 开始计时
        /// </summary>
        public void Start()
        {
            Thread.Sleep(0);
            QueryPerformanceCounter(out startTime);
        }
        #endregion 公有方法

        #region 属性
        /// <summary>
        /// 返回运行时间，单位是秒
        /// </summary>
        /// <value>运行时间</value>
        public double Duration
        {
            get { return (double)(stopTime - startTime) / (double)freq; }
        }
        #endregion 属性

        #endregion 成员方法

    }
}

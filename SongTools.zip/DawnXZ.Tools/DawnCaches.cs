﻿// =================================================================== 
// 【宋】常用工具集（DawnXZ.Tools）合集
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：DawnCaches.cs
// 项目名称：【宋】常用工具集
// 创建时间：2010-09-04
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System;
using System.Collections;
using System.Web;
using System.Web.Caching;

namespace DawnXZ.Tools
{
    /// <summary>
    /// 缓存操作类
    /// </summary>
    public class DawnCaches
    {

        #region 成员方法
        /// <summary>
        /// 建立半小时不访问便移除的缓存
        /// </summary>
        /// <param name="key">缓存名称</param>
        /// <param name="value">缓存内容</param>
        /// <returns></returns>
        public static object TryAddCacheHalfhour(string key, object value)
        {
            return TryAddCache(key, value, 30);
        }
        /// <summary>
        /// 建立一小时不访问便移除的缓存
        /// </summary>
        /// <param name="key">缓存名称</param>
        /// <param name="value">缓存内容</param>
        /// <returns></returns>
        public static object TryAddCacheOnehour(string key, object value)
        {
            return TryAddCache(key, value, 60);
        }
        /// <summary>
        /// 建立定时不访问便移除的缓存
        /// </summary>
        /// <param name="key">缓存名称</param>
        /// <param name="value">缓存内容</param>
        /// <param name="times">超时时间，单位：分钟</param>
        /// <returns></returns>
        public static object TryAddCache(string key, object value, double times)
        {
            return TryAddCache(key, value, System.TimeSpan.FromMinutes(times), CacheItemPriority.Normal);
        }
        /// <summary>
        /// 建立缓存
        /// </summary>
        public static object TryAddCache(string key, object value, CacheItemPriority priority)
        {
            if (HttpRuntime.Cache[key] == null && value != null)
                return HttpRuntime.Cache.Add(key, value, null, Cache.NoAbsoluteExpiration, Cache.NoSlidingExpiration, priority, null);
            else
                return null;
        }
        /// <summary>
        /// 建立定时不访问便移除的缓存
        /// </summary>
        public static object TryAddCache(string key, object value, TimeSpan slidingExpiration, CacheItemPriority priority)
        {
            if (HttpRuntime.Cache[key] == null && value != null)
                return HttpRuntime.Cache.Add(key, value, null, Cache.NoAbsoluteExpiration, slidingExpiration, priority, null);
            else
                return null;
        }
        /// <summary>
        /// 建立缓存，并在移除时执行事件
        /// </summary>
        public static object TryAddCache(string key, object value, DateTime absoluteExpiration, TimeSpan slidingExpiration, CacheItemPriority priority, CacheItemRemovedCallback onRemovedCallback)
        {
            if (HttpRuntime.Cache[key] == null && value != null)
                return HttpRuntime.Cache.Add(key, value, null, absoluteExpiration, slidingExpiration, priority, onRemovedCallback);
            else
                return null;
        }
        /// <summary>
        /// 移除缓存
        /// </summary>
        public static object TryRemoveCache(string key)
        {
            if (HttpRuntime.Cache[key] != null)
                return HttpRuntime.Cache.Remove(key);
            else
                return null;
        }
        /// <summary>
        /// 移除键中带某关键字的缓存
        /// </summary>
        public static void RemoveMultiCache(string keyInclude)
        {
            IDictionaryEnumerator CacheEnum = HttpRuntime.Cache.GetEnumerator();
            while (CacheEnum.MoveNext())
            {
                if (CacheEnum.Key.ToString().IndexOf(keyInclude.ToString()) >= 0)
                    HttpRuntime.Cache.Remove(CacheEnum.Key.ToString());
            }
        }
        /// <summary>
        /// 移除所有缓存
        /// </summary>
        public static void RemoveAllCache()
        {
            IDictionaryEnumerator CacheEnum = HttpRuntime.Cache.GetEnumerator();
            while (CacheEnum.MoveNext())
            {
                HttpRuntime.Cache.Remove(CacheEnum.Key.ToString());
            }
        }
        #endregion 成员方法

    }
}

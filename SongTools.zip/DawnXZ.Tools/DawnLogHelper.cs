﻿// =================================================================== 
// 【宋】常用工具集（DawnXZ.Tools）合集
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：DawnLogHelper.cs
// 项目名称：【宋】常用工具集
// 创建时间：2012-09-18 22:40:18
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Globalization;
using System.Collections.Generic;
using System.Net.Sockets;

namespace DawnXZ.Tools
{
    /// <summary> 
    /// 日志记录器
    /// </summary> 
    /// <remarks>High performance log class</remarks> 
    public class DawnLogHelper : IDisposable
    {

        #region 成员字段

        /// <summary>
        /// 日志保存绝对路径
        /// </summary>
        private string _logPath;
        /// <summary>
        /// log life time sign
        /// </summary>
        private DateTime _timeSign;
        /// <summary>
        /// 文件操作流
        /// </summary>
        private StreamWriter _writers;
        /// <summary>
        /// 作用于文件操作锁定
        /// </summary>
        private object _writerLock;
        /// <summary>
        /// Log Message queue
        /// </summary>
        private Queue<DawnLogMessage> _logMessages;
        /// <summary> 
        /// Wait enqueue wirte log message semaphore will release 
        /// </summary> 
        private Semaphore _semaphore;
        /// <summary>
        /// log write file state
        /// </summary>
        private bool _state;
        /// <summary>
        /// 日志保存类型
        /// </summary>
        private DawnLogType _logType;
        /// <summary>
        /// 日志文件尾部标记
        /// </summary>
        private string _logTailTag;
        /// <summary>
        /// 错误发生次数
        /// </summary>
        private int _errorCounted;

        #endregion

        #region 成员属性

        /// <summary>
        /// 日志保存绝对路径
        /// </summary>
        public string LogPath
        {
            get { return this._logPath; }
        }
        /// <summary>
        /// 文件操作流
        /// </summary>
        internal StreamWriter Writers
        {
            get { return this._writers; }
        }
        /// <summary> 
        /// 日志保存类型
        /// </summary> 
        public DawnLogType LogType
        {
            get { return this._logType; }
        }        
        /// <summary>
        /// 日志文件尾部标记
        /// </summary>
        public string LogTailTag
        {
            get { return this._logTailTag; }
            set { this._logTailTag = value; }
        }
        
        #endregion

        #region 构造函数

        /// <summary>
        /// 初始化
        /// </summary>
        /// <param name="appPath">应用程序路径</param>
        /// <param name="logDirName">日志文件夹名称</param>
        /// <param name="logType">日志类型</param>
        private void Initialize(string appPath, string logDirName, DawnLogType logType)
        {
            if (this._logMessages == null)
            {
                this._logPath = Path.Combine(appPath, logDirName);
                DawnFileRelated.CreateDirectory(LogPath);
                this._timeSign = DateTime.Now.AddMinutes(60 - DateTime.Now.Minute);
                this._writerLock = new object();
                this._logMessages = new Queue<DawnLogMessage>();
                this._semaphore = new Semaphore(0, int.MaxValue, "DawnXZ");
                //this._semaphore = new Semaphore(0, int.MaxValue, Constants.LogSemaphoreName);
                this._state = true;
                this._logType = logType;
                this._logTailTag = null;
                this._errorCounted = 0;
                var thread = new Thread(Work) { IsBackground = true };
                thread.Start();
            }
        }
        /// <summary>
        /// 文件日志类
        /// 默认应用程序所在位置下的 logs 文件夹
        /// </summary>
        public DawnLogHelper()
        {
            Initialize(DawnFileRelated.AppPath, "logs", DawnLogType.Daily);
        }
        /// <summary>
        /// 文件日志类
        /// 默认应用程序所在位置
        /// </summary>
        /// <param name="logType">日志类型</param>
        public DawnLogHelper(DawnLogType logType)
        {
            Initialize(DawnFileRelated.AppPath, "logs", logType);
        }
        /// <summary>
        /// 文件日志类
        /// </summary>
        /// <param name="appPath">应用程序路径</param>
        /// <param name="logType">日志类型</param>
        public DawnLogHelper(string appPath, DawnLogType logType)
        {
            Initialize(appPath, "logs", logType);
        }
        /// <summary>
        /// 文件日志类
        /// </summary>
        /// <param name="appPath">应用程序路径</param>
        /// <param name="logDirName">日志文件夹名称</param>
        /// <param name="logType">日志类型</param>
        public DawnLogHelper(string appPath, string logDirName, DawnLogType logType)
        {
            Initialize(appPath, logDirName, logType);
        }                     

        #endregion

        #region 成员方法

        #region Queue handle

        /// <summary> 
        /// Write Log file work method
        /// <remarks>
        /// Determine log queue have record need wirte 
        /// </remarks>
        /// </summary> 
        private void Work()
        {
            while (true)
            {
                if (this._logMessages.Count > 0)
                {
                    FileWriteMessage();
                }
                else
                {
                    if (WaitLogMessage()) break;
                }
            }
        }
        /// <summary> 
        /// Write message to log file 
        /// </summary> 
        private void FileWriteMessage()
        {
            DawnLogMessage logMessage = null;
            lock (this._writerLock)
            {
                if (this._logMessages.Count > 0) logMessage = this._logMessages.Dequeue();
            }
            if (logMessage != null)
            {
                FileWrite(logMessage);
            }
        }
        /// <summary> 
        /// The thread wait a log message
        /// <remarks>
        /// determine log life time is true or false 
        /// </remarks>
        /// </summary> 
        /// <returns>is close or not</returns> 
        private bool WaitLogMessage()
        {
            if (this._state)
            {
                WaitHandle.WaitAny(new WaitHandle[] { this._semaphore }, -1, false);
                return false;
            }
            FileClose();
            return true;
        }

        #endregion

        #region 私有方法

        /// <summary> 
        /// Gets file name by log type 
        /// </summary> 
        /// <returns>log file name</returns> 
        private string GetFilename()
        {
            string tmpFileName = "";
            switch (LogType)
            {
                case DawnLogType.Hour:
                    tmpFileName = DawnFileRelated.GetFileByHour(false);
                    break;
                case DawnLogType.Daily:
                    tmpFileName = DawnFileRelated.GetFileByDate(true);
                    break;
                case DawnLogType.Monthly:
                    tmpFileName = DawnFileRelated.GetFileByMonth(true);
                    break;
                case DawnLogType.Annually:
                    tmpFileName = DawnFileRelated.GetFileByYear();
                    break;
            }
            if (!string.IsNullOrEmpty(LogTailTag))
            {
                tmpFileName += LogTailTag;
            }
            return string.Format("{0}.log", tmpFileName);
        }
        /// <summary> 
        /// Write log file message 
        /// <remarks>
        /// determine the log file is time sign 
        /// </remarks>
        /// </summary> 
        /// <param name="msg"></param> 
        private void FileWrite(DawnLogMessage msg)
        {
            if (this._errorCounted > 3) return;
            try
            {
                if (null == Writers) FileOpen();
                if (DateTime.Now >= this._timeSign)
                {
                    FileClose();
                    FileOpen();
                    this._timeSign = DateTime.Now.AddHours(1);
                }
                Writers.WriteLine(string.Format(@"{0} [{1}]  {2}", msg.Datetime.ToString("yyyy-MM-dd HH:mm:ss"), msg.Type, msg.Text));
                Writers.Flush();
                System.Threading.Thread.Sleep(10);
            }
            catch
            {
                this._errorCounted++;
                //Console.Out.Write(e);
            }
        }
        /// <summary> 
        /// Open log file write log message 
        /// </summary> 
        private void FileOpen()
        {
            this._writers = new StreamWriter(Path.Combine(LogPath, GetFilename()), true, Encoding.UTF8);
        }
        /// <summary> 
        /// Close log file 
        /// </summary> 
        private void FileClose()
        {
            if (this._writers != null)
            {
                this._writers.Flush();
                this._writers.Close();
                this._writers.Dispose();
                this._writers = null;
            }
        }

        #endregion

        #region 公共方法

        /// <summary> 
        /// Enqueue a new log message and release a semaphore 
        /// </summary> 
        /// <param name="msg">Log message</param> 
        public void Write(DawnLogMessage msg)
        {
            if (msg != null)
            {
                lock (this._writerLock)
                {
                    this._logMessages.Enqueue(msg);
                    this._semaphore.Release();
                }
            }
        }
        /// <summary> 
        /// Write message by message content and type 
        /// </summary> 
        /// <param name="text">log message</param> 
        public void Write(string text)
        {
            Write(new DawnLogMessage(text, DawnMessageType.Information));
        }
        /// <summary> 
        /// Write message by message content and type 
        /// </summary> 
        /// <param name="text">log message</param> 
        /// <param name="type">message type</param> 
        public void Write(string text, DawnMessageType type)
        {
            Write(new DawnLogMessage(text, type));
        }
        /// <summary> 
        /// Write Message by datetime and message content and type 
        /// </summary> 
        /// <param name="dateTime">datetime</param> 
        /// <param name="text">message content</param> 
        /// <param name="type">message type</param> 
        public void Write(DateTime dateTime, string text, DawnMessageType type)
        {
            Write(new DawnLogMessage(dateTime, text, type));
        }
        /// <summary> 
        /// Write message ty exception and message type 
        /// </summary> 
        /// <param name="ex">exception</param> 
        public void Write(Exception ex)
        {
            Write(new DawnLogMessage(ex.GetType().Name, DawnMessageType.Error));
            Write(new DawnLogMessage(ex.Message, DawnMessageType.Error));
            Write(new DawnLogMessage(ex.StackTrace, DawnMessageType.Error));
        }
        /// <summary> 
        /// Write message ty exception and message type 
        /// </summary> 
        /// <param name="ex">exception</param> 
        /// <param name="type">message type</param> 
        public void Write(Exception ex, DawnMessageType type)
        {
            Write(new DawnLogMessage(ex.GetType().Name, DawnMessageType.Error));
            Write(new DawnLogMessage(ex.Message, type));
            Write(new DawnLogMessage(ex.StackTrace, type));
        }
        /// <summary>
        /// 写日志
        /// </summary>
        /// <param name="ex">套接字错误消息</param>
        public void Write(SocketException ex)
        {
            Write(string.Format("{0}[{1}]", ex.SocketErrorCode, ex.ErrorCode), DawnMessageType.Error);
            Write(ex.GetType().Name, DawnMessageType.Error);
            Write(ex.Message, DawnMessageType.Error);
            Write(ex.StackTrace, DawnMessageType.Error);
        }
        /// <summary>
        /// 写日志
        /// </summary>
        /// <param name="ex">套接字错误消息</param>
        /// <param name="msgType">消息类型</param>
        public void Write(SocketException ex, DawnMessageType msgType)
        {
            Write(string.Format("{0}[{1}]", ex.SocketErrorCode, ex.ErrorCode), msgType);
            Write(ex.GetType().Name, msgType);
            Write(ex.Message, msgType);
            Write(ex.StackTrace, msgType);
        }

        #endregion

        #region IDisposable member

        /// <summary> 
        /// Dispose log 
        /// </summary> 
        public void Dispose()
        {
            if (Writers != null) FileClose();
            this._writers = null;
            this._state = false;
        }

        #endregion

        #endregion

    }

    #region DawnLogType

    /// <summary> 
    /// Log Type 
    /// </summary> 
    /// <remarks>Create log by daily or weekly or monthly or annually</remarks> 
    public enum DawnLogType
    {
        /// <summary>
        /// Create log by hour
        /// </summary>
        Hour,
        /// <summary> 
        /// Create log by daily 
        /// </summary> 
        Daily,
        /// <summary> 
        /// Create log by monthly 
        /// </summary> 
        Monthly,
        /// <summary> 
        /// Create log by annually 
        /// </summary> 
        Annually
    }

    #endregion

    #region DawnLogMessage

    /// <summary> 
    /// Log Message Class 
    /// </summary> 
    public class DawnLogMessage
    {

        #region 成员字段

        /// <summary>
        /// Gets or sets datetime 
        /// </summary>
        private DateTime _datetime;
        /// <summary>
        /// Gets or sets message content 
        /// </summary>
        private string _text;
        /// <summary>
        /// Gets or sets message type 
        /// </summary>
        private DawnMessageType _type;

        #endregion

        #region 成员属性

        /// <summary> 
        /// Gets or sets datetime 
        /// </summary> 
        public DateTime Datetime
        {
            get { return this._datetime; }
            set { this._datetime = value; }
        }
        /// <summary> 
        /// Gets or sets message content 
        /// </summary> 
        public string Text
        {
            get { return this._text; }
            set { this._text = value; }
        }
        /// <summary> 
        /// Gets or sets message type 
        /// </summary> 
        public DawnMessageType Type
        {
            get { return this._type; }
            set { this._type = value; }
        }

        #endregion

        #region 构造函数

        /// <summary> 
        /// Create Log message instance 
        /// </summary> 
        public DawnLogMessage()
            : this("", DawnMessageType.Unknown)
        { }
        /// <summary> 
        /// Crete log message by message content and message type 
        /// </summary> 
        /// <param name="text">message content</param> 
        /// <param name="messageType">message type</param> 
        public DawnLogMessage(string text, DawnMessageType messageType)
            : this(DateTime.Now, text, messageType)
        { }
        /// <summary> 
        /// Create log message by datetime and message content and message type 
        /// </summary> 
        /// <param name="dateTime">date time </param> 
        /// <param name="text">message content</param> 
        /// <param name="messageType">message type</param> 
        public DawnLogMessage(DateTime dateTime, string text, DawnMessageType messageType)
        {
            this._datetime = dateTime;
            this._type = messageType;
            this._text = text;
        }

        #endregion

        #region 成员方法

        /// <summary> 
        /// Get Message to string 
        /// </summary> 
        /// <returns></returns> 
        public new string ToString()
        {
            return Datetime.ToString(CultureInfo.InvariantCulture) + "\t" + Text + "\n";
        }

        #endregion

    }

    #endregion

    #region DawnMessageType

    /// <summary> 
    /// Log Message Type enum 
    /// </summary> 
    public enum DawnMessageType
    {
        /// <summary> 
        /// unknown type 
        /// </summary> 
        Unknown,
        /// <summary> 
        /// information type 
        /// </summary> 
        Information,
        /// <summary> 
        /// warning type 
        /// </summary> 
        Warning,
        /// <summary> 
        /// error type 
        /// </summary> 
        Error,
        /// <summary> 
        /// success type 
        /// </summary> 
        Success
    }

    #endregion

}

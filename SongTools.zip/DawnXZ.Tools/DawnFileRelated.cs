﻿// =================================================================== 
// 【宋】常用工具集（DawnXZ.Tools）合集
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：DawnFileRelated.cs
// 项目名称：【宋】常用工具集
// 创建时间：2011-06-14
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System;
using System.IO;

namespace DawnXZ.Tools
{
    /// <summary>
    /// 文件相关操作类
    /// </summary>
    public class DawnFileRelated
    {

        #region Variable
        /// <summary>
        /// 路径分割符
        /// </summary>
        private const string PATH_SPLIT_CHAR = "\\";
        #endregion Variable

        #region 成员方法

        #region 常规检测
        /// <summary>
        /// 返回文件是否存在
        /// </summary>
        /// <param name="filename">文件名</param>
        /// <returns>是否存在</returns>
        public static bool FileExists(string filename)
        {
            return System.IO.File.Exists(filename);
        }
        /// <summary>
        /// 获取指定文件的扩展名
        /// </summary>
        /// <param name="fileName">指定文件名</param>
        /// <returns>扩展名</returns>
        public static string GetFileExtName(string fileName)
        {
            if (string.IsNullOrEmpty(fileName) || fileName.IndexOf('.') <= 0) return "";
            fileName = fileName.ToLower().Trim();
            return fileName.Substring(fileName.LastIndexOf('.'), fileName.Length - fileName.LastIndexOf('.'));
        }
        #endregion 常规检测

        #region 图片检测
        /// <summary>
        /// 图片是否存在
        /// 默认返回 ~/images/none.jpg
        /// </summary>
        /// <param name="obj">Object</param>
        /// <param name="showPath">图片路径</param>
        /// <returns>Path</returns>
        public static string CheckImage(object obj, string showPath)
        {
            if (string.IsNullOrEmpty(obj.ToString()))
            {
                return "~/images/none.jpg";
            }
            else
            {
                if (System.IO.File.Exists(System.Web.HttpContext.Current.Server.MapPath(showPath) + obj.ToString()))
                {
                    return showPath + obj.ToString();
                }
                else
                {
                    return "~/images/none.jpg";
                }
            }
        }
        #endregion 图片检测

        #region Path & 路径
        /// <summary>
        /// 日志存放路径
        /// </summary>
        public static string LogPath
        {
            get { return Path.Combine(AppPath, "logs"); }
        }
        /// <summary>
        /// 应用程序路径
        /// </summary>
        public static string AppPath
        {
            get { return AppDomain.CurrentDomain.BaseDirectory; }
        }
        /// <summary>
        /// 应用程序路径
        /// </summary>
        public static string PathByFileName
        {
            get
            {
                return System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName;
            }
        }
        /// <summary>
        /// 应用程序路径
        /// </summary>
        public static string PathByCurrentDirectory
        {
            get
            {
                return Environment.CurrentDirectory;
            }
        }
        /// <summary>
        /// 应用程序路径
        /// </summary>
        public static string PathByGetCurrentDirectory
        {
            get
            {
                return Directory.GetCurrentDirectory();
            }
        }
        /// <summary>
        /// 应用程序路径
        /// </summary>
        public static string PathByBaseDirectory
        {
            get
            {
                return AppDomain.CurrentDomain.BaseDirectory;
            }
        }
        /// <summary>
        /// 应用程序路径
        /// </summary>
        public static string PathByApplicationBase
        {
            get
            {
                return AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
            }
        }
        #endregion Path & 路径

        #region 文件命名格式
        /// <summary>
        /// 获得文件名称
        /// 格式：年
        /// </summary>
        /// <returns>yyyyMMdd.log / yyyy-MM-dd.log</returns>
        public static string GetFileByYear()
        {
            return DateTime.Now.ToString("yyyy");
        }
        /// <summary>
        /// 获得文件名称
        /// 格式：年月
        /// </summary>
        /// <param name="isHorizontal">是否启用横杆分隔</param>
        /// <returns>yyyyMMdd.log / yyyy-MM-dd.log</returns>
        public static string GetFileByMonth(bool isHorizontal)
        {
            if (isHorizontal)
            {
                return DateTime.Now.ToString("yyyy-MM");
            }
            else
            {
                return DateTime.Now.ToString("yyyyMM");
            }
        }
        /// <summary>
        /// 获得文件名称
        /// 格式：年月日
        /// </summary>
        /// <param name="isHorizontal">是否启用横杆分隔</param>
        /// <returns>yyyyMMdd.log / yyyy-MM-dd.log</returns>
        public static string GetFileByDate(bool isHorizontal)
        {
            if (isHorizontal)
            {
                return DateTime.Now.ToString("yyyy-MM-dd");
            }
            else
            {
                return DateTime.Now.ToString("yyyyMMdd");
            }
        }
        /// <summary>
        /// 获得文件名称
        /// 格式：年月日时
        /// </summary>
        /// <param name="isHorizontal">是否启用横杆分隔</param>
        /// <returns>yyyyMMdd.log / yyyy-MM-dd.log</returns>
        public static string GetFileByHour(bool isHorizontal)
        {
            if (isHorizontal)
            {
                return DateTime.Now.ToString("yyyy-MM-dd-HH");
            }
            else
            {
                return DateTime.Now.ToString("yyyyMMddHH");
            }
        }
        /// <summary>
        /// 获得文件名称
        /// 格式：年月日时分秒
        /// </summary>
        /// <param name="isHorizontal">是否启用横杆分隔</param>
        /// <returns>yyyyMMddHHmmss.log / yyyy-MM-dd-HHmmss.log</returns>
        public static string GetFileByDatetime(bool isHorizontal)
        {
            //获取系统时间
            DateTime _time = DateTime.Now;
            string _tempDT = null;
            if (isHorizontal)
            {
                _tempDT = _time.ToString("yyyy-MM-dd-");
            }
            else
            {
                _tempDT = _time.ToString("yyyyMMdd");
            }
            //时
            if (System.DateTime.Now.Hour < 10)
            {
                _tempDT += "0" + System.DateTime.Now.Hour.ToString();
            }
            else
            {
                _tempDT += System.DateTime.Now.Hour.ToString();
            }
            //分
            if (System.DateTime.Now.Minute < 10)
            {
                _tempDT += "0" + System.DateTime.Now.Minute.ToString();
            }
            else
            {
                _tempDT += System.DateTime.Now.Minute.ToString();
            }
            //秒
            if (System.DateTime.Now.Second < 10)
            {
                _tempDT += "0" + System.DateTime.Now.Second.ToString();
            }
            else
            {
                _tempDT += System.DateTime.Now.Second.ToString();
            }
            return _tempDT;
        }
        /// <summary>
        /// 获得文件名称
        /// 格式：年月日时分秒毫秒
        /// </summary>
        /// <param name="isHorizontal">是否启用横杆分隔</param>
        /// <returns>yyyyMMddHHmmssfff.log / yyyy-MM-dd-HHmmssfff.log</returns>
        public static string GetFileByALL(bool isHorizontal)
        {
            //获取系统时间
            DateTime _time = DateTime.Now;
            string _tempDT = null;
            if (isHorizontal)
            {
                _tempDT = _time.ToString("yyyy-MM-dd-");
            }
            else
            {
                _tempDT = _time.ToString("yyyyMMdd");
            }
            //时
            if (System.DateTime.Now.Hour < 10)
            {
                _tempDT += "0" + System.DateTime.Now.Hour.ToString();
            }
            else
            {
                _tempDT += System.DateTime.Now.Hour.ToString();
            }
            //分
            if (System.DateTime.Now.Minute < 10)
            {
                _tempDT += "0" + System.DateTime.Now.Minute.ToString();
            }
            else
            {
                _tempDT += System.DateTime.Now.Minute.ToString();
            }
            //秒
            if (System.DateTime.Now.Second < 10)
            {
                _tempDT += "0" + System.DateTime.Now.Second.ToString();
            }
            else
            {
                _tempDT += System.DateTime.Now.Second.ToString();
            }
            //毫秒
            if (System.DateTime.Now.Millisecond < 100)
            {
                _tempDT += "0" + DateTime.Now.Millisecond.ToString();
            }
            else if (System.DateTime.Now.Millisecond < 10)
            {
                _tempDT += "00" + DateTime.Now.Millisecond.ToString();
            }
            else
            {
                _tempDT += DateTime.Now.Millisecond.ToString();
            }
            return _tempDT;
        }
        #endregion 文件命名格式

        #region 生成缩略图
        /// <summary>
        /// 生成缩略图
        /// </summary>
        /// <param name="originalImagePath">源图路径（物理路径）</param>
        /// <param name="thumbnailPath">缩略图路径（物理路径）</param>
        /// <param name="width">缩略图宽度</param>
        /// <param name="height">缩略图高度</param>
        /// <param name="mode">
        /// 生成缩略图的方式
        /// "HW" 指定高宽缩放（可能变形）
        /// "W" 指定宽，高按比例
        /// "H" 指定高，宽按比例
        /// "Cut" 指定高宽裁减（不变形）
        /// </param>
        public static void MakeThumbnail(string originalImagePath, string thumbnailPath, int width, int height, string mode)
        {
            System.Drawing.Image originalImage = System.Drawing.Image.FromFile(originalImagePath);
            int towidth = width;
            int toheight = height;
            int x = 0;
            int y = 0;
            int ow = originalImage.Width;
            int oh = originalImage.Height;
            switch (mode)
            {
                case "HW"://指定高宽缩放（可能变形）
                    break;
                case "W"://指定宽，高按比例
                    toheight = originalImage.Height * width / originalImage.Width;
                    break;
                case "H"://指定高，宽按比例
                    towidth = originalImage.Width * height / originalImage.Height;
                    break;
                case "Cut"://指定高宽裁减（不变形）
                    if ((double)originalImage.Width / (double)originalImage.Height > (double)towidth / (double)toheight)
                    {
                        oh = originalImage.Height;
                        ow = originalImage.Height * towidth / toheight;
                        y = 0;
                        x = (originalImage.Width - ow) / 2;
                    }
                    else
                    {
                        ow = originalImage.Width;
                        oh = originalImage.Width * height / towidth;
                        x = 0;
                        y = (originalImage.Height - oh) / 2;
                    }
                    break;
                default:
                    break;
            }
            //新建一个bmp图片
            System.Drawing.Image bitmap = new System.Drawing.Bitmap(towidth, toheight);
            //新建一个画板
            System.Drawing.Graphics g = System.Drawing.Graphics.FromImage(bitmap);
            //设置高质量插值法
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.High;
            //设置高质量,低速度呈现平滑程度
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            //清空画布并以透明背景色填充
            g.Clear(System.Drawing.Color.Transparent);
            //在指定位置并且按指定大小绘制原图片的指定部分
            g.DrawImage(originalImage, new System.Drawing.Rectangle(0, 0, towidth, toheight), new System.Drawing.Rectangle(x, y, ow, oh), System.Drawing.GraphicsUnit.Pixel);
            try
            {
                //以jpg格式保存缩略图
                bitmap.Save(thumbnailPath, System.Drawing.Imaging.ImageFormat.Jpeg);
            }
            catch (System.Exception e)
            {
                throw e;
            }
            finally
            {
                originalImage.Dispose();
                bitmap.Dispose();
                g.Dispose();
            }
        }
        #endregion 生成缩略图

        #region 备份/恢复 文件
        /// <summary>
        /// 备份文件,当目标文件存在时覆盖
        /// </summary>
        /// <param name="sourceFileName">源文件名</param>
        /// <param name="destFileName">目标文件名</param>
        /// <returns>操作是否成功</returns>
        public static bool BackupFile(string sourceFileName, string destFileName)
        {
            return BackupFile(sourceFileName, destFileName, true);
        }
        /// <summary>
        /// 备份文件
        /// </summary>
        /// <param name="sourceFileName">源文件名</param>
        /// <param name="destFileName">目标文件名</param>
        /// <param name="overwrite">当目标文件存在时是否覆盖</param>
        /// <returns>操作是否成功</returns>
        public static bool BackupFile(string sourceFileName, string destFileName, bool overwrite)
        {
            if (!System.IO.File.Exists(sourceFileName)) throw new FileNotFoundException(sourceFileName + "文件不存在！");

            if (!overwrite && System.IO.File.Exists(destFileName)) return false;
            try
            {
                System.IO.File.Copy(sourceFileName, destFileName, true);
                return true;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        /// <summary>
        /// 恢复文件
        /// </summary>
        /// <param name="backupFileName">备份文件名</param>
        /// <param name="targetFileName">要恢复的文件名</param>
        /// <returns>操作是否成功</returns>
        public static bool RestoreFile(string backupFileName, string targetFileName)
        {
            return RestoreFile(backupFileName, targetFileName, null);
        }
        /// <summary>
        /// 恢复文件
        /// </summary>
        /// <param name="backupFileName">备份文件名</param>
        /// <param name="targetFileName">要恢复的文件名</param>
        /// <param name="backupTargetFileName">要恢复文件再次备份的名称,如果为null,则不再备份恢复文件</param>
        /// <returns>操作是否成功</returns>
        public static bool RestoreFile(string backupFileName, string targetFileName, string backupTargetFileName)
        {
            try
            {
                if (!System.IO.File.Exists(backupFileName)) throw new FileNotFoundException(backupFileName + "文件不存在！");
                if (backupTargetFileName != null)
                {
                    if (!System.IO.File.Exists(targetFileName))
                    {
                        throw new FileNotFoundException(targetFileName + "文件不存在！无法备份此文件！");
                    }
                    else
                    {
                        System.IO.File.Copy(targetFileName, backupTargetFileName, true);
                    }
                }
                System.IO.File.Delete(targetFileName);
                System.IO.File.Copy(backupFileName, targetFileName);
            }
            catch (Exception e)
            {
                throw e;
            }
            return true;
        }
        #endregion 备份/恢复 文件

        #region 目录操作
        /// <summary>
        /// 复制指定目录的所有文件,不包含子目录及子目录中的文件
        /// </summary>
        /// <param name="sourceDir">原始目录</param>
        /// <param name="targetDir">目标目录</param>
        /// <param name="overWrite">如果为true,表示覆盖同名文件,否则不覆盖</param>
        public static void CopyFiles(string sourceDir, string targetDir, bool overWrite)
        {
            CopyFiles(sourceDir, targetDir, overWrite, false);
        }
        /// <summary>
        /// 复制指定目录的所有文件
        /// </summary>
        /// <param name="sourceDir">原始目录</param>
        /// <param name="targetDir">目标目录</param>
        /// <param name="overWrite">如果为true,覆盖同名文件,否则不覆盖</param>
        /// <param name="copySubDir">如果为true,包含目录,否则不包含</param>
        public static void CopyFiles(string sourceDir, string targetDir, bool overWrite, bool copySubDir)
        {
            //复制当前目录文件
            foreach (string sourceFileName in Directory.GetFiles(sourceDir))
            {
                string targetFileName = Path.Combine(targetDir, sourceFileName.Substring(sourceFileName.LastIndexOf(PATH_SPLIT_CHAR) + 1));
                if (File.Exists(targetFileName))
                {
                    if (overWrite == true)
                    {
                        File.SetAttributes(targetFileName, FileAttributes.Normal);
                        File.Copy(sourceFileName, targetFileName, overWrite);
                    }
                }
                else
                {
                    File.Copy(sourceFileName, targetFileName, overWrite);
                }
            }
            //复制子目录
            if (copySubDir)
            {
                foreach (string sourceSubDir in Directory.GetDirectories(sourceDir))
                {
                    string targetSubDir = Path.Combine(targetDir, sourceSubDir.Substring(sourceSubDir.LastIndexOf(PATH_SPLIT_CHAR) + 1));
                    if (!Directory.Exists(targetSubDir)) Directory.CreateDirectory(targetSubDir);
                    CopyFiles(sourceSubDir, targetSubDir, overWrite, true);
                }
            }
        }
        /// <summary>
        /// 剪切指定目录的所有文件,不包含子目录
        /// </summary>
        /// <param name="sourceDir">原始目录</param>
        /// <param name="targetDir">目标目录</param>
        /// <param name="overWrite">如果为true,覆盖同名文件,否则不覆盖</param>
        public static void MoveFiles(string sourceDir, string targetDir, bool overWrite)
        {
            MoveFiles(sourceDir, targetDir, overWrite, false);
        }
        /// <summary>
        /// 剪切指定目录的所有文件
        /// </summary>
        /// <param name="sourceDir">原始目录</param>
        /// <param name="targetDir">目标目录</param>
        /// <param name="overWrite">如果为true,覆盖同名文件,否则不覆盖</param>
        /// <param name="moveSubDir">如果为true,包含目录,否则不包含</param>
        public static void MoveFiles(string sourceDir, string targetDir, bool overWrite, bool moveSubDir)
        {
            //移动当前目录文件
            foreach (string sourceFileName in Directory.GetFiles(sourceDir))
            {
                string targetFileName = Path.Combine(targetDir, sourceFileName.Substring(sourceFileName.LastIndexOf(PATH_SPLIT_CHAR) + 1));
                if (File.Exists(targetFileName))
                {
                    if (overWrite == true)
                    {
                        File.SetAttributes(targetFileName, FileAttributes.Normal);
                        File.Delete(targetFileName);
                        File.Move(sourceFileName, targetFileName);
                    }
                }
                else
                {
                    File.Move(sourceFileName, targetFileName);
                }
            }
            if (moveSubDir)
            {
                foreach (string sourceSubDir in Directory.GetDirectories(sourceDir))
                {
                    string targetSubDir = Path.Combine(targetDir, sourceSubDir.Substring(sourceSubDir.LastIndexOf(PATH_SPLIT_CHAR) + 1));
                    if (!Directory.Exists(targetSubDir)) Directory.CreateDirectory(targetSubDir);
                    MoveFiles(sourceSubDir, targetSubDir, overWrite, true);
                    Directory.Delete(sourceSubDir);
                }
            }
        }
        /// <summary>
        /// 删除指定目录的所有文件，不包含子目录
        /// </summary>
        /// <param name="targetDir">操作目录</param>
        public static void DeleteFiles(string targetDir)
        {
            DeleteFiles(targetDir, false);
        }
        /// <summary>
        /// 删除指定目录的所有文件和子目录
        /// </summary>
        /// <param name="targetDir">操作目录</param>
        /// <param name="delSubDir">如果为true,包含对子目录的操作</param>
        public static void DeleteFiles(string targetDir, bool delSubDir)
        {
            foreach (string fileName in Directory.GetFiles(targetDir))
            {
                File.SetAttributes(fileName, FileAttributes.Normal);
                File.Delete(fileName);
            }
            if (delSubDir)
            {
                DirectoryInfo dir = new DirectoryInfo(targetDir);
                foreach (DirectoryInfo subDi in dir.GetDirectories())
                {
                    DeleteFiles(subDi.FullName, true);
                    subDi.Delete();
                }
            }
        }
        /// <summary>
        /// 创建指定目录
        /// </summary>
        /// <param name="targetDir"></param>
        public static void CreateDirectory(string targetDir)
        {
            DirectoryInfo dir = new DirectoryInfo(targetDir);
            if (!dir.Exists) dir.Create();
        }
        /// <summary>
        /// 建立子目录
        /// </summary>
        /// <param name="parentDir">目录路径</param>
        /// <param name="subDirName">子目录名称</param>
        public static void CreateDirectory(string parentDir, string subDirName)
        {
            CreateDirectory(parentDir + PATH_SPLIT_CHAR + subDirName);
        }
        /// <summary>
        /// 删除指定目录
        /// </summary>
        /// <param name="targetDir">目录路径</param>
        public static void DeleteDirectory(string targetDir)
        {
            DirectoryInfo dirInfo = new DirectoryInfo(targetDir);
            if (dirInfo.Exists)
            {
                DeleteFiles(targetDir, true);
                dirInfo.Delete(true);
            }
        }
        /// <summary>
        /// 删除指定目录的所有子目录,不包括对当前目录文件的删除
        /// </summary>
        /// <param name="targetDir">目录路径</param>
        public static void DeleteSubDirectory(string targetDir)
        {
            foreach (string subDir in Directory.GetDirectories(targetDir))
            {
                DeleteDirectory(subDir);
            }
        }        
        #endregion 目录操作

        #endregion 成员方法

    }
}

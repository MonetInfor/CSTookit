﻿// =================================================================== 
// 【宋】常用工具集（DawnXZ.Tools）合集
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：DawnDESEncrypt.cs
// 项目名称：【宋】常用工具集
// 创建时间：2010-09-04
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System;
using System.Text;
using System.IO;
using System.Security.Cryptography;

namespace DawnXZ.Tools
{
    /// <summary>
    /// 加 / 解 密类
    /// </summary>
    public class DawnDESEncrypt
    {

        #region 成员方法

        #region ========加密========
        /// <summary>
        /// 加密
        /// </summary>
        /// <param name="Text">待加密字符串</param>
        /// <returns></returns>
        public static string Encrypt(string Text)
        {
            return Encrypt(Text, "*DawnXZ..com*");
        }
        /// <summary>
        /// 加密
        /// <remarks>
        /// 101-109
        /// </remarks>
        /// </summary>
        /// <param name="Text">待加密字符串1</param>
        /// <param name="intFlag">待加密字符串2</param>
        /// <returns></returns>
        public static string Encrypt(string Text, byte intFlag)
        {
            string tempEncrypt = string.Empty;
            switch (intFlag)
            {
                case 101:
                    tempEncrypt = Encrypt(Text, "iv9oegcmJ6KT1Wdj2o6");
                    break;
                case 102:
                    tempEncrypt = Encrypt(Text, "zYN80NuP2KtCFHRhN12");
                    break;
                case 103:
                    tempEncrypt = Encrypt(Text, "lSpSNBlfr0XZh6t5K0z");
                    break;
                case 104:
                    tempEncrypt = Encrypt(Text, "hJY3C3NcXvnuD93lame");
                    break;
                case 105:
                    tempEncrypt = Encrypt(Text, "wiwHgeFjU09JyzZUSkq");
                    break;
                case 106:
                    tempEncrypt = Encrypt(Text, "YQnApRjbf4grm9QROY5");
                    break;
                case 107:
                    tempEncrypt = Encrypt(Text, "B6oIdoh0fi7SwKWQGHE");
                    break;
                case 108:
                    tempEncrypt = Encrypt(Text, "FT8IyYTrjpx95hWiaxY");
                    break;
                case 109:
                    tempEncrypt = Encrypt(Text, "ujP341Ae27dsOXNh9wB");
                    break;
                default:
                    tempEncrypt = Encrypt(Text, "*DawnXZ..com*");
                    break;
            }
            return tempEncrypt;
        }
        /// <summary>
        /// 加密 URL 专用
        /// </summary>
        /// <param name="Text">待加密字符串</param>
        /// <returns></returns>
        public static string EncryptUrl(string Text)
        {
            return Encrypt(Text, "*url*");
        }
        /// <summary> 
        /// 加密数据 
        /// </summary> 
        /// <param name="Text">待加密字符串</param> 
        /// <param name="sKey">加密密钥</param> 
        /// <returns></returns> 
        public static string Encrypt(string Text, string sKey)
        {
            try
            {
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                byte[] inputByteArray;
                inputByteArray = Encoding.Default.GetBytes(Text);
                des.Key = ASCIIEncoding.ASCII.GetBytes(MD5(sKey, true).Substring(0, 8));
                des.IV = ASCIIEncoding.ASCII.GetBytes(MD5(sKey, true).Substring(0, 8));
                System.IO.MemoryStream ms = new System.IO.MemoryStream();
                CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(), CryptoStreamMode.Write);
                cs.Write(inputByteArray, 0, inputByteArray.Length);
                cs.FlushFinalBlock();
                StringBuilder ret = new StringBuilder();
                foreach (byte b in ms.ToArray())
                {
                    ret.AppendFormat("{0:X2}", b);
                }
                return ret.ToString();
            }
            catch
            {
                return null;
            }
        }
        #endregion ========加密========

        #region ========解密========
        /// <summary>
        /// 解密
        /// </summary>
        /// <param name="Text">待解密字符串</param>
        /// <returns></returns>
        public static string Decrypt(string Text)
        {
            return Decrypt(Text, "*DawnXZ..com*");
        }
        /// <summary>
        /// 解密
        /// <remarks>
        /// 101-109
        /// </remarks>
        /// </summary>
        /// <param name="Text">待解密字符串1</param>
        /// <param name="intFlag">待解密字符串2</param>
        /// <returns></returns>
        public static string Decrypt(string Text, byte intFlag)
        {
            string tempDecrypt = string.Empty;
            switch (intFlag)
            {
                case 101:
                    tempDecrypt = Decrypt(Text, "iv9oegcmJ6KT1Wdj2o6");
                    break;
                case 102:
                    tempDecrypt = Decrypt(Text, "zYN80NuP2KtCFHRhN12");
                    break;
                case 103:
                    tempDecrypt = Decrypt(Text, "lSpSNBlfr0XZh6t5K0z");
                    break;
                case 104:
                    tempDecrypt = Decrypt(Text, "hJY3C3NcXvnuD93lame");
                    break;
                case 105:
                    tempDecrypt = Decrypt(Text, "wiwHgeFjU09JyzZUSkq");
                    break;
                case 106:
                    tempDecrypt = Decrypt(Text, "YQnApRjbf4grm9QROY5");
                    break;
                case 107:
                    tempDecrypt = Decrypt(Text, "B6oIdoh0fi7SwKWQGHE");
                    break;
                case 108:
                    tempDecrypt = Decrypt(Text, "FT8IyYTrjpx95hWiaxY");
                    break;
                case 109:
                    tempDecrypt = Decrypt(Text, "ujP341Ae27dsOXNh9wB");
                    break;
                default:
                    tempDecrypt = Decrypt(Text, "*DawnXZ..com*");
                    break;
            }
            return tempDecrypt;
        }
        /// <summary>
        /// 解密 URL 专用
        /// </summary>
        /// <param name="Text">待解密字符串</param>
        /// <returns></returns>
        public static string DecryptUrl(string Text)
        {
            return Decrypt(Text, "*url*");
        }
        /// <summary>
        /// 解密字符串并将多余显示为 * 号
        /// </summary>
        /// <param name="show">显示位数</param>
        /// <param name="Text">待解密字符串</param>
        /// <returns></returns>
        public static string Decrypt(int show, string Text)
        {
            string strReplace = null;
            string strTemp = Decrypt(Text, "*DawnXZ..com*");
            if (string.IsNullOrEmpty(strTemp)) return null;
            for (int intCount = 0; intCount < strTemp.Length - show; intCount++)
            {
                strReplace += "*";
            }
            if (show < strTemp.Length)
            {
                strTemp = strTemp.Replace(strTemp.Substring(show, strTemp.Length - show), strReplace);
            }
            return strTemp;
        }
        /// <summary> 
        /// 解密数据 
        /// </summary> 
        /// <param name="Text">待解密字符串</param> 
        /// <param name="sKey">解密密钥</param> 
        /// <returns></returns> 
        public static string Decrypt(string Text, string sKey)
        {
            try
            {
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                int len;
                len = Text.Length / 2;
                byte[] inputByteArray = new byte[len];
                int x, i;
                for (x = 0; x < len; x++)
                {
                    i = Convert.ToInt32(Text.Substring(x * 2, 2), 16);
                    inputByteArray[x] = (byte)i;
                }
                des.Key = ASCIIEncoding.ASCII.GetBytes(MD5(sKey, true).Substring(0, 8));
                des.IV = ASCIIEncoding.ASCII.GetBytes(MD5(sKey, true).Substring(0, 8));
                System.IO.MemoryStream ms = new System.IO.MemoryStream();
                CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(), CryptoStreamMode.Write);
                cs.Write(inputByteArray, 0, inputByteArray.Length);
                cs.FlushFinalBlock();
                return Encoding.Default.GetString(ms.ToArray());
            }
            catch
            {
                return null;
            }
        }
        #endregion ========解密========

        #region ========加解密文件========
        /// <summary>
        /// 加密文件
        /// </summary>
        /// <param name="inName">输入文件名</param>
        /// <param name="outName">输出文件名</param>
        /// <param name="desKey">加密Key</param>
        /// <param name="desIV">加密IV</param>
        public static void fileEncryptData(String inName, String outName, byte[] desKey, byte[] desIV)
        {
            //Create the file streams to handle the input and output files.
            FileStream fin = new FileStream(inName, FileMode.Open, FileAccess.Read);
            FileStream fout = new FileStream(outName, FileMode.OpenOrCreate, FileAccess.Write);
            fout.SetLength(0);
            //Create variables to help with read and write.
            byte[] bin = new byte[100]; //This is intermediate storage for the encryption.
            long rdlen = 0;              //This is the total number of bytes written.
            long totlen = fin.Length;    //This is the total length of the input file.
            int len;                     //This is the number of bytes to be written at a time.
            DES des = new DESCryptoServiceProvider();
            CryptoStream encStream = new CryptoStream(fout, des.CreateEncryptor(desKey, desIV), CryptoStreamMode.Write);
            //Read from the input file, then encrypt and write to the output file.
            while (rdlen < totlen)
            {
                len = fin.Read(bin, 0, 100);
                encStream.Write(bin, 0, len);
                rdlen = rdlen + len;
            }
            encStream.Close();
            fout.Close();
            fin.Close();
        }
        /// <summary>
        /// 解密文件
        /// </summary>
        /// <param name="inName">输入文件名</param>
        /// <param name="outName">输出文件名</param>
        /// <param name="desKey">加密Key</param>
        /// <param name="desIV">加密IV</param>
        public static void fileDecryptData(String inName, String outName, byte[] desKey, byte[] desIV)
        {
            //Create the file streams to handle the input and output files.
            FileStream fin = new FileStream(inName, FileMode.Open, FileAccess.Read);
            FileStream fout = new FileStream(outName, FileMode.OpenOrCreate, FileAccess.Write);
            fout.SetLength(0);
            //Create variables to help with read and write.
            byte[] bin = new byte[100]; //This is intermediate storage for the encryption.
            long rdlen = 0;              //This is the total number of bytes written.
            long totlen = fin.Length;    //This is the total length of the input file.
            int len;                     //This is the number of bytes to be written at a time.
            DES des = new DESCryptoServiceProvider();
            CryptoStream encStream = new CryptoStream(fout, des.CreateDecryptor(desKey, desIV), CryptoStreamMode.Write);
            //Read from the input file, then encrypt and write to the output file.
            while (rdlen < totlen)
            {
                len = fin.Read(bin, 0, 100);
                encStream.Write(bin, 0, len);
                rdlen = rdlen + len;
            }
            encStream.Close();
            fout.Close();
            fin.Close();
        }
        #endregion ========加解密文件========

        #region MD5 & SHA256
        /// <summary>
        /// MD5函数
        /// </summary>
        /// <param name="str">原始字符串</param>
        /// <param name="isUpper">是否大写形式</param>
        /// <returns>MD5结果</returns>
        public static string MD5(string str, bool isUpper)
        {
            byte[] b = Encoding.UTF8.GetBytes(str);
            b = new MD5CryptoServiceProvider().ComputeHash(b);
            string ret = "";
            for (int i = 0; i < b.Length; i++)
            {
                ret += b[i].ToString("x").PadLeft(2, '0');
            }
            if (isUpper) ret = ret.ToUpper();
            return ret;
        }
        /// <summary>
        /// SHA256函数
        /// </summary>
        /// /// <param name="str">原始字符串</param>
        /// <returns>SHA256结果</returns>
        public static string SHA256(string str)
        {
            byte[] SHA256Data = Encoding.UTF8.GetBytes(str);
            SHA256Managed Sha256 = new SHA256Managed();
            byte[] Result = Sha256.ComputeHash(SHA256Data);
            return Convert.ToBase64String(Result);  //返回长度为44字节的字符串
        }
        #endregion MD5 & SHA256

        #region 哈希加密
        /// <summary>
        /// 得到随机哈希加密字符串
        /// </summary>
        /// <returns></returns>
        public static string GetHashSecurity()
        {
            return GetHashEncoding(GetHashRandomValue());
        }
        /// <summary>
        /// 得到一个随机数值
        /// </summary>
        /// <returns></returns>
        public static string GetHashRandomValue()
        {
            Random Seed = new Random();
            string RandomVaule = Seed.Next(1, int.MaxValue).ToString();
            return RandomVaule;
        }
        /// <summary>
        /// 哈希加密一个字符串
        /// SHA512函数
        /// </summary>
        /// <param name="Security"></param>
        /// <returns></returns>
        public static string GetHashEncoding(string Security)
        {
            byte[] Value;
            UnicodeEncoding Code = new UnicodeEncoding();
            byte[] Message = Code.GetBytes(Security);
            SHA512Managed Arithmetic = new SHA512Managed();
            Value = Arithmetic.ComputeHash(Message);
            Security = "";
            foreach (byte o in Value)
            {
                Security += (int)o + "O";
            }
            return Security;
        }
        #endregion 哈希加密

        #endregion 成员方法

    }

    /// <summary> 
    /// 加密 AES 方式
    /// </summary> 
    public class DawnAES
    {

        #region 成员方法
        //默认密钥向量
        private static byte[] Keys = { 0x41, 0x72, 0x65, 0x79, 0x6F, 0x75, 0x6D, 0x79, 0x53, 0x6E, 0x6F, 0x77, 0x6D, 0x61, 0x6E, 0x3F };
        /// <summary>
        /// AES 加密字符串
        /// </summary>
        /// <param name="encryptString">待加密的字符串</param>
        /// <param name="encryptKey">加密密钥,要求为8位</param>
        /// <returns>加密成功返回加密后的字符串,失败返回源串</returns>
        public static string Encode(string encryptString, string encryptKey)
        {
            encryptKey = DawnStringRelated.InterceptGetSubString(encryptKey, 32, "");
            encryptKey = encryptKey.PadRight(32, ' ');
            RijndaelManaged rijndaelProvider = new RijndaelManaged();
            rijndaelProvider.Key = Encoding.UTF8.GetBytes(encryptKey.Substring(0, 32));
            rijndaelProvider.IV = Keys;
            ICryptoTransform rijndaelEncrypt = rijndaelProvider.CreateEncryptor();
            byte[] inputData = Encoding.UTF8.GetBytes(encryptString);
            byte[] encryptedData = rijndaelEncrypt.TransformFinalBlock(inputData, 0, inputData.Length);
            return Convert.ToBase64String(encryptedData);
        }
        /// <summary>
        /// AES 解密字符串
        /// </summary>
        /// <param name="decryptString">待解密的字符串</param>
        /// <param name="decryptKey">解密密钥,要求为8位</param>
        /// <returns>解密成功返回解密后的字符串,失败返回 null</returns>
        public static string Decode(string decryptString, string decryptKey)
        {
            try
            {
                decryptKey = DawnStringRelated.InterceptGetSubString(decryptKey, 32, "");
                decryptKey = decryptKey.PadRight(32, ' ');
                RijndaelManaged rijndaelProvider = new RijndaelManaged();
                rijndaelProvider.Key = Encoding.UTF8.GetBytes(decryptKey);
                rijndaelProvider.IV = Keys;
                ICryptoTransform rijndaelDecrypt = rijndaelProvider.CreateDecryptor();
                byte[] inputData = Convert.FromBase64String(decryptString);
                byte[] decryptedData = rijndaelDecrypt.TransformFinalBlock(inputData, 0, inputData.Length);
                return Encoding.UTF8.GetString(decryptedData);
            }
            catch
            {
                return null;
            }
        }
        #endregion 成员方法

    }

    /// <summary> 
    /// 加密 DES 方式
    /// </summary> 
    public class DawnDES
    {

        #region 成员方法
        //默认密钥向量
        private static byte[] Keys = { 0x12, 0x34, 0x56, 0x78, 0x90, 0xAB, 0xCD, 0xEF };
        /// <summary>
        /// DES 加密字符串
        /// </summary>
        /// <param name="encryptString">待加密的字符串</param>
        /// <param name="encryptKey">加密密钥,要求为8位</param>
        /// <returns>加密成功返回加密后的字符串,失败返回源串</returns>
        public static string Encode(string encryptString, string encryptKey)
        {
            encryptKey = DawnStringRelated.InterceptGetSubString(encryptKey, 8, "");
            encryptKey = encryptKey.PadRight(8, ' ');
            byte[] rgbKey = Encoding.UTF8.GetBytes(encryptKey.Substring(0, 8));
            byte[] rgbIV = Keys;
            byte[] inputByteArray = Encoding.UTF8.GetBytes(encryptString);
            DESCryptoServiceProvider dCSP = new DESCryptoServiceProvider();
            MemoryStream mStream = new MemoryStream();
            CryptoStream cStream = new CryptoStream(mStream, dCSP.CreateEncryptor(rgbKey, rgbIV), CryptoStreamMode.Write);
            cStream.Write(inputByteArray, 0, inputByteArray.Length);
            cStream.FlushFinalBlock();
            return Convert.ToBase64String(mStream.ToArray());
        }
        /// <summary>
        /// DES 解密字符串
        /// </summary>
        /// <param name="decryptString">待解密的字符串</param>
        /// <param name="decryptKey">解密密钥,要求为8位,和加密密钥相同</param>
        /// <returns>解密成功返回解密后的字符串,失败返 null</returns>
        public static string Decode(string decryptString, string decryptKey)
        {
            try
            {
                decryptKey = DawnStringRelated.InterceptGetSubString(decryptKey, 8, "");
                decryptKey = decryptKey.PadRight(8, ' ');
                byte[] rgbKey = Encoding.UTF8.GetBytes(decryptKey);
                byte[] rgbIV = Keys;
                byte[] inputByteArray = Convert.FromBase64String(decryptString);
                DESCryptoServiceProvider DCSP = new DESCryptoServiceProvider();
                MemoryStream mStream = new MemoryStream();
                CryptoStream cStream = new CryptoStream(mStream, DCSP.CreateDecryptor(rgbKey, rgbIV), CryptoStreamMode.Write);
                cStream.Write(inputByteArray, 0, inputByteArray.Length);
                cStream.FlushFinalBlock();
                return Encoding.UTF8.GetString(mStream.ToArray());
            }
            catch
            {
                return null;
            }
        }
        #endregion 成员方法

    }
}

﻿// =================================================================== 
// 【宋】常用工具集（DawnXZ.Tools）合集
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：DawnSqlSafe.cs
// 项目名称：【宋】常用工具集
// 创建时间：2010-09-04
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System;
using System.Web;

namespace DawnXZ.Tools
{
    /// <summary>
    /// Sql防注入安全类
    /// <remarks>
    /// <para>在 Web.config 文件中的 appSettings 配置节添加如下代码</para>
    /// <para>!--防注入设置[yes/no][strSqlInjection可不配置]--></para>
    /// <para>add key="strSqlInjection" value="and |exec |insert |select |delete |update |count | * |chr |mid |master |truncate |char |declare " /></para>
    /// <para>add key="strSqlInjectionFlag" value="no" /></para>
    /// <para>add key="strSqlInjectionErrPage" value="Error.aspx" /></para>
    /// <para>在 Web.config 文件中的 system.web 配置节 中的 HttpModules 中添加如下代码</para>
    /// <para>防注入设置</para>
    /// <para>add name="httpSqlInjection" type="DawnXZ.Tools.DawnSqlSafe,httpSqlInjection" /></para>
    /// </remarks>
    /// </summary>
    public class DawnSqlSafe : IHttpModule
    {

        #region 成员方法

        /// <summary>
        /// 初始化
        /// </summary>
        /// <param name="application"></param>
        public void Init(HttpApplication application)
        {
            application.BeginRequest += (new EventHandler(this.Application_BeginRequest));
        }
        /// <summary>
        /// 应用程序请求开始
        /// </summary>
        /// <param name="source"></param>
        /// <param name="e"></param>
        private void Application_BeginRequest(Object source, EventArgs e)
        {
            DawnProcessRequest pr = new DawnProcessRequest();
            pr.StartProcessRequest();
        }
        /// <summary>
        /// 释放
        /// </summary>
        public void Dispose()
        { }

        #endregion

    }
}

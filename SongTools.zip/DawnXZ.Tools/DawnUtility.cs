﻿// =================================================================== 
// 【宋】常用工具集（DawnXZ.Tools）合集
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：DawnUtility.cs
// 项目名称：【宋】常用工具集
// 创建时间：2011-06-14
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System;
using System.Diagnostics;
using System.Web;
using System.IO;
using System.Text.RegularExpressions;
using System.Text;

namespace DawnXZ.Tools
{
    /// <summary>
    /// 多效用的、多功能的 方法体
    /// </summary>
    public class DawnUtility
    {

        #region 成员方法

        #region 常规集合
        /// <summary>
        /// 清除UBB标签
        /// </summary>
        /// <param name="sDetail">帖子内容</param>
        /// <returns>帖子内容</returns>
        public static string ClearUBB(string sDetail)
        {
            return Regex.Replace(sDetail, @"\[[^\]]*?\]", string.Empty, RegexOptions.IgnoreCase);
        }
        /// <summary>
        /// 清理字符串
        /// </summary>
        public static string CleanInput(string strIn)
        {
            return Regex.Replace(strIn.Trim(), @"[^\w\.@-]", "");
        }
        /// <summary>
        /// 获取 Email 主机名
        /// 例：test@163.com
        /// 获得后为：163.com
        /// </summary>
        /// <param name="strEmail">Email 地址</param>
        /// <returns></returns>
        public static string GetEmailHostName(string strEmail)
        {
            if (strEmail.IndexOf("@") < 0) return "";
            return strEmail.Substring(strEmail.LastIndexOf("@")).ToLower();
        }
        #endregion 常规集合

        #region 输出指定 ContentType 文件
        /// <summary>
        /// 以指定的ContentType输出指定文件
        /// </summary>
        /// <param name="filepath">文件路径</param>
        /// <param name="filename">输出的文件名</param>
        /// <param name="filetype">将文件输出时设置的ContentType</param>
        public static void ResponseFile(string filepath, string filename, string filetype)
        {
            Stream iStream = null;
            // 缓冲区为10k
            byte[] buffer = new Byte[10000];
            // 文件长度
            int length;
            // 需要读的数据长度
            long dataToRead;
            try
            {
                // 打开文件
                iStream = new FileStream(filepath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                // 需要读的数据长度
                dataToRead = iStream.Length;
                HttpContext.Current.Response.ContentType = filetype;
                if (HttpContext.Current.Request.ServerVariables["HTTP_USER_AGENT"].IndexOf("MSIE") > -1)
                {
                    HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=" + DawnRequest.HtmlCodingUrlEncode(filename.Trim()).Replace("+", " "));
                }
                else
                {
                    HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=" + filename.Trim());
                }
                while (dataToRead > 0)
                {
                    // 检查客户端是否还处于连接状态
                    if (HttpContext.Current.Response.IsClientConnected)
                    {
                        length = iStream.Read(buffer, 0, 10000);
                        HttpContext.Current.Response.OutputStream.Write(buffer, 0, length);
                        HttpContext.Current.Response.Flush();
                        buffer = new Byte[10000];
                        dataToRead = dataToRead - length;
                    }
                    else
                    {
                        //如果不再连接则跳出死循环
                        dataToRead = -1;
                    }
                }
            }
            catch (Exception ex)
            {
                HttpContext.Current.Response.Write("Error : " + ex.Message);
            }
            finally
            {
                if (iStream != null) iStream.Close();// 关闭文件
            }
            HttpContext.Current.Response.End();
        }
        #endregion 输出指定 ContentType 文件

        #region 对象状态转换
        /// <summary>
        /// 转换目标对象状态表示形式
        /// 模式：true √、false ×
        /// </summary>
        public static string StatusConvertByObject(object stateFlag)
        {
            if (Convert.ToBoolean(stateFlag))
            {
                return "√";
            }
            else
            {
                return "×";
            }
        }
        #endregion 对象状态转换

        #region 月份标识数组
        /// <summary>
        /// 根据阿拉伯数字返回月份的名称
        /// 英文
        /// </summary>	
        public static string[] GetMonthesByEnglish
        {
            get
            {
                return new string[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
            }
        }
        /// <summary>
        /// 根据阿拉伯数字返回月份的名称
        /// 中文
        /// </summary>
        public static string[] GetMonthesByChinese
        {
            get
            {
                return new string[] { "一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月" };
            }
        }
        #endregion 月份标识数组

        #region 组件检测场
        /// <summary>
        /// 组件检测场
        /// </summary>
        /// <param name="objName">要检测的组件名称</param>
        /// <returns>是否支持 true/false</returns>
        public static bool SubassemblyCheckByBool(string objName)
        {
            bool tmpFlg = false;
            try
            {
                object obj = System.Web.HttpContext.Current.Server.CreateObject(objName);
                tmpFlg = true;
                obj = null;
            }
            catch
            {
                tmpFlg = false;
            }
            return tmpFlg;
        }
        /// <summary>
        /// 组件检测场
        /// </summary>
        /// <param name="objName">要检测的组件名称</param>
        /// <returns>是否支持 true/false</returns>
        public static string SubassemblyCheckByString(string objName)
        {
            string tmpObjInfo = null;
            try
            {
                object obj = System.Web.HttpContext.Current.Server.CreateObject(objName);
                tmpObjInfo = obj.GetType().Assembly.ToString();
            }
            catch
            {
                tmpObjInfo = null;
            }
            return tmpObjInfo;
        }
        #endregion 组件检测场

        #region 进程、IIS 进程
        /// <summary>
        /// 检测应用程序是否已经启动
        /// </summary>
        /// <returns>是/否</returns>
        public static bool CheckProgramState()
        {
            int ProceedingCount = 0;
            Process[] ProceddingCon = Process.GetProcesses();
            foreach (Process IsProcedding in ProceddingCon)
            {
                if (IsProcedding.ProcessName == Process.GetCurrentProcess().ProcessName)
                {
                    ProceedingCount += 1;
                }
            }
            if (ProceedingCount > 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// hack tip:通过更新web.config文件方式来重启IIS进程池（注：iis中web园数量须大于1,且为非虚拟主机用户才可调用该方法）
        /// </summary>
        public static void RestartIISProcess()
        {
            try
            {
                System.Xml.XmlDocument xmldoc = new System.Xml.XmlDocument();
                xmldoc.Load(DawnRequest.GetMapPath("~/web.config"));
                System.Xml.XmlTextWriter writer = new System.Xml.XmlTextWriter(DawnRequest.GetMapPath("~/web.config"), null);
                writer.Formatting = System.Xml.Formatting.Indented;
                xmldoc.WriteTo(writer);
                writer.Flush();
                writer.Close();
            }
            catch
            { ; }
        }
        #endregion 进程、IIS 进程

        #region JSON 相关
        /// <summary>
        /// 将数据表转换成JSON类型串
        /// </summary>
        /// <param name="dt">要转换的数据表</param>
        /// <returns></returns>
        public static StringBuilder JsonFromDataTable(System.Data.DataTable dt)
        {
            return JsonFromDataTable(dt, true);
        }
        /// <summary>
        /// 将数据表转换成JSON类型串
        /// </summary>
        /// <param name="dt">要转换的数据表</param>
        /// <param name="dt_dispose">数据表转换结束后是否dispose掉</param>
        /// <returns></returns>
        public static StringBuilder JsonFromDataTable(System.Data.DataTable dt, bool dt_dispose)
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append("[\r\n");
            //数据表字段名和类型数组
            string[] dt_field = new string[dt.Columns.Count];
            int i = 0;
            string formatStr = "{{";
            string fieldtype = "";
            foreach (System.Data.DataColumn dc in dt.Columns)
            {
                dt_field[i] = dc.Caption.ToLower().Trim();
                formatStr += "'" + dc.Caption.ToLower().Trim() + "':";
                fieldtype = dc.DataType.ToString().Trim().ToLower();
                if (fieldtype.IndexOf("int") > 0 || fieldtype.IndexOf("deci") > 0 ||
                    fieldtype.IndexOf("floa") > 0 || fieldtype.IndexOf("doub") > 0 ||
                    fieldtype.IndexOf("bool") > 0)
                {
                    formatStr += "{" + i + "}";
                }
                else
                {
                    formatStr += "'{" + i + "}'";
                }
                formatStr += ",";
                i++;
            }

            if (formatStr.EndsWith(",")) formatStr = formatStr.Substring(0, formatStr.Length - 1);//去掉尾部","号
            formatStr += "}},";
            i = 0;
            object[] objectArray = new object[dt_field.Length];
            foreach (System.Data.DataRow dr in dt.Rows)
            {
                foreach (string fieldname in dt_field)
                {   //对 \ , ' 符号进行转换 
                    objectArray[i] = dr[dt_field[i]].ToString().Trim().Replace("\\", "\\\\").Replace("'", "\\'");
                    switch (objectArray[i].ToString())
                    {
                        case "True":
                            {
                                objectArray[i] = "true"; break;
                            }
                        case "False":
                            {
                                objectArray[i] = "false"; break;
                            }
                        default: break;
                    }
                    i++;
                }
                i = 0;
                stringBuilder.Append(string.Format(formatStr, objectArray));
            }
            if (stringBuilder.ToString().EndsWith(",")) stringBuilder.Remove(stringBuilder.Length - 1, 1);//去掉尾部","号
            if (dt_dispose) dt.Dispose();
            return stringBuilder.Append("\r\n];");
        }
        /// <summary>
        /// Json特符字符过滤，参见http://www.json.org/
        /// </summary>
        /// <param name="sourceStr">要过滤的源字符串</param>
        /// <returns>返回过滤的字符串</returns>
        public static string JsonCharFilter(string sourceStr)
        {
            sourceStr = sourceStr.Replace("\\", "\\\\");
            sourceStr = sourceStr.Replace("\b", "\\\b");
            sourceStr = sourceStr.Replace("\t", "\\\t");
            sourceStr = sourceStr.Replace("\n", "\\\n");
            sourceStr = sourceStr.Replace("\n", "\\\n");
            sourceStr = sourceStr.Replace("\f", "\\\f");
            sourceStr = sourceStr.Replace("\r", "\\\r");
            return sourceStr.Replace("\"", "\\\"");
        }
        #endregion JSON 相关

        #endregion 成员方法

    }
}

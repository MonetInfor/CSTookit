﻿// =================================================================== 
// 【宋】常用工具集（DawnXZ.PublicClass）合集
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：S_Validate.cs
// 项目名称：【宋】常用工具集
// 创建时间：2010-09-04
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System;
using System.Text;
using System.Text.RegularExpressions;

namespace DawnXZ.PublicClass
{
    /// <summary>
    /// 正则判断类
    /// </summary>
    public class S_Validate
    {

        #region 成员方法

        /// <summary>
        /// 电话号码
        /// </summary>
        public static bool isPhone(string phoneString)
        {
            return System.Text.RegularExpressions.Regex.IsMatch(phoneString, "^(\\d{3,4}-)?\\d{7,8}$");
        }
        /// <summary>
        /// 手机号码
        /// </summary>
        public static bool isMobile(string mobileString)
        {
            return System.Text.RegularExpressions.Regex.IsMatch(mobileString, "^13[0123456789]\\d{8}$|^15[0123456789]\\d{8}$");
        }
        /// <summary>
        /// 电话号码、手机号码
        /// </summary>
        public static bool isPhoneMobile(string telString)
        {
            return System.Text.RegularExpressions.Regex.IsMatch(telString, "^(\\d{3,4}-)?\\d{7,8}$|^13[0-9]\\d{8}$|^15[0-9]\\d{8}$");
        }
        /// <summary>
        /// 检测是否符合email格式（正则一）
        /// </summary>
        /// <param name="strEmail">要判断的email字符串</param>
        /// <returns>判断结果</returns>
        public static bool IsValidEmail(string strEmail)
        {
            return Regex.IsMatch(strEmail, @"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
        }
        /// <summary>
        /// 检测是否符合email格式（正则二）
        /// </summary>
        /// <param name="strEmail">要判断的email字符串</param>
        /// <returns></returns>
        public static bool IsValidDoEmail(string strEmail)
        {
            return Regex.IsMatch(strEmail, @"^@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
        }
        /// <summary>
        /// 检测是否符合email格式（通用格式）
        /// </summary>
        /// <param name="emailString">要判断的email字符串</param>
        /// <returns></returns>
        public static bool isEmail(string emailString)
        {
            return System.Text.RegularExpressions.Regex.IsMatch(emailString, "^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$");
        }
        /// <summary>
        /// 邮政编码
        /// </summary>
        public static bool isPost(string postString)
        {
            return System.Text.RegularExpressions.Regex.IsMatch(postString, "^[0-9]{6}");
        }
        /// <summary>
        /// 身份证
        /// </summary>
        /// <param name="idCardString"></param>
        /// <returns></returns>
        public static bool isIdCard(string idCardString)
        {
            return System.Text.RegularExpressions.Regex.IsMatch(idCardString, "\\d{17}[\\d|X]|\\d{15}");
        }
        /// <summary>
        /// 只能为26个英文字母
        /// </summary>
        public static bool isString(string strString)
        {
            return System.Text.RegularExpressions.Regex.IsMatch(strString, "^[A-Za-z]+$");
        }
        /// <summary>
        /// 判断是否为汉字
        /// </summary>
        public static bool isChinese(string isChineseString)
        {
            for (int intCount = 0; intCount < isChineseString.Length; intCount++)
            {
                string strDBC = ToDBC(isChineseString.Substring(intCount, 1));
                int len = System.Text.Encoding.Default.GetByteCount(strDBC);
                if (len != 2)
                {
                    return false;
                }
            }
            return true;
        }
        /// <summary>
        /// 转半角的函数(DBC case)（用于验证输入是否为汉字）
        /// </summary>
        /// <param name="input">任意字符串</param>
        /// <returns>半角字符串</returns>
        ///<remarks>
        ///全角空格为12288，半角空格为32
        ///其他字符半角(33-126)与全角(65281-65374)的对应关系是：均相差65248
        ///</remarks>
        public static string ToDBC(string input)
        {
            char[] c = input.ToCharArray();
            for (int i = 0; i < c.Length; i++)
            {
                if (c[i] == 12288)
                {
                    c[i] = (char)32;
                    continue;
                }
                if (c[i] > 65280 && c[i] < 65375)
                    c[i] = (char)(c[i] - 65248);
            }
            return new string(c);
        }
        /// <summary>
        /// SQL注入全面检测（四合一）
        /// </summary>
        /// <param name="InText">要过滤的字符串</param>
        /// <returns>如果参数存在不安全字符，则返回true</returns>
        public static bool IsSqlCheck(string InText)
        {
            if (isSqlFilter(InText))
            {
                return false;
            }
            if (isSqlFilterType(InText))
            {
                return false;
            }
            if (IsSafeSqlUrl(InText))
            {
                return false;
            }
            if (!IsSafeSqlUrl(InText))
            {
                return false;
            }
            return true;
        }
        /// <summary>
        /// SQL注入过滤（SQL关键字）
        /// </summary>
        /// <param name="InText">要过滤的字符串</param>
        /// <returns>如果参数存在不安全字符，则返回true</returns>
        public static bool isSqlFilter(string InText)
        {
            string word = "table|proc|procedure|and|exec|from|execute|drop|insert|into|select|delete|update|alter|when|set|chr|mid|master|or|then|like|truncate|char|declare|inner|join|where|order|by|as|case|commit|create|distinct|identity";
            if (InText == null)
                return false;
            foreach (string i in word.Split('|'))
            {
                if ((InText.ToLower().IndexOf(i + " ") > -1) || (InText.ToLower().IndexOf(" " + i) > -1))
                {
                    return true;
                }
            }
            return false;
        }
        /// <summary>
        /// SQL注入过滤（数据类型）
        /// </summary>
        /// <param name="InText">要过滤的字符串</param>
        /// <returns>如果参数存在不安全字符，则返回true</returns>
        public static bool isSqlFilterType(string InText)
        {
            string word = "bigint|numeric|bit|smallint|decimal|smallmoney|int|tinyint|money|float|real|date|datetimeoffset|smalldatetime|datetime|time|char|varchar|text|nchar|nvarchar|ntext|binary|varbinary|image|cursor|timestamp|xml|table";
            if (InText == null)
                return false;
            foreach (string i in word.Split('|'))
            {
                if ((InText.ToLower().IndexOf(i + " ") > -1) || (InText.ToLower().IndexOf(" " + i) > -1))
                {
                    return true;
                }
            }
            return false;
        }
        /// <summary>
        /// 检测是否有Sql危险字符（URL）
        /// </summary>
        /// <param name="InText">要过滤的字符串</param>
        /// <returns>如果参数存在不安全字符，则返回true</returns>
        public static bool IsSafeSqlUrl(string InText)
        {
            string word = "and |as |alter |declare |delete |double(|drop |exec(|exec |execute |from |in |inner |insert |into |join |like |or |order |proc |procedure |return |select |set |top |update |values(|where  |bigint(|numeric(|bit(|smallint(|decimal(|smallmoney(|int(|tinyint(|money(|float(|date(|datetimeoffset(|smalldatetime(|datetime(|char(|varchar(|text(|nchar(|nvarchar(|ntext(";
            if (InText == null)
                return false;
            foreach (string i in word.Split('|'))
            {
                if ((InText.ToLower().IndexOf(i) > -1) || (InText.ToLower().IndexOf(i) > -1))
                {
                    return true;
                }
            }
            return false;
        }
        /// <summary>
        /// 检测是否有Sql危险字符
        /// </summary>
        /// <param name="str">要判断字符串</param>
        /// <returns>判断结果</returns>
        public static bool IsSafeSqlString(string str)
        {
            return !Regex.IsMatch(str, @"[-|;|,|\/|\(|\)|\[|\]|\}|\{|%|@|\*|!|\']");
        }
        /// <summary>
        /// 改正sql语句中的转义字符
        /// </summary>
        public static string mashSQL(string str)
        {
            string str2;
            if (str == null)
            {
                str2 = "";
            }
            else
            {
                str = str.Replace("\'", "'");
                str2 = str;
            }
            return str2;
        }
        /// <summary>
        /// 替换sql语句中的有问题符号
        /// </summary>
        public static string ChkSQL(string str)
        {
            string str2;

            if (str == null)
            {
                str2 = "";
            }
            else
            {
                str = str.Replace("'", "''");
                str2 = str;
            }
            return str2;
        }
        /// <summary>
        /// 检测是否有危险的可能用于链接的字符串
        /// </summary>
        /// <param name="str">要判断字符串</param>
        /// <returns>判断结果</returns>
        public static bool IsSafeUserInfoString(string str)
        {
            return !Regex.IsMatch(str, @"^\s*$|^c:\\con\\con$|[%,\*" + "\"" + @"\s\t\<\>\&]|游客|^Guest");
        }
        /// <summary>
        /// 是否为ip
        /// </summary>
        /// <param name="ip"></param>
        /// <returns></returns>
        public static bool IsIP(string ip)
        {
            return Regex.IsMatch(ip, @"^((2[0-4]\d|25[0-5]|[01]?\d\d?)\.){3}(2[0-4]\d|25[0-5]|[01]?\d\d?)$");

        }
        /// <summary>
        /// 是否为ip
        /// </summary>
        /// <param name="ip"></param>
        /// <returns></returns>
        public static bool IsIPSect(string ip)
        {
            return Regex.IsMatch(ip, @"^((2[0-4]\d|25[0-5]|[01]?\d\d?)\.){2}((2[0-4]\d|25[0-5]|[01]?\d\d?|\*)\.)(2[0-4]\d|25[0-5]|[01]?\d\d?|\*)$");

        }
        /// <summary>
        /// 判断对象是否为Int32类型的数字
        /// </summary>
        /// <param name="Expression"></param>
        /// <returns></returns>
        public static bool IsNumeric(object Expression)
        {
            if (Expression != null)
            {
                string str = Expression.ToString();
                if (str.Length > 0 && str.Length <= 11 && Regex.IsMatch(str, @"^[-]?[0-9]*[.]?[0-9]*$"))
                {
                    if ((str.Length < 10) || (str.Length == 10 && str[0] == '1') || (str.Length == 11 && str[0] == '-' && str[1] == '1'))
                    {
                        return true;
                    }
                }
            }
            return false;

        }
        /// <summary>
        /// 判断对象是否为Double类型的数字
        /// </summary>
        /// <param name="Expression"></param>
        /// <returns></returns>
        public static bool IsDouble(object Expression)
        {
            if (Expression != null)
            {
                return Regex.IsMatch(Expression.ToString(), @"^([0-9])[0-9]*(\.\w*)?$");
            }
            return false;
        }
        /// <summary>
        /// 判断给定的字符串数组(strNumber)中的数据是不是都为数值型
        /// </summary>
        /// <param name="strNumber">要确认的字符串数组</param>
        /// <returns>是则返加true 不是则返回 false</returns>
        public static bool IsNumericArray(string[] strNumber)
        {
            if (strNumber == null)
            {
                return false;
            }
            if (strNumber.Length < 1)
            {
                return false;
            }
            foreach (string id in strNumber)
            {
                if (!IsNumeric(id))
                {
                    return false;
                }
            }
            return true;

        }

        #endregion

    }
}

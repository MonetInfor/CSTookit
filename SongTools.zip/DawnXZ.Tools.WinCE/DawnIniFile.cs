﻿// =================================================================== 
// 【宋】常用工具集（DawnXZ.Tools）合集
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：DawnIniFile.cs
// 项目名称：【宋】常用工具集
// 创建时间：2013-01-03
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System;
using System.IO;
using System.Text;
using System.Collections;

namespace DawnXZ.Tools
{
    /// <summary>
    /// INI文件操作类
    /// </summary>
    public class DawnIniFile
    {

        #region 成员字段

        /// <summary>
        /// INI 文件绝对路径
        /// </summary>
        string FIniFilePath;
        /// <summary>
        /// 空格替换字符
        /// </summary>
        char[] FTrimChar = { ' ', '\t' };

        #endregion

        #region 构造函数

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="iniFilePath">INI 文件绝对路径</param>
        public DawnIniFile(string iniFilePath)
        {
            this.FIniFilePath = iniFilePath;
        }

        #endregion

        #region 成员方法

        #region 公共方法

        #region Read all of the configuration section

        /// <summary>
        /// Read all of the configuration section
        /// </summary>
        /// <returns></returns>
        public string[] GetSections()
        {
            string[] strSection = null;
            if (File.Exists(FIniFilePath))
            {
                string str;
                ArrayList ls = new ArrayList();
                TextReader tr = File.OpenText(FIniFilePath);
                while ((str = tr.ReadLine()) != null)
                {
                    str = str.Trim();
                    if ((str.StartsWith("[")) && (str.EndsWith("]"))) ls.Add(str);
                }
                tr.Close();
                if (ls.Count > 0)
                {
                    strSection = new string[ls.Count];
                    for (int i = 0; i < ls.Count; i++)
                    {
                        strSection[i] = ls[i].ToString();
                    }
                }
            }
            return strSection;
        }

        #endregion

        #region Configuration section read

        /// <summary>
        /// Read string value
        /// </summary>
        /// <param name="sectionName">Node Name</param>
        /// <param name="keyName">Key names</param>
        /// <param name="defValue">Defaults</param>
        /// <returns>String value</returns>
        public string ReadString(string sectionName, string keyName, string defValue)
        {
            try
            {
                return CeReadPrivateProfileString(sectionName, keyName, defValue);
            }
            catch
            {
                return defValue;
            }
        }
        /// <summary>
        /// Read integer
        /// </summary>
        /// <param name="sectionName">Node Name</param>
        /// <param name="keyName">Key names</param>
        /// <param name="defValue">Defaults</param>
        /// <returns>Integer value</returns>
        public int ReadInteger(string sectionName, string keyName, int defValue)
        {
            string intStr = CeReadPrivateProfileString(sectionName, keyName, Convert.ToString(defValue));
            try
            {
                return Convert.ToInt32(intStr);
            }
            catch
            {
                return defValue;
            }
        }
        /// <summary>
        /// Reads a Boolean value
        /// </summary>
        /// <param name="sectionName">Node Name</param>
        /// <param name="keyName">Key names</param>
        /// <param name="defValue">Defaults</param>
        /// <returns>Boolean value</returns>
        public bool ReadBool(string sectionName, string keyName, bool defValue)
        {
            try
            {
                return Convert.ToBoolean(CeReadPrivateProfileString(sectionName, keyName, Convert.ToString(defValue)));
            }
            catch
            {
                return defValue;
            }
        }

        #endregion

        #region Write configuration section

        /// <summary>
        /// Write string
        /// </summary>
        /// <param name="sectionName">Node Name</param>
        /// <param name="keyName">Key names</param>
        /// <param name="keyValue">The new value</param>
        public void WriteString(string sectionName, string keyName, string keyValue)
        {
            CeWritePrivateProfileString(sectionName, keyName, keyValue);
        }
        /// <summary>
        /// Write integer
        /// </summary>
        /// <param name="sectionName">Node Name</param>
        /// <param name="keyName">Key names</param>
        /// <param name="keyValue">The new value</param>
        public void WriteInteger(string sectionName, string keyName, int keyValue)
        {
            CeWritePrivateProfileString(sectionName, keyName, keyValue.ToString());
        }
        /// <summary>
        /// Writes a Boolean value
        /// </summary>
        /// <param name="sectionName">Node Name</param>
        /// <param name="keyName">Key names</param>
        /// <param name="keyValue">The new value</param>
        public void WriteBool(string sectionName, string keyName, bool keyValue)
        {
            CeWritePrivateProfileString(sectionName, keyName, Convert.ToString(keyValue));
        }

        #endregion

        #endregion

        #region 私有方法

        /// <summary>
        /// Write to the configuration section of key
        /// </summary>
        /// <param name="sectionName">Node Name</param>
        /// <param name="keyName">Key names</param>
        /// <param name="keyValue">The new value</param>
        /// <returns></returns>
        private int CeWritePrivateProfileString(string sectionName, string keyName, string keyValue)
        {
            ArrayList ls = new ArrayList();
            bool SectOK = false;
            bool SetOK = false;
            if (File.Exists(FIniFilePath))
            {
                int pos1;
                string substr;
                string str;
                TextReader tr = File.OpenText(FIniFilePath);
                while ((str = tr.ReadLine()) != null)
                {
                    ls.Add(str);
                }
                tr.Close();
                //开始寻找关键字，如果找不到，则在这段的最后一行插入，然后再整体的保存一下INI文件。
                for (int i = 0; i < ls.Count; i++)
                {
                    str = ls[i].ToString();
                    //先判断是否到下一段中了,如果本来就是最后一段，那就有可能永远也不会发生了。
                    if (str.StartsWith("[") && SectOK)
                    {
                        SetOK = true;//如果在这一段中没有找到，并且已经要进入下一段了，就直接在这一段末添加了。
                        ls.Insert(i, keyName.Trim() + "=" + keyValue);
                        break;//如果到下一段了，则直接退出就好。
                    }
                    if (SectOK)
                    {
                        pos1 = str.IndexOf("=");
                        if (pos1 > 1)
                        {
                            substr = str.Substring(0, pos1);
                            substr.Trim(FTrimChar);
                            //如果在这一段中找到KEY了，直接修改就好了。
                            if (substr.Equals(keyName, StringComparison.OrdinalIgnoreCase) && SectOK) //是在此段中，并且KEYSTR前段也能匹配上。
                            {
                                SetOK = true;
                                ls[i] = keyName.Trim() + "=" + keyValue;
                                break;
                            }
                        }
                    }
                    //判断是否到需要的段中了。
                    if (str.StartsWith("[" + sectionName + "]")) SectOK = true;
                }
                if (SetOK == false)
                {
                    SetOK = true;
                    if (!SectOK)
                    {
                        ls.Add("[" + sectionName + "]");//如果没有找到段，则需要再添加段。
                    }
                    ls.Add(keyName.Trim() + "=" + keyValue);
                }
            }
            else
            {
                //如果文件不存在，则需要建立文件。
                ls.Clear();
                ls.Add("##文件创建：" + DateTime.Now.ToString() + "##");
                ls.Add("[" + sectionName + "]");
                ls.Add(keyName.Trim() + "=" + keyValue);
            }
            if (File.Exists(FIniFilePath))
            {
                File.Delete(FIniFilePath);//删除源文件。
            }
            TextWriter tw = File.CreateText(FIniFilePath);
            //string[] strList = new string[ls.Count];
            for (int i = 0; i < ls.Count; i++)
            {
                //strList[i] = ls[i].ToString();
                tw.WriteLine(ls[i].ToString());
            }
            tw.Flush();
            tw.Close();
            //File.WriteAllLines(IniFileName, strList);
            return 0;
        }
        /// <summary>
        /// Key to read the configuration section
        /// </summary>
        /// <param name="sectionName">Node Name</param>
        /// <param name="keyName">Key names</param>
        /// <param name="defValue">Defaults</param>
        /// <returns>键值</returns>
        private string CeReadPrivateProfileString(string sectionName, string keyName, string defValue)
        {
            string retstr = defValue;
            if (File.Exists(FIniFilePath))
            {
                bool SectOK = false;
                int pos1;
                string substr;
                string str;
                ArrayList ls = new ArrayList();
                TextReader tr = File.OpenText(FIniFilePath);
                while ((str = tr.ReadLine()) != null)
                {
                    str = str.Trim();
                    //先判断是否到下一段中了。
                    if (str.StartsWith("[") && SectOK)
                    {
                        break;//如果到下一段了，则直接退出就好。
                    }
                    if (SectOK)
                    {
                        pos1 = str.IndexOf("=");
                        if (pos1 > 1)
                        {
                            substr = str.Substring(0, pos1);
                            substr.Trim(FTrimChar);
                            if (substr.Equals(keyName, StringComparison.OrdinalIgnoreCase))
                            {
                                //是在此段中，并且KEYSTR前段也能匹配上。
                                retstr = str.Substring(pos1 + 1).Trim(FTrimChar);
                                break;
                            }
                        }
                    }
                    //判断是否到需要的段中了。
                    if (str.StartsWith("[" + sectionName + "]")) SectOK = true;
                }
                tr.Close();
            }
            return retstr;
        }

        #endregion

        #endregion

    }
}

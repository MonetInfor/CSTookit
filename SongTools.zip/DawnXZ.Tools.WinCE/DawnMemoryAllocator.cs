﻿// =================================================================== 
// 【宋】常用工具集（DawnXZ.Tools）合集
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：DawnMemoryAllocator.cs
// 项目名称：【宋】常用工具集
// 创建时间：2013-01-03
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System;
using System.Runtime.InteropServices;

namespace DawnXZ.Tools
{
    
    /// <summary>
    /// <para>###########################################################################################</para>
    /// <para>## Name of function/class/method...: MemoryAllocator </para>
    /// <para>## Version of function/class/method: v1.1 </para>
    /// <para>## Version of software.............: v1.0 </para>
    /// <para>## Author..........................: Gabriel Renom </para>
    /// <para>## Date............................: 1/December/2006 (Last update 4/12/2006) </para>
    /// <para>## Company.........................: Intellident </para>
    /// <para>##----------------------------------------------------------------------------------------- </para>
    /// <para>## Description: MemoryAllocater gives you the ability of setting your own memory (Mb/KB) </para>
    /// <para>## - SetMemoryInMegaBit () </para>
    /// <para>## - SetMemoryInKB () </para>
    /// <para>## It gets information about any kind of memory available/total from the system: </para>
    /// <para>## - Virtual Memory </para>
    /// <para>## - Physical Memory </para>
    /// <para>## - Page File </para>
    /// <para>## - Page Size </para>
    /// <para>## - CF CardFree Space </para>
    /// <para>##----------------------------------------------------------------------------------------- </para>
    /// <para>## IN: - </para>
    /// <para>##----------------------------------------------------------------------------------------- </para>
    /// <para>## OUT: - </para>
    /// <para>##----------------------------------------------------------------------------------------- </para>
    /// <para>## Dependencies: By default it uses API calls to "coredll.dll" and .NET libraries; System </para>
    /// <para>## and System.Runtime.InteropServices.      OpenNetCF.org</para>
    /// <para>###########################################################################################</para>
    /// </summary>
    public class DawnMemoryAllocator
    {

        #region [ Variables ]

        /// <summary>
        /// 存储页
        /// </summary>
        private int iStoragePages = 0;
        /// <summary>
        /// RAM页
        /// </summary>
        private int iRamPages = 0;
        /// <summary>
        /// 页面大小
        /// </summary>
        private int iPageSize = 0;

        #endregion

        #region [ Enums ]

        /// <summary>
        /// 处理器类型枚举
        /// </summary>
        public enum ProcessorType : int
        {
            /// <summary> 
            /// Processor is Intel 80386. 
            /// </summary> 
            Intel_386 = 386,
            /// <summary> 
            /// Processor is Intel 80486. 
            /// </summary> 
            Intel_486 = 486,
            /// <summary> 
            /// Processor is Intel Pentium (80586). 
            /// </summary> 
            Intel_Pentium = 586,
            /// <summary> 
            /// Processor is Intel Pentium II (80686). 
            /// </summary> 
            Intel_PentiumII = 686,
            /// <summary> 
            /// Processor is Intel 64bit (IA64). 
            /// </summary> 
            Intel_IA64 = 2200,
            /// <summary> 
            /// Processor is MIPS R4000. 
            /// </summary> 
            MIPS_R4000 = 4000,
            /// <summary> 
            /// Processor is Alpha 21064. 
            /// </summary> 
            Alpha_21064 = 21064,
            /// <summary> 
            /// Processor is Power PC 403. 
            /// </summary> 
            PPC_403 = 403,
            /// <summary> 
            /// Processor is Power PC 601. 
            /// </summary> 
            PPC_601 = 601,
            /// <summary> 
            /// Processor is Power PC 603. 
            /// </summary> 
            PPC_603 = 603,
            /// <summary> 
            /// Processor is Power PC 604. 
            /// </summary> 
            PPC_604 = 604,
            /// <summary> 
            /// Processor is Power PC 620. 
            /// </summary> 
            PPC_620 = 620,
            /// <summary> 
            /// Processor is Hitachi SH3. 
            /// </summary> 
            Hitachi_SH3 = 10003,
            /// <summary> 
            /// Processor is Hitachi SH3E. 
            /// </summary> 
            Hitachi_SH3E = 10004,
            /// <summary> 
            /// Processor is Hitachi SH4. 
            /// </summary> 
            Hitachi_SH4 = 10005,
            /// <summary> 
            /// Processor is Motorola 821. 
            /// </summary> 
            Motorola_821 = 821,
            /// <summary> 
            /// Processor is SH3. 
            /// </summary> 
            SHx_SH3 = 103,
            /// <summary> 
            /// Processor is SH4. 
            /// </summary> 
            SHx_SH4 = 104,
            /// <summary> 
            /// Processor is StrongARM. 
            /// </summary> 
            StrongARM = 2577,
            /// <summary> 
            /// Processor is ARM 720. 
            /// </summary> 
            ARM720 = 1824,
            /// <summary> 
            /// Processor is ARM 820. 
            /// </summary> 
            ARM820 = 2080,
            /// <summary> 
            /// Processor is ARM 920. 
            /// </summary> 
            ARM920 = 2336,
            /// <summary> 
            /// Processor is ARM 7 TDMI. 
            /// </summary> 
            ARM_7TDMI = 70001
        }
        /// <summary>
        /// 处理器架构枚举
        /// </summary>
        public enum ProcessorArchitecture : short
        {
            /// <summary> 
            /// Processor is Intel x86 based. 
            /// </summary> 
            Intel = 0,
            /// <summary> 
            /// Processor is MIPS based. 
            /// </summary> 
            MIPS = 1,
            /// <summary> 
            /// Processor is Alpha based. 
            /// </summary> 
            Alpha = 2,
            /// <summary> 
            /// Processor is Power PC based. 
            /// </summary> 
            PPC = 3,
            /// <summary> 
            /// Processor is SH3, SH4 etc. 
            /// </summary> 
            SHX = 4,
            /// <summary> 
            /// Processor is ARM based. 
            /// </summary> 
            ARM = 5,
            /// <summary> 
            /// Processor is Intel 64bit. 
            /// </summary> 
            IA64 = 6,
            /// <summary> 
            /// Processor is Alpha 64bit. 
            /// </summary> 
            Alpha64 = 7,
            /// <summary> 
            /// Unknown processor architecture. 
            /// </summary> 
            Unknown = -1
        }

        #endregion

        #region [ DLL Calls ]

        [DllImport("coredll.dll", SetLastError = true)]
        internal static extern bool SetSystemMemoryDivision(int dwStorePages);
        [DllImport("coredll", SetLastError = true)]
        private static extern bool GetSystemMemoryDivision(ref int storagepages, ref int rampages, ref int pageSizepages);
        [DllImport("coredll", EntryPoint = "GetSystemInfo", SetLastError = true)]
        internal static extern void GetSystemInfoCE(out SystemInfo pSI);
        [DllImport("coredll", EntryPoint = "GlobalMemoryStatus", SetLastError = false)]
        internal static extern void GlobalMemoryStatusCE(out MemoryStatus msce);
        [DllImport("coredll", EntryPoint = "GetDiskFreeSpaceEx", SetLastError = true)]
        internal static extern bool GetFreeSpace(string DirectoryName, ref long FreeBytesAvailableToCaller, ref long TotalNumberOfBytes, ref long TotalNumberOfFreeBytes);
        
        #endregion

        #region [ Structures ]

        /// <summary>
        /// 内存状态
        /// </summary>
        public struct MemoryStatus
        {
            /// <summary>
            /// dwLength
            /// </summary>
            internal uint dwLength;
            /// <summary> 
            /// Specifies a number between 0 and 100 that gives a general idea of current memory utilization, in which 0 indicates no memory use and 100 indicates full memory use. 
            /// </summary> 
            public int MemoryLoad;
            /// <summary> 
            /// Indicates the total number of bytes of physical memory. 
            /// </summary> 
            public int TotalPhysical;
            /// <summary> 
            /// Indicates the number of bytes of physical memory available. 
            /// </summary> 
            public int AvailablePhysical;
            /// <summary> 
            /// Indicates the total number of bytes that can be stored in the paging file. Note that this number does not represent the actual physical size of the paging file on disk. 
            /// </summary> 
            public int TotalPageFile;
            /// <summary> 
            /// Indicates the number of bytes available in the paging file. 
            /// </summary> 
            public int AvailablePageFile;
            /// <summary> 
            /// Indicates the total number of bytes that can be described in the user mode portion of the virtual address space of the calling process. 
            /// </summary> 
            public int TotalVirtual;
            /// <summary> 
            /// Indicates the number of bytes of unreserved and uncommitted memory in the user mode portion of the virtual address space of the calling process. 
            /// </summary> 
            public int AvailableVirtual;
        }
        /// <summary>
        /// 系统信息
        /// </summary>
        public struct SystemInfo
        {
            /// <summary> 
            /// The system's processor architecture. 
            /// </summary> 
            public ProcessorArchitecture ProcessorArchitecture;
            /// <summary>
            /// 保留的
            /// </summary>
            internal ushort wReserved;
            /// <summary> 
            /// The page size and the granularity of page protection and commitment. 
            /// </summary> 
            public int PageSize;
            /// <summary> 
            /// Pointer to the lowest memory address accessible to applications and dynamic-link libraries (DLLs).  
            /// </summary> 
            public int MinimumApplicationAddress;
            /// <summary> 
            /// Pointer to the highest memory address accessible to applications and DLLs. 
            /// </summary> 
            public int MaximumApplicationAddress;
            /// <summary> 
            /// Specifies a mask representing the set of processors configured into the system. Bit 0 is processor 0; bit 31 is processor 31.  
            /// </summary> 
            public int ActiveProcessorMask;
            /// <summary> 
            /// Specifies the number of processors in the system. 
            /// </summary> 
            public int NumberOfProcessors;
            /// <summary> 
            /// Specifies the type of processor in the system. 
            /// </summary> 
            public ProcessorType ProcessorType;
            /// <summary> 
            /// Specifies the granularity with which virtual memory is allocated. 
            /// </summary> 
            public int AllocationGranularity;
            /// <summary> 
            /// Specifies the system抯 architecture-dependent processor level. 
            /// </summary> 
            public short ProcessorLevel;
            /// <summary> 
            /// Specifies an architecture-dependent processor revision. 
            /// </summary> 
            public short ProcessorRevision;
        }

        #endregion

        #region [ Properties ]

        /// <summary> 
        /// It gets available virtual memory. 
        /// </summary> 
        public int AvailableVirtualMemory
        {
            get { return (this.GetAvailableVirtual()); }
        }
        /// <summary> 
        /// It gets available physical memory. 
        /// </summary> 
        public int AvailablePhysicalMemory
        {
            get { return (this.GetAvailablePhysical()); }
        }
        /// <summary> 
        /// It gets available page file. 
        /// </summary> 
        public int AvailablePageFile
        {
            get { return (this.GetAvailablePageFile()); }
        }
        /// <summary> 
        /// It gets total virtual memory. 
        /// </summary> 
        public int TotalVirtual
        {
            get { return (this.GetTotalVirtual()); }
        }
        /// <summary> 
        /// It gets total physical memory. 
        /// </summary> 
        public int TotalPhysical
        {
            get { return (this.GetTotalPhysical()); }
        }
        /// <summary> 
        /// It gets total page file. 
        /// </summary> 
        public int TotalPageFile
        {
            get { return (this.GetTotalPageFile()); }
        }
        /// <summary> 
        /// It gets page size. 
        /// </summary> 
        public int PageSize
        {
            get { return (this.GetPageSize()); }
        }
        /// <summary> 
        /// It gets Memory Division (API 32) Storage Pages. 
        /// </summary> 
        public int MDStoragePages
        {
            get
            {
                SystemMemoryDivision();
                return (this.iStoragePages);
            }
        }
        /// <summary> 
        /// It gets Memory Division (API 32) Ram Pages. 
        /// </summary> 
        public int MDRamPages
        {
            get
            {
                SystemMemoryDivision();
                return (this.iRamPages);
            }
        }
        /// <summary> 
        /// It gets Memory Division (API 32) Page Size. 
        /// </summary> 
        public int MDPageSize
        {
            get
            {
                SystemMemoryDivision();
                return (this.iPageSize);
            }
        }
        /// <summary> 
        /// It gets the memory available in Ram (return bytes). 
        /// </summary> 
        public int MemoryInUse
        {
            get
            {
                return (GetTotalPhysical() - GetAvailablePhysical());
            }
        }
        /// <summary> 
        /// It gets the free space available in the storage card. 
        /// </summary> 
        public long CFCardFreeSpace
        {
            get
            {
                long lUserBytesFree = 0;
                long lTotalBytes = 0;
                long lTotalBytesFree = 0;
                //GetFreeSpace(@"\Storage Card", ref lUserBytesFree, ref lTotalBytes, ref lTotalBytesFree);
                GetFreeSpace(@"\存储卡", ref lUserBytesFree, ref lTotalBytes, ref lTotalBytesFree);
                return lTotalBytesFree;
            }
        }

        #endregion

        #region [ Constructors ]

        /// <summary>
        /// 构造函数
        /// </summary>
        public DawnMemoryAllocator()
        { }

        #endregion

        #region [ Private Methods ]

        /// <summary> 
        /// Gets the Global Memory Status.... 
        /// </summary> 
        /// <returns></returns> 
        private static MemoryStatus GlobalMemoryStatus()
        {
            MemoryStatus ms = new MemoryStatus();

            GlobalMemoryStatusCE(out ms);

            return ms;
        }
        /// <summary> 
        /// Gets the System Info... 
        /// </summary> 
        /// <returns></returns> 
        private static SystemInfo GetSystemInfo()
        {
            SystemInfo pSI = new SystemInfo();

            try
            {
                GetSystemInfoCE(out pSI);
            }
            catch (Exception)
            {
                //throw new WinAPIException("Error retrieving system info."); 
            }
            return pSI;
        }
        /// <summary> 
        /// Get the available Virtual memory from the system. 
        /// </summary> 
        /// <returns>Memory...</returns> 
        private int GetAvailableVirtual()
        {
            MemoryStatus mem = new MemoryStatus();

            mem = GlobalMemoryStatus();

            return (mem.AvailableVirtual);
        }
        /// <summary> 
        /// Get the available Physical memory from the system. 
        /// </summary> 
        /// <returns>Memory...</returns> 
        private int GetAvailablePhysical()
        {
            MemoryStatus mem = new MemoryStatus();

            mem = GlobalMemoryStatus();

            return (mem.AvailablePhysical);
        }
        /// <summary> 
        /// Get the available Page File memory from the system. 
        /// </summary> 
        /// <returns>Memory...</returns> 
        private int GetAvailablePageFile()
        {
            MemoryStatus mem = new MemoryStatus();
            mem = GlobalMemoryStatus();
            return (mem.AvailablePageFile);
        }
        /// <summary> 
        /// Get total Virtual memory from the system. 
        /// </summary> 
        /// <returns>Memory...</returns> 
        private int GetTotalVirtual()
        {
            MemoryStatus mem = new MemoryStatus();
            mem = GlobalMemoryStatus();
            return (mem.TotalVirtual);
        }
        /// <summary> 
        /// Get total Physical memory from the system. 
        /// </summary> 
        /// <returns>Memory...</returns> 
        private int GetTotalPhysical()
        {
            MemoryStatus mem = new MemoryStatus();
            mem = GlobalMemoryStatus();
            return (mem.TotalPhysical);
        }
        /// <summary> 
        /// Get total Page File memory from the system. 
        /// </summary> 
        /// <returns>Memory...</returns> 
        private int GetTotalPageFile()
        {
            MemoryStatus mem = new MemoryStatus();
            mem = GlobalMemoryStatus();
            return (mem.TotalPageFile);
        }
        /// <summary> 
        /// Get the Page size from the system. 
        /// </summary> 
        /// <returns>Memory...</returns> 
        private int GetPageSize()
        {
            SystemInfo sys = new SystemInfo();
            sys = GetSystemInfo();
            return (sys.PageSize);
        }

        #endregion

        #region [ Public Methods ]

        /// <summary> 
        /// It sets Allocate memory in Megas 
        /// </summary> 
        /// <param name="iMemory">Number of Megas</param> 
        /// <returns>True(OK)/False(Fail)</returns> 
        public bool SetMemoryInMegaBit(int iMemory)
        {
            iMemory = iMemory * 256;
            return (SetSystemMemoryDivision(iMemory));
        }
        /// <summary> 
        /// It sets Allocate memory in KB, the memory has to be allocated in pages of 256KB 
        /// </summary> 
        /// <param name="iMemory">Number of KB</param> 
        /// <returns>True(OK)/False(Fail)</returns> 
        public bool SetMemoryInKB(int iMemory)
        {
            return (SetSystemMemoryDivision(iMemory));
        }
        /// <summary> 
        /// It gets storage, ram and page size pages. 
        /// </summary> 
        /// <param name="iStoragePages_">Storage Pages, it has to be passed by reference to get the value back</param> 
        /// <param name="iRamPages_">Ram Pages, it has to be passed by reference to get the value back</param> 
        /// <param name="iPageSizePages_">Page Size Pages, it has to be passed by reference to get the value back</param> 
        /// <returns></returns>
        public bool SystemMemoryDivision(ref int iStoragePages_, ref int iRamPages_, ref int iPageSizePages_)
        {
            return (GetSystemMemoryDivision(ref iStoragePages_, ref iRamPages_, ref iPageSizePages_));
        }
        /// <summary>
        /// It gets storage, ram and page size pages. 
        /// </summary>
        /// <returns></returns>
        public bool SystemMemoryDivision()
        {
            return (GetSystemMemoryDivision(ref iStoragePages, ref iRamPages, ref iPageSize));
        }
        /// <summary> 
        /// It gets the Processor Architecture. 
        /// </summary> 
        /// <returns>Processor Architecture</returns> 
        public string GetProcessorArchitecture()
        {
            SystemInfo sys = new SystemInfo();
            ProcessorArchitecture PA = new ProcessorArchitecture();
            sys = GetSystemInfo();
            PA = sys.ProcessorArchitecture;
            return (PA.ToString());
        }
        /// <summary> 
        /// It gets the Allocation Granularity with Virtual Memory is allocated. 
        /// </summary> 
        /// <returns>Processor Architecture</returns> 
        public int GetAllocationGranularity()
        {
            SystemInfo sys = new SystemInfo();
            //ProcessorArchitecture PA = new ProcessorArchitecture();
            sys = GetSystemInfo();
            return (sys.AllocationGranularity);
        }
        /// <summary>
        /// 重新分配资源
        /// </summary>
        /// <returns>成功/失败</returns>
        public bool ReAllocateDivision()
        {
            long X = 0;
            long L = 0;
            int PageSize = 0;
            X = ((this.GetAvailableVirtual()) - (this.GetAvailablePhysical())) / 2;
            L = X / this.GetPageSize();
            PageSize = System.Int32.Parse(L.ToString());
            return (SetSystemMemoryDivision(PageSize));
        }

        #endregion

    }
}

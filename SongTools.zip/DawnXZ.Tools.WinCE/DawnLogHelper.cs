﻿using System;
using System.IO;
using System.Net.Sockets;

namespace DawnXZ.Tools
{
    /// <summary>
    /// 日志记录器
    /// </summary>
    public class DawnLogHelper
    {

        #region 构造函数

        /// <summary>
        /// 构造函数
        /// <para>存放于程序目录下的logs文件夹</para>
        /// </summary>
        public DawnLogHelper()
        { }

        #endregion

        #region 成员方法
        
        /// <summary>
        /// 记录系统日志
        /// </summary>
        /// <param name="msg">日志消息正文</param>
        public void Write(string msg)
        {
            WriteMsg("Information", msg);
        }
        /// <summary>
        /// 记录系统日志
        /// </summary>
        /// <param name="type">日志消息类型</param>
        /// <param name="msg">日志消息正文</param>
        public void Write(string type, string msg)
        {
            WriteMsg(type, msg);
        }
        /// <summary>
        /// 记录系统日志
        /// </summary>
        /// <param name="ex">错误消息对象</param>
        public void Write(Exception ex)
        {
            if (ex is SocketException) WriteMsg("Error", ((SocketException)ex).ErrorCode.ToString());
            WriteMsg("Error",ex.GetType().Name);
            WriteMsg("Error", ex.Message);
            WriteMsg("Error", ex.StackTrace);
        }
        /// <summary>
        /// 记录系统日志
        /// </summary>
        /// <param name="type">日志消息类型</param>
        /// <param name="ex">错误消息对象</param>
        public void Write(string type, Exception ex)
        {
            if (ex is SocketException) WriteMsg(type, ((SocketException)ex).ErrorCode.ToString());
            WriteMsg(type, ex.GetType().Name);
            WriteMsg(type, ex.Message);
            WriteMsg(type, ex.StackTrace);
        }
        /// <summary>
        /// 写日志文件
        /// </summary>
        /// <param name="type">日志消息类型</param>
        /// <param name="msg">日志消息正文</param>
        private void WriteMsg(string type, string msg)
        {
            if (!Directory.Exists(DawnFileRelated.LogPath))
            {
                Directory.CreateDirectory(DawnFileRelated.LogPath);
            }
            string fileNames = string.Format(@"{0}.log", DateTime.Now.ToString("yyyy-MM-dd"));
            fileNames = Path.Combine(DawnFileRelated.LogPath, fileNames);
            if (!File.Exists(fileNames))
            {
                FileStream fs = File.Create(fileNames);
                fs.Close();
            }
            WriteFile(fileNames, string.Format(@"{0} [{1}] {2}", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), type, msg));
        }
        /// <summary>
        /// 写日志文件
        /// </summary>
        /// <param name="fileName">文件绝对路径</param>
        /// <param name="msg">日志消息正文</param>
        private void WriteFile(string fileName, string msg)
        {
            try
            {
                StreamWriter sw = File.AppendText(fileName);
                sw.WriteLine(msg);
                sw.Flush();
                sw.Close();
            }
            catch { }
        }

        #endregion

    }
}

﻿// =================================================================== 
// 【宋】常用工具集（DawnXZ.Tools）合集
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：DawnSystems.cs
// 项目名称：【宋】常用工具集
// 创建时间：2013-01-03
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System;

namespace DawnXZ.Tools
{
    /// <summary>
    /// WinCE 系统相关操作
    /// </summary>
    public class DawnSystems
    {

        #region Restart WinCE

        /// <summary>
        /// Restart WinCE
        /// </summary>
        /// <param name="dwIoControlCode"></param>
        /// <param name="lpInBuf"></param>
        /// <param name="nInBufSize"></param>
        /// <param name="lpOutBuf"></param>
        /// <param name="nOutBufSize"></param>
        /// <param name="lpBytesReturned"></param>
        /// <returns></returns>
        [System.Runtime.InteropServices.DllImport("coredll.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
        private extern static int KernelIoControl(int dwIoControlCode, IntPtr lpInBuf, int nInBufSize, IntPtr lpOutBuf, int nOutBufSize, ref int lpBytesReturned);
        /// <summary>
        /// Restart WinCE
        /// </summary>
        [System.Runtime.InteropServices.DllImport("coredll.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
        private extern static void SetCleanRebootFlag();
        /// <summary>
        /// Restart WinCE
        /// </summary>
        public void RestartWinCE()
        {
            int IOCTL_HAL_REBOOT = 0x101003C;
            int bytesReturned = 0;
            SetCleanRebootFlag();
            KernelIoControl(IOCTL_HAL_REBOOT, IntPtr.Zero, 0, IntPtr.Zero, 0, ref bytesReturned);
        }

        #endregion

    }
}

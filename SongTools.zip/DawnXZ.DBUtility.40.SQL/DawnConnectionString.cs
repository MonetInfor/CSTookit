﻿// =================================================================== 
// 通用数据库(DawnXZ.DBUtility)操作项目
//====================================================================
//【宋杰军 @Copy Right 2008+】--【联系ＱＱ：6808240】--【请保留此注释】
//====================================================================
// 文件名称：Conn.cs
// 项目名称：通用数据库操作层
// 创建时间：2010-12-24
// 创建人员：宋杰军
// 负 责 人：宋杰军
// ===================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ===================================================================
using System;
using System.Web;
using System.Configuration;

namespace DawnXZ.DBUtility
{
    /// <summary>
    /// The Conn class 
    /// </summary>
    public static class DawnConnectionString
    {

        #region 数据库连接字符串

        //public static readonly string SqlConnString = System.Configuration.ConfigurationManager.ConnectionStrings["strConnection"].ConnectionString;
        /// <summary>
        /// Sql Server 连接字符串
        /// 默认名称：strConnection
        /// </summary>
        /// <param name="KeyName">键值名称</param>
        /// <returns>连接字符串</returns>
        public static string SqlConnString(string KeyName)
        {
            string tmp = null;
            if (!string.IsNullOrEmpty(KeyName))
            {
                tmp = ConfigurationManager.ConnectionStrings[KeyName].ConnectionString;
            }
            else
            {
                tmp = ConfigurationManager.ConnectionStrings["strConnection"].ConnectionString;
            }
            return tmp;
        }
        
        #endregion 数据库连接字符串
    
    }
}

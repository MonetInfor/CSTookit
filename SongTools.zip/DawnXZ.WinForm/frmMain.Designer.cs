﻿namespace DawnXZ.WinForm
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.btnTest = new System.Windows.Forms.Button();
            this.btnDesencryptAll = new System.Windows.Forms.Button();
            this.btnDesencrypt = new System.Windows.Forms.Button();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.BackColor = System.Drawing.Color.LightSlateGray;
            this.toolStripContainer1.ContentPanel.Controls.Add(this.btnTest);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.btnDesencryptAll);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.btnDesencrypt);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(1018, 105);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStripContainer1.LeftToolStripPanelVisible = false;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 600);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.RightToolStripPanelVisible = false;
            this.toolStripContainer1.Size = new System.Drawing.Size(1018, 105);
            this.toolStripContainer1.TabIndex = 1;
            this.toolStripContainer1.Text = "toolStripContainer1";
            this.toolStripContainer1.TopToolStripPanelVisible = false;
            // 
            // btnTest
            // 
            this.btnTest.BackColor = System.Drawing.Color.DarkCyan;
            this.btnTest.Font = new System.Drawing.Font("SimSun", 11F, System.Drawing.FontStyle.Bold);
            this.btnTest.ForeColor = System.Drawing.Color.DarkBlue;
            this.btnTest.Image = global::DawnXZ.WinForm.Properties.Resources.package_development;
            this.btnTest.Location = new System.Drawing.Point(264, 9);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(80, 88);
            this.btnTest.TabIndex = 2;
            this.btnTest.Text = "验证测试";
            this.btnTest.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnTest.UseVisualStyleBackColor = false;
            this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
            // 
            // btnDesencryptAll
            // 
            this.btnDesencryptAll.BackColor = System.Drawing.Color.DarkCyan;
            this.btnDesencryptAll.Font = new System.Drawing.Font("SimSun", 11F, System.Drawing.FontStyle.Bold);
            this.btnDesencryptAll.ForeColor = System.Drawing.Color.DarkBlue;
            this.btnDesencryptAll.Image = global::DawnXZ.WinForm.Properties.Resources.encrypted;
            this.btnDesencryptAll.Location = new System.Drawing.Point(138, 9);
            this.btnDesencryptAll.Name = "btnDesencryptAll";
            this.btnDesencryptAll.Size = new System.Drawing.Size(120, 88);
            this.btnDesencryptAll.TabIndex = 1;
            this.btnDesencryptAll.Text = "加/解密定制版";
            this.btnDesencryptAll.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDesencryptAll.UseVisualStyleBackColor = false;
            this.btnDesencryptAll.Click += new System.EventHandler(this.btnDesencryptAll_Click);
            // 
            // btnDesencrypt
            // 
            this.btnDesencrypt.BackColor = System.Drawing.Color.DarkCyan;
            this.btnDesencrypt.Font = new System.Drawing.Font("SimSun", 11F, System.Drawing.FontStyle.Bold);
            this.btnDesencrypt.ForeColor = System.Drawing.Color.DarkBlue;
            this.btnDesencrypt.Image = global::DawnXZ.WinForm.Properties.Resources.file_locked;
            this.btnDesencrypt.Location = new System.Drawing.Point(12, 9);
            this.btnDesencrypt.Name = "btnDesencrypt";
            this.btnDesencrypt.Size = new System.Drawing.Size(120, 88);
            this.btnDesencrypt.TabIndex = 0;
            this.btnDesencrypt.Text = "加/解密通用版";
            this.btnDesencrypt.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDesencrypt.UseVisualStyleBackColor = false;
            this.btnDesencrypt.Click += new System.EventHandler(this.btnDesencrypt_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1018, 705);
            this.Controls.Add(this.toolStripContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "【晨曦小竹】工具集→主界面";
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.Button btnDesencrypt;
        private System.Windows.Forms.Button btnDesencryptAll;
        private System.Windows.Forms.Button btnTest;
    }
}
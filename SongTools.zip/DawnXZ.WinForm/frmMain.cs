﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DawnXZ.WinForm
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        #region .

        /// <summary>
        /// 正在关闭
        /// </summary>
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (MessageBox.Show("您确定要退出本系统吗？", "【晨曦小竹·工具集】提示信息", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.closeAllForm();
                this.Dispose();
                Application.Exit();
            }
            else
            {
                e.Cancel = true;
            }
            base.OnFormClosing(e);
        }
        //关闭所有已经打开的子窗体
        private void closeAllForm()
        {
            if (this.MdiChildren.Length > 0)
            {
                foreach (Form myFrm in this.MdiChildren)
                {
                    myFrm.Close();
                    myFrm.Dispose();
                }
            }
        }
        //检查是否存在当前窗口，私有方法
        private Boolean ckChildFrm(string frmName)
        {
            foreach (Form childFrm in this.MdiChildren)
            {
                //用子窗体的名称进行判断，如果存在则将他激活
                if (childFrm.Name == frmName)
                {
                    if (childFrm.WindowState == FormWindowState.Minimized)
                    {
                        childFrm.WindowState = FormWindowState.Normal;
                    }
                    childFrm.Activate();
                    return true;
                }
            }
            return false;
        }

        #endregion

        /// <summary>
        /// 字符串 加/解 密
        /// </summary>
        private void btnDesencrypt_Click(object sender, EventArgs e)
        {
            if (!ckChildFrm("frmDESEncrypt"))
            {
                frmDESEncrypt frmdesencrypt = new frmDESEncrypt();
                frmdesencrypt.MdiParent = this;
                frmdesencrypt.Show();
            }
        }
        /// <summary>
        /// 字符串 加/解 密
        /// </summary>
        private void btnDesencryptAll_Click(object sender, EventArgs e)
        {
            if (!ckChildFrm("frmDESEncryptAll"))
            {
                frmDESEncryptAll frmdesencryptall = new frmDESEncryptAll();
                frmdesencryptall.MdiParent = this;
                frmdesencryptall.Show();
            }
        }
        /// <summary>
        /// 测试专用
        /// </summary>
        private void btnTest_Click(object sender, EventArgs e)
        {
            if (!ckChildFrm("frmTest"))
            {
                frmTest frmtest = new frmTest();
                frmtest.MdiParent = this;
                frmtest.Show();
            }
        }
    }
}

﻿using System;
using System.Windows.Forms;

namespace DawnXZ.WinForm
{
    /// <summary>
    /// Extensible general entrust class
    /// </summary>
    public class DawnDelegateEx
    {

        #region Delegate & Event

        /// <summary>
        /// Declare a delegate
        /// </summary>
        /// <param name="sender">The delegate object</param>
        /// <param name="e">The delegate event</param>
        public delegate void UpdateInfoEventHandler(object sender, UpdateInfoEventArgs e);
        /// <summary>
        /// Declare a delegate event
        /// </summary>
        private event UpdateInfoEventHandler UpdateInfo;

        #endregion

        #region Delegate event class

        /// <summary>
        /// Delegate event class
        /// </summary>
        public class UpdateInfoEventArgs : EventArgs
        {
            /// <summary>
            /// To update the information
            /// </summary>
            public readonly string _strInfo;
            /// <summary>
            /// Whether for error message
            /// </summary>
            public readonly bool _exFlag;
            /// <summary>
            /// Constructed function
            /// </summary>            
            /// <param name="strInfo">To update the information</param>
            /// <param name="exFlag">Whether for error message</param>
            public UpdateInfoEventArgs(string strInfo, bool exFlag)
            {
                this._strInfo = strInfo;
                this._exFlag = exFlag;
            }
        }

        #endregion

        #region Register & UnRegister

        /// <summary>
        /// To register more than one method for an event
        /// </summary>
        /// <param name="method">Method name</param>
        public void Register(UpdateInfoEventHandler method)
        {
            UpdateInfo += method;
        }
        /// <summary>
        /// Registered with the event a unique method
        /// </summary>
        /// <param name="method">Method name</param>
        public void RegisterOnly(UpdateInfoEventHandler method)
        {
            UpdateInfo = method;
        }
        /// <summary>
        /// Registered with the event against method
        /// </summary>
        /// <param name="method">Method name</param>
        public void UnRegister(UpdateInfoEventHandler method)
        {
            UpdateInfo -= method;
        }
        /// <summary>
        /// Registered with the event against method
        /// </summary>
        public void UnRegister()
        {
            UpdateInfo = null;
        }

        #endregion

        #region Virtual

        /// <summary>
        /// Can be overridden execute method
        /// </summary>
        /// <param name="form">System.Windows.Forms</param>
        /// <param name="e">The delegate event</param>
        protected virtual void OnUpdateInfo(Form form, UpdateInfoEventArgs e)
        {
            //if (UpdateInfo != null && form != null) form.Invoke(UpdateInfo, this, e);//会造成阻塞[即假死]
            if (UpdateInfo != null && form != null) form.BeginInvoke(UpdateInfo, this, e);
        }

        #endregion

        #region Member method

        /// <summary>
        /// Executes a delegate method
        /// </summary>
        /// <param name="form">System.Windows.Forms</param>
        /// <param name="strInfo">To update the information</param>
        /// <param name="exFlag">Whether for error message</param>
        public void Executes(Form form, string strInfo, bool exFlag)
        {
            UpdateInfoEventArgs e = new UpdateInfoEventArgs(strInfo, exFlag);
            OnUpdateInfo(form, e);
            e = null;
        }

        #endregion

    }
}

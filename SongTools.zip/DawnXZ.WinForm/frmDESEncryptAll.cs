﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DawnXZ.Tools;

namespace DawnXZ.WinForm
{
    public partial class frmDESEncryptAll : Form
    {
        public frmDESEncryptAll()
        {
            InitializeComponent();
        }

        private void frmDESEncryptAll_Load(object sender, EventArgs e)
        {
            this.cboxKeyType.SelectedIndex = 0;
        }

        #region 自定义密钥加/解密
        /// <summary>
        /// 自定义密钥加密
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEncrypt2_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txt_tempData2.Text) && !string.IsNullOrEmpty(txt_desKeys.Text))
            {
                txt_desData2.Clear();
                txt_desData2.Text = DawnDESEncrypt.Encrypt(txt_tempData2.Text, txt_desKeys.Text);
            }
        }
        /// <summary>
        /// 自定义密钥解密
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDecrypt2_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txt_tempData2.Text) && !string.IsNullOrEmpty(txt_desKeys.Text))
            {
                txt_desData2.Clear();
                try
                {
                    txt_desData2.Text = DawnDESEncrypt.Decrypt(txt_tempData2.Text, txt_desKeys.Text);
                }
                catch
                {
                    txt_desData2.Text = "错误的加密原数据！";
                }
            }
        }
        #endregion 自定义密钥加/解密

        #region 内置密钥加/解密
        /// <summary>
        /// 内置密钥加密
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnInsidEncrypt_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtInsidOrigin.Text))
            {
                txtInsidValue.Clear();
                txtInsidValue.Text = DawnDESEncrypt.Encrypt(txtInsidOrigin.Text, byte.Parse(cboxKeyType.SelectedItem.ToString()));
            }
        }
        /// <summary>
        /// 内置密钥解密
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnInsidDecrypt_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtInsidOrigin.Text))
            {
                txtInsidValue.Clear();
                try
                {
                    txtInsidValue.Text = DawnDESEncrypt.Decrypt(txtInsidOrigin.Text, byte.Parse(cboxKeyType.SelectedItem.ToString()));
                }
                catch
                {
                    txtInsidValue.Text = "错误的加密原数据！";
                }
            }
        }
        #endregion 内置密钥加/解密
        
    }
}

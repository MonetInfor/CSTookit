﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DawnXZ.Tools;

namespace DawnXZ.WinForm
{
    public partial class frmDESEncrypt : Form
    {
        /// <summary>
        /// 构造函数
        /// </summary>
        public frmDESEncrypt()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 窗口加载
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmDESEncrypt_Load(object sender, EventArgs e)
        {
            
        }

        #region 通用密钥加/解密数据
        /// <summary>
        /// 通用密钥加密数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDESOrigin_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtDESOrigin.Text))
            {
                txtDESValue.Clear();
                txtDESValue.Text = DawnDESEncrypt.Encrypt(txtDESOrigin.Text);
            }
        }
        /// <summary>
        /// 通用密钥解密数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDESValue_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtDESOrigin.Text))
            {
                txtDESValue.Clear();
                try
                {
                    txtDESValue.Text = DawnDESEncrypt.Decrypt(txtDESOrigin.Text);
                }
                catch
                {
                    txtDESValue.Text = "错误的加密原数据！";
                }
            }
        }
        #endregion 通用密钥加/解密数据

        #region MD5数据生成
        /// <summary>
        /// MD5数据生成
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnMD5_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtMD5Origin.Text))
            {
                txtMD5Value.Clear();
                txtMD5Value.Text = DawnDESEncrypt.MD5(txtMD5Origin.Text, true);
            }
        }
        #endregion MD5数据生成

        #region Base64
        /// <summary>
        /// 转Base64
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnToBase64_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtBase64Origin.Text.Trim()))
            {
                this.txtBase64Value.Clear();
                this.txtBase64Value.Text = DawnTypeConverter.ToBase64Encode(txtBase64Origin.Text.Trim());
            }
        }
        /// <summary>
        /// 反转Base64
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnToUnBase64_Click(object sender, EventArgs e)
        {
            string strVal = txtBase64Origin.Text.Trim();
            if (!string.IsNullOrEmpty(strVal))
            {
                this.txtBase64Value.Clear();
                if (!DawnValidator.IsBase64String(strVal))
                {
                    this.txtBase64Value.Text = "错误的[Base64]原数据！";
                    return;
                }                
                this.txtBase64Value.Text = DawnTypeConverter.ToBase64Decode(txtBase64Origin.Text.Trim());
            }
        }
        #endregion Base64
               
    }
}

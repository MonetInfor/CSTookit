﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DawnXZ.Tools;

namespace DawnXZ.WinForm
{
    public partial class frmTest : Form
    {
        /// <summary>
        /// 构造函数
        /// </summary>
        public frmTest()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 加载
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmTest_Load(object sender, EventArgs e)
        {
            //this.txtMobile.Text = "13312341234";
            //this.cboxType.SelectedIndex = this.cboxType.Items.Count - 1;
        }

        #region 电话号码
        /// <summary>
        /// 电话号码
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEnter_Click(object sender, EventArgs e)
        {
            string strValue = this.cboxPhone.SelectedItem as string;
            bool checkFlag = false;
            switch (strValue)
            {
                case "电话号码":
                    checkFlag = DawnValidator.TelIsTelephone(this.txtMobile.Text);
                    break;
                case "中国移动":
                    checkFlag = DawnValidator.TelIsChinaMobile(this.txtMobile.Text);
                    break;
                case "中国联通":
                    checkFlag = DawnValidator.TelIsChinaUnicom(this.txtMobile.Text);
                    break;
                case "中国电信":
                    checkFlag = DawnValidator.TelIsChinaTelecom(this.txtMobile.Text);
                    break;
                default:
                    break;
            }
            this.lblResultPhone.Text = checkFlag.ToString();
        }
        #endregion 电话号码

        #region 电子邮箱
        /// <summary>
        /// 电子邮箱
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEmail_Click(object sender, EventArgs e)
        {
            this.lblResultEmail.Text = DawnValidator.IsEmail(this.txtEmail.Text).ToString();
        }
        #endregion 电子邮箱

        #region 字符串验证
        /// <summary>
        /// 字符串验证
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnString_Click(object sender, EventArgs e)
        {
            string strValue = this.cboxString.SelectedItem as string;
            bool checkFlag = false;
            switch (strValue)
            {
                case "用户密码":
                    checkFlag = DawnValidator.EngIsPassword(this.txtString.Text);
                    break;
                case "用户密码2":
                    checkFlag = DawnValidator.EngIsPasswords(this.txtString.Text);
                    break;
                case "注册帐号":
                    checkFlag = DawnValidator.EngIsRegister(this.txtString.Text);
                    break;
                case "26个字母":
                    checkFlag = DawnValidator.EngIsEnglish(this.txtString.Text);
                    break;
                case "大写字母":
                    checkFlag = DawnValidator.EngIsUppercase(this.txtString.Text);
                    break;
                case "小写字母":
                    checkFlag = DawnValidator.EngIsLowercase(this.txtString.Text);
                    break;
                case "字母数字":
                    checkFlag = DawnValidator.EngIsEngAndNum(this.txtString.Text);
                    break;
                case "英头数字":
                    checkFlag = DawnValidator.EngIsEngAndNums(this.txtString.Text);
                    break;
                case "字数下线":
                    checkFlag = DawnValidator.EngIsEngAndNumOrUnderline(this.txtString.Text);
                    break;
                default:
                    break;
            }
            this.lblResultString.Text = checkFlag.ToString();
        }
        #endregion 字符串验证

        #region 中文汉字
        /// <summary>
        /// 中文汉字
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnChinese_Click(object sender, EventArgs e)
        {
            string strValue = this.cboxChinese.SelectedItem as string;
            bool checkFlag = false;
            switch (strValue)
            {
                case "中文汉字":
                    checkFlag = DawnValidator.ChsIsChinese(this.txtChinese.Text);
                    break;
                case "中字母数":
                    checkFlag = DawnValidator.ChsIsChineseOrEngOrNum(this.txtChinese.Text);
                    break;
                case "真实姓名":
                    checkFlag = DawnValidator.ChsIsTname(this.txtChinese.Text);
                    break;
                case "半角转换":
                    this.lblResultChinese.Text = string.Format("　{0}", DawnValidator.ChsToDBC(this.txtChinese.Text));
                    break;
                default:
                    break;
            }
            this.lblResultChinese.Text = checkFlag.ToString();
        }
        #endregion 中文汉字

        #region SQL注入
        /// <summary>
        /// SQL注入
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSqlInjection_Click(object sender, EventArgs e)
        {
            string strValue = this.cboxSqlInjection.SelectedItem as string;
            bool checkFlag = false;
            switch (strValue)
            {
                case "四方法合一":
                    checkFlag = DawnValidator.IsSqlFilter(this.txtSqlInjection.Text);
                    break;
                case "SQL关键字":
                    checkFlag = DawnValidator.IsSqlInjectionOfKey(this.txtSqlInjection.Text);
                    break;
                case "SQL数据类型":
                    checkFlag = DawnValidator.IsSqlInjectionOfType(this.txtSqlInjection.Text);
                    break;
                case "SQL危险命令":
                    checkFlag = DawnValidator.IsSqlInjectionOfURL(this.txtSqlInjection.Text);
                    break;
                case "SQL危险字符":
                    checkFlag = DawnValidator.IsSqlInjectionOfString(this.txtSqlInjection.Text);
                    break;
                default:
                    break;
            }
            this.lblResultSqlInjection.Text = checkFlag.ToString();
        }
        #endregion SQL注入

        #region IP地址
        /// <summary>
        /// IP地址
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnIpAdress_Click(object sender, EventArgs e)
        {
            string strValue = this.cboxIpAdress.SelectedItem as string;
            bool checkFlag = false;
            switch (strValue)
            {
                case "常规IP地址":
                    checkFlag = DawnValidator.IsIP(this.txtIpAdress.Text);
                    break;
                case "IPSect":
                    checkFlag = DawnValidator.IsIPSect(this.txtIpAdress.Text);
                    break;
                default:
                    break;
            }
            this.lblResultIpAdress.Text = checkFlag.ToString();
        }
        #endregion IP地址

        #region 数字校验
        /// <summary>
        /// 数字校验
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnNumeral_Click(object sender, EventArgs e)
        {
            string strValue = this.cboxNumeral.SelectedItem as string;
            bool checkFlag = false;
            switch (strValue)
            {
                case "纯数字":
                    checkFlag = DawnValidator.NumIsInteger(this.txtNumeral.Text);
                    break;
                case "零和非零":
                    checkFlag = DawnValidator.NumIsZeroOrNot(this.txtNumeral.Text);
                    break;
                case "正数两位小数":
                    checkFlag = DawnValidator.NumIsPlus2Point(this.txtNumeral.Text);
                    break;
                case "正数一至三位":
                    checkFlag = DawnValidator.NumIsPlus3Point(this.txtNumeral.Text);
                    break;
                case "非零正整数":
                    checkFlag = DawnValidator.NumIsIntegralBySignless(this.txtNumeral.Text);
                    break;
                case "非零负整数":
                    checkFlag = DawnValidator.NumIsIntegralByNegative(this.txtNumeral.Text);
                    break;
                case "正浮点数":
                    checkFlag = DawnValidator.NumIsFloatBySignless(this.txtNumeral.Text);
                    break;
                case "负浮点数":
                    checkFlag = DawnValidator.NumIsFloatByNegative(this.txtNumeral.Text);
                    break;
                case "Int32类型":
                    checkFlag = DawnValidator.NumIsNumeric(this.txtNumeral.Text);
                    break;
                case "Double类型":
                    checkFlag = DawnValidator.NumIsDouble(this.txtNumeral.Text);
                    break;
                case "Int32类型逗号":
                    checkFlag = DawnValidator.NumIsNumericList(this.txtNumeral.Text);
                    break;
                default:
                    break;
            }
            this.lblResultNumeral.Text = checkFlag.ToString();
        }
        #endregion 数字校验

        #region 颜色校验
        /// <summary>
        /// 颜色校验
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnColor_Click(object sender, EventArgs e)
        {
            this.lblResultColor.Text = DawnValidator.IsColor(this.txtColor.Text).ToString();
        }
        #endregion 颜色校验

        #region 身份证号码
        /// <summary>
        /// 身份证号码
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnIDCard_Click(object sender, EventArgs e)
        {
            this.lblResultIDCard.Text = DawnValidator.IsIDCard(this.txtIDCard.Text).ToString();
        }
        #endregion 身份证号码

        #region 链接地址
        /// <summary>
        /// 链接地址
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnUrl_Click(object sender, EventArgs e)
        {
            this.lblResultUrl.Text = DawnValidator.IsURL(this.txtUrl.Text).ToString();
        }
        #endregion 链接地址

        #region 邮政编码
        /// <summary>
        /// 邮政编码
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPost_Click(object sender, EventArgs e)
        {
            this.lblResultPost.Text = DawnValidator.IsPost(this.txtPost.Text).ToString();
        }
        #endregion 邮政编码

    }
}

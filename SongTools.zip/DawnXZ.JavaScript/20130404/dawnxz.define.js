﻿var Dawn = {
    Message: {
        'Success': '成功！',
        'Failing': '操作失败！请重试！',
        'Error': '出错啦！请重试或联系管理员！',
        'Illegal': '您的操作有误，请重试！',
        'CheckCode': '您输入的验证码不正确！'
    }
};